<?php

function get_calculationbuilder_elements() {
    $editArray = array();

    array_push($editArray, 
        array(
            'editContentId' => 'backend_heading',
            'fields' => array(
                array(
                    'type' => 'textarea_',
                    'icon' => 'fas fa-tag',
                    'label' => __('Calculation title (backend)', 'af2_multilanguage'),
                    'placeholder' => __('Enter title...', 'af2_multilanguage'),
                    'required' => true,
                    'details' => array(
                        'html' => true,
                        'htmlId' => 'af2_calculation_backend_heading',
                        'empty_value' => __('Calculation title (backend)', 'af2_multilanguage'),
                        'saveObjectId' => 'title'
                    )
                ),
            ),
        ),
    );


    return $editArray;
}
