<div class="af2_menu_hooks_wrapper mb10">
    <?php if(isset($menu_hook_inline_checkbox)) { ?>
        <div class="af2_toggle_wrapper">
            <input type="checkbox" id="<?=$menu_hook_inline_checkbox['id']?>" class="af2_toggle" <?=$menu_hook_inline_checkbox['active'] ? 'checked' : ''?>>
            <label for="<?=$menu_hook_inline_checkbox['id']?>" class="af2_toggle_btn"></label>
            <h4 class="af2_toggle_label ml5"><?=__($menu_hook_inline_checkbox['label'], 'af2_multilanguage')?></h4>
        </div>
    <?php } ?>
    <?php if(isset($menu_hook_extra_title)) { ?>
        <h4><?=__($menu_hook_extra_title['label'], 'af2_multilanguage')?>: <?=$menu_hook_extra_title['value']?></h4>
    <?php } ?>
    <?php if(isset($menu_hook_inline_search)) { ?>
        <?php
        $filter_columns = null;
        if(is_array($menu_hook_inline_search)) {
            $filter_columns = '';
            for($i = 0; $i < sizeof($menu_hook_inline_search); $i++) {
                if($i != 0) $filter_columns .= ';';
                $filter_columns .= $menu_hook_inline_search[$i];
            }
        }
        else {
            $filter_columns = $menu_hook_inline_search;
        }
        ?>
        <div class="af2_menu_headline_search_component">
            <input id="af2_search_filter" data-searchfiltercolumn="<?=$filter_columns?>" type="text" placeholder="<?=__('Search...', 'af2_multilanguage')?>">
            <div class="af2_menu_headline_search_component_icon"><i class="fas fa-search"></i></div>
        </div>
    <?php } ?>
    <?php if(isset($menu_hook_inline_button_form)) { ?>
        <form method="POST">
            <input type="hidden" name="<?=$menu_hook_inline_button_form['id_label']?>" value="<?=$menu_hook_inline_button_form['id_value']?>">
            <input type="hidden" name="<?=$menu_hook_inline_button_form['bonus_label']?>" value="<?=$menu_hook_inline_button_form['bonus_value']?>">
            <?php
            if(isset($menu_hook_inline_button_form['bonus_labels']) && isset($menu_hook_inline_button_form['bonus_values'])) {
                $i = 0;
                foreach($menu_hook_inline_button_form['bonus_labels'] as $bonus_labels) {
                    echo "<input type='hidden' name='".$menu_hook_inline_button_form['bonus_labels'][$i]."' value='".$menu_hook_inline_button_form['bonus_values'][$i]."'>";
                    $i++;
                }
            }
            ?>
            <button id="<?=$menu_hook_inline_button_form['id']?>" type="submit" class="af2_btn af2_btn_primary"><i class="<?=$menu_hook_inline_button_form['icon']?>"></i><?=__($menu_hook_inline_button_form['label'], 'af2_multilanguage')?></button>
        </form>
    <?php } ?>
</div>
