<div class="af2_helpcenter_button_wrapper">
<div>
    <iframe id="af2_helpcenter_frame" class="af2_hide" src="https://help.funnelforms.io/" loading="lazy" width="400px" height="500px"></iframe>
</div>
<div class="af2_action_button show_hide_helpcenter"><i class="fas fa-question"></i></div>
</div>