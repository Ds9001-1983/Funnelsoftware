<div class="af2_menu_headline">
    <div class="af2_menu_headline_heading">
        <h3 class="af2_menu_headline_heading_text"><?=__($heading, 'af2_multilanguage')?></h3>
    </div>
    <div class="af2_menu_headline_components">
        <?php if(isset($menu_functions_search)) { ?>
            <div class="af2_menu_headline_search_component">
                <?php
                    $filter_columns = null;
                    if(is_array($menu_functions_search)) {
                        $filter_columns = '';
                        for($i = 0; $i < sizeof($menu_functions_search); $i++) {
                            if($i != 0) $filter_columns .= ';';
                            $filter_columns .= $menu_functions_search[$i];
                        }
                    }
                    else {
                        $filter_columns = $menu_functions_search;
                    }
                ?>
                <input id="af2_search_filter" data-searchfiltercolumn="<?=$filter_columns?>" type="text" placeholder="<?=__('Search...', 'af2_multilanguage')?>">
                <div class="af2_menu_headline_search_component_icon"><i class="fas fa-search"></i></div>
            </div>
        <?php } ?>
        
        <?php if(isset($menu_functions_button)) { ?>
            <?php if(isset($menu_functions_button['link'])) { ?>
            <a class="af2_btn_link" href="<?=$menu_functions_button['link']?>">
                <div id="<?=$menu_functions_button['triggerId']?>" class="af2_btn af2_btn_primary af2_menu_functions_button"><i class="<?=$menu_functions_button['icon']?>"></i><?=__($menu_functions_button['label'], 'af2_multilanguage')?></div>
            </a>
            <?php } else { ?>
                <div id="<?=$menu_functions_button['triggerId']?>" class="af2_btn af2_btn_primary af2_menu_functions_button <?= isset($menu_functions_button['modelTarget']) ? 'af2_modal_btn' :''?>" <?php if(isset($menu_functions_button['dataAttributes']) ) { foreach($menu_functions_button['dataAttributes'] as $att => $dataAttr){ echo 'data-'.$att.'="'.$dataAttr.'"'; } }?>><i class="<?=$menu_functions_button['icon']?>"></i><?=__($menu_functions_button['label'], 'af2_multilanguage')?></div>
            <?php } ?>
        <?php } ?>

        <?php if(isset($menu_functions_select)) { ?>
            <div class="af2_menu_headline_select_component">
                <p class="af2_menu_functions_select_label"><?=__($menu_functions_select['title'], 'af2_multilanguage')?></p>
                <select id="<?=$menu_functions_select['id']?>" class="af2_menu_functions_select" data-link="<?=$menu_functions_select['link']?>" data-getattribute="<?=$menu_functions_select['getattribute']?>">
                    <option value="all" <?= $menu_functions_select['selected'] === 'all' ? 'selected' : '' ?>><?=__($menu_functions_select['all_label'], 'af2_multilanguage')?></option>
                    <?php foreach($menu_functions_select['options'] as $option) { ?>
                    <option value="<?=$option['value']?>" <?= strval($menu_functions_select['selected']) === strval($option['value']) ? 'selected' : '' ?>><?=$option['label']?></option>
                    <?php } ?>
                </select>
            </div>
        <?php } ?>
    </div>
</div>