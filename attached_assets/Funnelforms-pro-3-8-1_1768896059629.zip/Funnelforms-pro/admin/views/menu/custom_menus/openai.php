<h5 style="margin-bottom: 30px"><?=__('The Funnelforms AI is currently in beta. Errors may occur when generating the forms. If errors occur, please change your prompt and try again.', 'af2_multilanguage')?></h5>
<div class="af2_openai_form_wrapper">
    <?= do_shortcode('[funnelforms_openai id="'.get_option('af2_openai_form_id').'" preview="true"]') ?>
</div>