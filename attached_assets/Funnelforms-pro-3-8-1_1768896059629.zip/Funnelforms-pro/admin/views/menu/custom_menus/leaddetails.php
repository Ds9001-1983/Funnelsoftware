<div class="af2_leaddetails_page_wrapper">
    <div class="af2_card af2_leaddetails">
        <div class="af2_card_block">
            <div class="af2_leaddetails_controller_buttons">
                <a class="af2_btn_link mb10" href="<?= admin_url('/admin.php?page='.LEADS_SLUG ) ?>">
                    <div id="af2_back_to_leads" class="af2_btn af2_btn_secondary"><i class="fas fa-arrow-left"></i><?=__('Back to overview', 'af2_multilanguage')?></div>
                </a>
                <?php include AF2_MENU_HOOKS_SNIPPET ?>
            </div>
            <div class="af2_leaddetails_table">
            <?php $i = 1; ?>
            <?php foreach($af2_custom_contents['lead_details'] as $af2_custom_content) { ?>
                <div class="af2_leaddetails_table_row_wrapper">
                    <div class="af2_leaddetails_table_row af2_leaddetails_row_left <?= $i % 2 == 0 ? 'second_row' : 'first_row' ?>">
                        <p><?= $af2_custom_content['label']; ?></p>
                    </div>
                    <div class="af2_leaddetails_table_row af2_leaddetails_row_right <?= $i % 2 == 0 ? 'second_row' : 'first_row' ?>">
                        <p><?= $af2_custom_content['value']; ?></p>
                    </div>
                </div>
            <?php $i++; ?>
            <?php } ?>
            </div>
        </div>
    </div>

    <div class="af2_card af2_leaddetails">
        <div class="af2_card_block">
            <h4><?=__('Hidden fields', 'af2_multilanguage')?></h4>
            <div class="af2_leaddetails_table hidden_fields">
                <?php $i = 1; ?>
                <?php foreach($af2_custom_contents['hidden_fields'] as $af2_custom_content) { ?>
                    <div class="af2_leaddetails_table_row_wrapper">
                        <div class="af2_leaddetails_table_row af2_leaddetails_row_left <?= $i % 2 == 0 ? 'second_row' : 'first_row' ?>">
                            <p><?= $af2_custom_content['label']; ?></p>
                        </div>
                        <div class="af2_leaddetails_table_row af2_leaddetails_row_right <?= $i % 2 == 0 ? 'second_row' : 'first_row' ?>">
                            <p><?= esc_html($af2_custom_content['value']); ?></p>
                        </div>
                    </div>
                <?php $i++; ?>
                <?php } ?>
            </div>
        </div>
    </div>

    <div class="af2_card af2_leaddetails">
        <div class="af2_card_block">
            <h4><?=__('Calculations', 'af2_multilanguage')?></h4>
            <div class="af2_leaddetails_table calculations">
                <?php $i = 1; ?>
                <?php foreach($af2_custom_contents['form_calculations'] as $af2_custom_content) { ?>
                    <div class="af2_leaddetails_table_row_wrapper">
                        <div class="af2_leaddetails_table_row af2_leaddetails_row_left <?= $i % 2 == 0 ? 'second_row' : 'first_row' ?>">
                            <p><?= $af2_custom_content['label']; ?></p>
                        </div>
                        <div class="af2_leaddetails_table_row af2_leaddetails_row_right <?= $i % 2 == 0 ? 'second_row' : 'first_row' ?>">
                            <p><?= esc_html($af2_custom_content['value']); ?></p>
                        </div>
                    </div>
                <?php $i++; ?>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
