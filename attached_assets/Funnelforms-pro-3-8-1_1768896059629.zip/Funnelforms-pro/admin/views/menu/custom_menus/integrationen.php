<div class="af2_integrations_wrapper af2_card_table">
    <?php foreach($af2_custom_contents as $af2_custom_content) { ?>
        <?php if($af2_custom_content['active'] == -1) { ?>
            <div class="af2_card invisible">
                <div class="af2_card_block">
                </div>
            </div>
        <?php } else { ?>
            <div class="af2_card <?=$af2_custom_content['active'] == 0 ? 'inactive' : 'af2_modal_btn' ?>" data-target="<?=$af2_custom_content['modal_id']?>">
                <div class="af2_card_block">
                    <h4><?=$af2_custom_content['name']?></h4>
                    <p><?=__($af2_custom_content['type'], 'af2_multilanguage')?> <?=$af2_custom_content['active'] == 0 ? '('.__('In development', 'af2_multilanguage').')' : ''?></p>
                </div>
            </div>

            <div id="<?=$af2_custom_content['modal_id']?>" class="af2_modal" 
                data-heading="<?=$af2_custom_content['name']?>"
                data-close="<?=__('Cancel', 'af2_multilanguage')?>"
                data-class="<?=$af2_custom_content['name']?>_modal"
                data-target="<?=$af2_custom_content['name']?>_modal"
                data-sizeclass="moderate_size"
                data-bottombar="true" >
                
                <!-- Modal content -->
                <div class="af2_modal_content">
                    <form id="<?=$af2_custom_content['modal_id']?>_form" name="<?=$af2_custom_content['modal_id']?>_form" class="af2_integration_form_wrapper" enctype="multipart/form-data" data-integrationid="<?=$af2_custom_content['modal_id']?>">
                        <div class="af2_integration_form">
                            <?php foreach($af2_custom_content['credentials'] as $credential) { ?>
                            <div id="<?=$credential['option_value']?>" class="custom_builder_content_card_box">
                                <div class="custom_builder_content_card_box_heading">
                                    <i class="<?=$credential['icon']?>"></i>
                                    <p><?=__($credential['label'], 'af2_multilanguage')?></p>
                                </div>
                                <div class="custom_builder_content_card_box_content">
                                    <input type="<?=$credential['type']?>" placeholder="..." class="af2_edit_content_input af2_credential_input" data-optionvalue="<?=$credential['option_value']?>" 
                                    value="<?=get_option($credential['option_value'])?>" data-integration="<?=$af2_custom_content['modal_id']?>_form" <?= isset($credential['disabled']) && $credential['disabled'] ? 'disabled' : '' ?>>
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                    </form>
                </div>

                <div class="af2_modal_bottombar">
                    <button type="submit" form="<?=$af2_custom_content['modal_id']?>_form" class="af2_btn af2_btn_primary af2_save_credentials"><?=__('Save credentials', 'af2_multilanguage')?>
                        <span class="af2_hide loading">&nbsp;<i class="fas fa-circle-notch fa-spin"></i></span>
                    </button>
                </div>
            </div>

        <?php } ?>
    <?php } ?>
</div>