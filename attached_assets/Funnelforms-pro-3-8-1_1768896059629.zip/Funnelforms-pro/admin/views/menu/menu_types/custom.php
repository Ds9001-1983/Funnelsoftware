<div class="af2_menu_sheet">
    <div class="af2_menu_sheet_content <?= $show_sidebar == false ? 'no_sidebar' : '' ?>">
        <?php include $menu_custom_template ?>
    </div>
    
    <?php if($show_sidebar == true) include AF2_MENU_SIDEBAR; ?>
</div>