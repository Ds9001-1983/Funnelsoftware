<div class="af2_builder">
    <div class="af2_builder_wrapper">
        <div class="af2_toast_wrapper"></div>
        <?php if(isset($builder_sidebar_data)) { ?>
        <div class="af2_builder_sidebar colorOne leftSidebar <?=$builder_sidebar_select_filter != null ? 'af2_select_filter' : ''?>">
            <div>
                <div class="af2_builder_overflow-scroll">

                    <div class="af2_builder_sidebar_header af2_icon_text af2_builder_element">
                        <div class="af2_icon_wrapper colorPrimary"><i class="<?=$builder_sidebar_data['icon']?>"></i></div>
                        <h4><?=__($builder_sidebar_data['label'], 'af2_multilanguage')?></h4>
                    </div>
                    <?php if($builder_sidebar_select_filter != null) { ?>
                    <div class="af2_builder_sidebar_select_filter">
                        <select style="padding: 0px 25px 0 10px !important;" class="<?=$builder_sidebar_select_filter['select_class']?>">
                            <option value="empty"><?=__($builder_sidebar_select_filter['empty_value'], 'af2_multilanguage')?></option>
                            <?php foreach($builder_sidebar_select_filter['selection_values'] as $option) { ?>
                                <option value="<?=$option['value']?>"><?=$option['label']?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <?php } ?>
                    <div class="af2_builder_sidebar_content_wrapper af2_builder_element af2_no_padding">
                        <?php foreach($builder_sidebar_content_elements as $builder_sidebar_content_element) { ?>
                        <div class="af2_builder_sidebar_content af2_builder_sidebar_element <?=$builder_sidebar_content_element_class?> <?=isset($builder_sidebar_content_element['icon']) ? 'af2_flex_sidebar_heading' : ''?>"
                        data-elementid="<?=$builder_sidebar_content_element['elementid']?>" data-selectvalue="<?=isset($builder_sidebar_content_element['select_value']) ? $builder_sidebar_content_element['select_value'] : null?>">
                            <?php if(isset($builder_sidebar_content_element['icon'])) { ?>
                                <i class="<?=$builder_sidebar_content_element['icon']?>"></i>
                            <?php } ?>
                            <h5 class="af2_builder_sidebar_content_heading"><?=__($builder_sidebar_content_element['label'], 'af2_multilanguage')?></h5>
                            <?php if(isset($builder_sidebar_content_element['image'])) { ?>
                            <div class="af2_builder_sidebar_image">
                                <img src="<?=plugins_url($builder_sidebar_content_element['image'], AF2_PLUGIN)?>">
                            </div>
                            <?php } ?>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>
        <?php if(isset($builder_filter_data)) { ?>
        <div class="af2_builder_sidebar colorOne leftSidebar <?=$builder_sidebar_select_filter != null ? 'af2_select_filter' : ''?>">
            <div>
                <div class="af2_builder_overflow-scroll">

                    <div class="af2_builder_sidebar_header af2_icon_text af2_builder_element">
                        <div class="af2_icon_wrapper colorPrimary"><i class="<?=$builder_sidebar_data['icon']?>"></i></div>
                        <h4><?=__($builder_sidebar_data['label'], 'af2_multilanguage')?></h4>
                    </div>
                    <?php if($builder_sidebar_select_filter != null) { ?>
                    <div class="af2_builder_sidebar_select_filter">
                        <select style="padding: 0px 25px 0 10px !important;" class="<?=$builder_sidebar_select_filter['select_class']?>">
                            <option value="empty"><?=__($builder_sidebar_select_filter['empty_value'], 'af2_multilanguage')?></option>
                            <?php foreach($builder_sidebar_select_filter['selection_values'] as $option) { ?>
                                <option value="<?=$option['value']?>"><?=$option['label']?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <?php } ?>
                    <div class="af2_builder_sidebar_content_wrapper af2_builder_element af2_no_padding">
                        <?php foreach($builder_sidebar_content_elements as $builder_sidebar_content_element) { ?>
                        <div class="af2_builder_sidebar_content af2_builder_sidebar_element <?=$builder_sidebar_content_element_class?> <?=isset($builder_sidebar_content_element['icon']) ? 'af2_flex_sidebar_heading' : ''?>"
                        data-elementid="<?=$builder_sidebar_content_element['elementid']?>" data-selectvalue="<?=isset($builder_sidebar_content_element['select_value']) ? $builder_sidebar_content_element['select_value'] : null?>">
                            <?php if(isset($builder_sidebar_content_element['icon'])) { ?>
                                <i class="<?=$builder_sidebar_content_element['icon']?>"></i>
                            <?php } ?>
                            <h5 class="af2_builder_sidebar_content_heading"><?=__($builder_sidebar_content_element['label'], 'af2_multilanguage')?></h5>
                            <?php if(isset($builder_sidebar_content_element['image'])) { ?>
                            <div class="af2_builder_sidebar_image">
                                <img src="<?=plugins_url($builder_sidebar_content_element['image'], AF2_PLUGIN)?>">
                            </div>
                            <?php } ?>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>
        <div class="af2_builder_content_wrapper">
            <div class="af2_builder_header af2_builder_element">
                <?php if($builder_pre_heading_buttons != null) { ?>
                    <div class="af2_builder_pre_heading_buttons">
                    <?php foreach($builder_pre_heading_buttons as $builder_pre_heading_button) { ?>
                        <div id="<?=$builder_pre_heading_button['id']?>" class="af2_btn af2_btn_primary"><i class="<?=$builder_pre_heading_button['icon']?>"></i></div>
                    <?php } ?>
                    </div>
                <?php } ?>
                <div class="af2_builder_header_heading af2_icon_text">
                    <div class="af2_icon_wrapper colorBlue"><i class="<?=$builder_heading['icon']?>"></i></div>
                    <h4><?=__($builder_heading['label'], 'af2_multilanguage')?></h4>
                </div>
                <div class="af2_builder_header_components">

                    <?php if(isset($menu_builder_pre_control_buttons)) { ?>
                        <?php foreach($menu_builder_pre_control_buttons as $button)  { ?>
                        <div id="<?=$button['id']?>" class="af2_btn af2_btn_primary">
                            <i class="<?=$button['icon']?>"></i>
                            <?=__($button['label'], 'af2_multilanguage')?></div>
                        <?php } ?>
                    <?php } ?>

                    <?php
                            $buttontext = __('Exit editor', 'af2_multilanguage');
                            $close_url = $close_editor_url;
                            if(isset($_GET['navigateBackBuilder']) && isset($_GET['navigateBackID'])) {
                                $buttontext = __('Back to Form-Editor', 'af2_multilanguage');
                                $close_url = admin_url('/admin.php?page='.$_GET['navigateBackBuilder'].'&id='.$_GET['navigateBackID']);
                            }
                    ?>
                    <a class="af2_btn_link" href="<?=$close_url?>">
                        <div id="af2_close_editor" class="af2_btn af2_btn_primary"><i class="fas fa-times-circle"></i><?=$buttontext?></div>
                    </a>
                    <?php if(isset($menu_builder_control_buttons)) { ?>
                        <?php foreach($menu_builder_control_buttons as $menu_builder_control_button)  { ?>
                        <div id="<?=$menu_builder_control_button['id']?>" class="af2_btn af2_btn_primary">
                            <i class="<?=$menu_builder_control_button['icon']?>"></i>
                            <?=__($menu_builder_control_button['label'], 'af2_multilanguage')?></div>
                        <?php } ?>
                    <?php } ?>
                    <div id="<?=$af2_own_save_button_id?>" class="af2_btn af2_btn_primary"><i class="fas fa-save"></i><?=__('Save', 'af2_multilanguage')?></div>
                </div>
            </div>

            <div class="dragscroll af2_builder_content af2_card <?= isset($builder_sidebar_data) ? '' : 'margin-lr' ?>">
                <div class="af2_card_block af2_builder_workspace">
                    <?php include $builder_template ?>
                </div>
            </div>
        </div>

        <?php if(isset($builder_sidebar_edit)) { ?>
        <div class="af2_builder_sidebar colorOne rightSidebar editSidebar hide">
            <div>
                <div class="af2_builder_overflow-scroll">
                    <div class="af2_builder_sidebar_header af2_icon_text af2_builder_element">
                        <div class="af2_btn af2_btn_primary af2_control_button unsummonEditSidebar"><i class="fas fa-times"></i></div>
                        <h4><?=__($builder_sidebar_edit['label'], 'af2_multilanguage')?></h4>
                    </div>
                    <div class="af2_builder_sidebar_content_wrapper af2_builder_element af2_no_padding">
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>
    </div>
</div>

<div id="af2_save_modal" class="af2_modal"
    data-class="af2_save_modal"
    data-target="af2_save_modal"
    data-sizeclass="moderate_size"
    data-bottombar="false"
    data-heading="<?=__('Error log', 'af2_multilanguage')?>"
    data-close="<?=__('Close', 'af2_multilanguage')?>">

  <!-- Modal content -->
  <div class="af2_modal_content">
    
  </div>
</div>
