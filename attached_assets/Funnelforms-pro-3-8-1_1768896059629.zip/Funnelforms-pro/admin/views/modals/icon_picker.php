<?php include AF2_ALL_ICONS_PATH; ?>

<div id="af2_fontawesome_iconpicker" class="af2_modal"
    data-class="af2_fontawesome_iconpicker"
    data-target="af2_fontawesome_iconpicker"
    data-sizeclass="full_size"
    data-bottombar="true"
    data-heading="<?=__('Select icon', 'af2_multilanguage')?>"
    data-close="<?=__('Close', 'af2_multilanguage')?>">

  <!-- Modal content -->
  <div class="af2_modal_content">
    <div class="af2_iconpicker_search_wrapper">
      <i class="fas fa-search"></i>
      <input type="text" id="af2_iconpicker_search" class="af2_iconpicker_search" placeholder="<?=__('Search...', 'af2_multilanguage')?>">
    </div>
    <div class="af2_iconpicker_table">
        <?php foreach($af2_all_font_awesome_icons as $icon) { ?>
            <div class="af2_iconpicker_icon" data-iconid="<?=$icon?>">
                <i class="<?=$icon?>"></i>
            </div>
        <?php } ?>
    </div>
  </div>

  <div class="af2_modal_bottombar">
    <div id="af2_iconpicker_save" class="af2_btn af2_btn_primary"><?=__('Save', 'af2_multilanguage')?></div>
  </div>

</div>