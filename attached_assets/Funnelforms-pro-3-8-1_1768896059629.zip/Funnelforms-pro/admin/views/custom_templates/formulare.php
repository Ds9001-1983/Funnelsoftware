<div id="af2_external_modal" class="af2_modal"
    data-class="af2_external_modal"
    data-target="af2_external_modal"
    data-sizeclass="max-w-md"
    data-heading="<?= __('External embed code', 'af2_multilanguage') ?>"
    data-close="<?= __('Close', 'af2_multilanguage') ?>">

    <!-- Modal content -->
    <div class="af2_modal_content">
        <h5 style="margin-bottom: 30px;"><?= __('Note: For security reasons, it is not possible to use the "File upload" question type via the external embedding. An upload via the external embedding does not work.', 'af2_multilanguage') ?></h5>
        <h5 class="mb15"><?= __("Copy this code into the code area for the header or footer of the website. If you have problems with the embedding, change the parameter: data-jquery-needed to 'false'.", 'af2_multilanguage') ?></h5>
        <div class="textarea_copy_field">
            <textarea id="af2_external_script_1" class="af2_copy_to_clipboard_element" rows="5" readonly></textarea>
            <div data-id="af2_external_script_1" class="af2_copy_to_clipboard_es clipboard icon af2_btn af2_btn_primary"><i class="fas fa-copy" aria-hidden="true"></i><?= __('Copy', 'af2_multilanguage') ?></div>
        </div>
        <div class="mb15"></div>
        <h5 class="mb15"><?= __('Copy this code to any place on the website where you want to embed Funnelforms.', 'af2_multilanguage') ?></h5>
        <div class="textarea_copy_field">
            <textarea id="af2_external_script_2" class="af2_copy_to_clipboard_element" readonly></textarea>
            <div data-id="af2_external_script_2" class="af2_copy_to_clipboard_es clipboard icon af2_btn af2_btn_primary"><i class="fas fa-copy" aria-hidden="true"></i><?= __('Copy', 'af2_multilanguage') ?></div>
        </div>
    </div>
</div>

<div id="af2_popup_modal" class="af2_modal"
    data-class="af2_popup_modal"
    data-target="af2_popup_modal"
    data-sizeclass="max-w-md"
    data-heading="<?= __('Show form in a popup', 'af2_multilanguage') ?>"
    data-close="<?= __('Close', 'af2_multilanguage') ?>">

    <!-- Modal content -->
    <div class="af2_modal_content">
        <h5 class="mb15"><?= __('Copy this shortcode into any position of your website to show up the Funnelform inside a popup. The popup function does not affect the conventional integration. You can use both functions simultaneously.', 'af2_multilanguage') ?></h5>
        <fieldset id="af2_popup_radio_chooser" class="af2_radio_chooser">
            <div class="af2_option_div">
                <input type="radio" name="popup" id="af2_popup_delay" value="af2_popup_choose_div_delay" data-hide="af2_popup_choose_div_click" checked>
                <label for="af2_popup_delay"><?= __('The popup appears after a delay', 'af2_multilanguage') ?></label>
            </div>
            <div class="af2_option_div">
                <input type="radio" name="popup" id="af2_popup_click" value="af2_popup_choose_div_click" data-hide="af2_popup_choose_div_delay">
                <label for="af2_popup_click"><?= __('The popup appears after clicking on a button', 'af2_multilanguage') ?></label>
            </div>
        </fieldset>
        <div class="af2_popup_choose_div mb30">
            <div class="af2_popup_choose_div_delay">
                <p class="mb15"><?= __('Delay in milliseconds (after this time the popup opens automatically):', 'af2_multilanguage') ?></p>
                <input type="text" id="af2_popup_delay_value" placeholder="1000">
            </div>
            <div class="af2_popup_choose_div_click af2_hide">
                <p class="mb15"><?= __('Button-Class (define a class, attached to an element on your website to open the popup):', 'af2_multilanguage') ?></p>
                <input type="text" id="af2_popup_click_value" placeholder="af2_popup_class">
            </div>
        </div>
        <div class="textarea_copy_field">
            <textarea id="af2_popup_script" class="af2_copy_to_clipboard_element" readonly></textarea>
            <div data-id="af2_popup_script" class="af2_copy_to_clipboard_es clipboard icon af2_btn af2_btn_primary"><i class="fas fa-copy" aria-hidden="true"></i><?= __('Copy', 'af2_multilanguage') ?></div>
        </div>
    </div>
</div>

<div id="af2_funnel_link_modal" class="af2_modal"
    data-class="af2_funnel_link_modal"
    data-target="af2_funnel_link_modal"
    data-sizeclass="max-w-md"
    data-heading="<?= __('Direct URL', 'af2_multilanguage') ?>"
    data-close="<?= __('Close', 'af2_multilanguage') ?>">
    <!-- Modal content -->
    <div class="af2_modal_content">
        <p id="af2_public_slug_message_private" class="mb30" style="display: none;"><?php echo __("This form is currently private.", 'af2_multilanguage'); ?></p>
        <div id="af2_public_slug_message_public" class="mb30" style="display: none;"><p><?php echo __("This form is currently public.", 'af2_multilanguage'); ?></p><button class="af2_btn af2_btn_primary" id="af2-remove-public-slug"><?php echo __("Make private", 'af2_multilanguage'); ?></button></div>
        <p id="af2_public_slug_error" class="mb30" style="display: none;"><?php echo __("This form is currently public.", 'af2_multilanguage'); ?></p>
        
        
        <label for="af2_public_slug"><h5 class="mb15"><?= __('Public URL', 'af2_multilanguage') ?></h5></label>
        <p style="margin-bottom: 15px"><?= __('Create a link to display this form directly as a standalone page.', 'af2_multilanguage') ?></p>
        <div class="af2-public-slug-input-wrapper mb15">
            <span class="af2-public-slug-input-prefix"><?php echo site_url(); ?>/funnelforms/</span>
            <input class="af2-public-slug-input" type="text" id="af2_public_slug" name="af2_public_slug" value="" />
            <input type="text" value="" id="af2-public-slug-full-url" class="af2_copy_to_clipboard_element af2-public-slug-full-url-hidden" />
            <button data-id="af2-public-slug-full-url" class="af2_copy_to_clipboard_es clipboard icon af2_btn af2_btn_secondary"><i class="fas fa-copy" aria-hidden="true"></i><?= __('Copy', 'af2_multilanguage') ?></button>
        </div>
        <button id="af2-save-public-slug" type="button" class="af2_btn af2_btn_primary"><?= __('Publish', 'af2_multilanguage') ?></button>
    </div>
</div>