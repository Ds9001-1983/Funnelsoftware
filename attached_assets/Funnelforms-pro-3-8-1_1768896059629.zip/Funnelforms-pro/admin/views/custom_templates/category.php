<div id="modal-categories" class="af2_modal"
data-class="modal-categories"
data-target="modal-categories"
data-sizeclass="moderate_big_size"
data-bottombar="false"
data-urlopen="show_category_modal"
data-heading="<?=__('Edit categories', 'af2_multilanguage')?>"
data-close="<?=__('Close', 'af2_multilanguage')?>">

    <!-- Modal content -->
    <div class="af2_modal_content">
        <p style="margin-bottom: 20px;"><?=__('Categories always have to be unique and can not have the same title. If a category gets deleted the question will stay but they change their state to not assigned.', 'af2_multilanguage')?></p>
        <div class="af2_add_category">
            <input class="af2_add_category_input" placeholder="<?=__('Add category', 'af2_multilanguage')?>" type="text"/>
            <button class="add_category af2_btn af2_btn_primary"><?=__('Add', 'af2_multilanguage')?></button>
        </div>
        <div class="af2_category_list">
        <?php 
        foreach($menu_functions_select['options'] as $option) { 
            ?>            
            <div class="af2_category" id="<?=$option['value']?>">
                <div class="af2_category_title"><h5><?=$option['label']?></h5></div>
                <button class="af2_category_delete af2_btn af2_btn_primary"><?=__('Delete', 'af2_multilanguage')?></button>
            </div>            
            <?php 
        }
        ?>   
        </div>     
    </div>
</div>