<div class="af2_custom_builder_wrapper af2_formularbuilder_preview">
    <?= do_shortcode('[funnelforms id="'.$_GET['id'].'" preview="true"]') ?>
</div>