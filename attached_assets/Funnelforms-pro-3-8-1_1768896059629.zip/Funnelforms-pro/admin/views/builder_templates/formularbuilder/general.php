<div class="af2_form_builder_wrapper_general">
    <div id="af2_form_questions_container" data-zoomlevel="5" class="af2_form_questions_container af2_zoom_container af2_array_draggable_restrict af2_add_array_draggable_restrict af2_array_dropzone_in" data-arrayid="0">
        <svg width="100%" height="100%" class="af2_draw_svg">
        </svg>

        <div class="af2_form_question af2_start af2_no_delete af2_no_position af2_no_remove"
        data-elementid="0"
        data-saveobjectid="all_entries"
        data-deletetriggerid="af2_form_questions_container"
        data-x="1020.1734130859379" data-y="564.0643310546867" data-translationx="1020.1734130859379" data-translationy="564.0643310546867"
        data-formquestionentryid="-1">
            <div class="af2_form_question_heading">
                <h5><?=__('Start', 'af2_multilanguage')?></h5>
                <div class="af2_form_question_connect_dot af2_line_draggable af2_form_question_connect_dot_general" data-lineid="-1" data-formquestionentryid="-1">
                    <div class="af2_form_question_connect_dot_fill"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="af2_interface_modal" class="af2_modal"
    data-class="af2_interface_modal"
    data-target="af2_interface_modal"
    data-sizeclass="moderate_big_size"
    data-bottombar="false"
    data-heading="<?=__('Edit integration', 'af2_multilanguage')?>"
    data-close="<?=__('Save', 'af2_multilanguage')?>">

  <!-- Modal content -->
  <div class="af2_modal_content">
    
  </div>
</div>
