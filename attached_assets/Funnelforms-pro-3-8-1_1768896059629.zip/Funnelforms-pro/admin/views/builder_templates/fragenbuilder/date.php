<div id="af2_date_wrapper" class="af2_builder_editable_object af2_date_wrapper" data-editcontentid="date">
    <div id="af2_date" class="af2_date"></div>
    <div class="af2_date_form_wrapper">
        <div class="af2_date_form_heading">
            <h5><?=__('March', 'af2_multilanguage')?></h5>
        </div>
        <div class="af2_date_form_body">
            <div class="af2_date_form_days">
                <div class="af2_date_form_days_content af2_date_form_content_heading"><?=__('Mo', 'af2_multilanguage')?></div>
                <div class="af2_date_form_days_content af2_date_form_content_heading"><?=__('Tu', 'af2_multilanguage')?></div>
                <div class="af2_date_form_days_content af2_date_form_content_heading"><?=__('We', 'af2_multilanguage')?></div>
                <div class="af2_date_form_days_content af2_date_form_content_heading"><?=__('Th', 'af2_multilanguage')?></div>
                <div class="af2_date_form_days_content af2_date_form_content_heading"><?=__('Fr', 'af2_multilanguage')?></div>
                <div class="af2_date_form_days_content af2_date_form_content_heading"><?=__('Sa', 'af2_multilanguage')?></div>
                <div class="af2_date_form_days_content af2_date_form_content_heading"><?=__('Su', 'af2_multilanguage')?></div>
            </div>
            <div class="af2_date_form_days">
                <div class="af2_date_form_days_content af2_date_form_content_day"></div>
                <div class="af2_date_form_days_content af2_date_form_content_day">1</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">2</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">3</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">4</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">5</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">6</div>
            </div>
            <div class="af2_date_form_days">
                <div class="af2_date_form_days_content af2_date_form_content_day">7</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">8</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">9</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">10</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">11</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">12</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">13</div>
            </div>
            <div class="af2_date_form_days">
                <div class="af2_date_form_days_content af2_date_form_content_day">14</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">15</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">16</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">17</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">18</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">19</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">20</div>
            </div>
            <div class="af2_date_form_days">
                <div class="af2_date_form_days_content af2_date_form_content_day">21</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">22</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">23</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">24</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">25</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">26</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">27</div>
            </div>
            <div class="af2_date_form_days">
                <div class="af2_date_form_days_content af2_date_form_content_day">28</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">29</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">30</div>
                <div class="af2_date_form_days_content af2_date_form_content_day">31</div>
                <div class="af2_date_form_days_content af2_date_form_content_day"></div>
                <div class="af2_date_form_days_content af2_date_form_content_day"></div>
                <div class="af2_date_form_days_content af2_date_form_content_day"></div>
            </div>
        </div>
    </div>
</div>