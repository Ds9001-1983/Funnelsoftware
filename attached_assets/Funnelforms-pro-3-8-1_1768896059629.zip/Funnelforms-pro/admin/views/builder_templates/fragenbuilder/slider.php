<div id="af2_slider_wrapper" class="af2_builder_editable_object af2_slider_wrapper" data-editcontentid="slider">
    <div class="af2_hide" id="af2_slider_label_wrapper" class="af2_slider_label_wrapper"></div>
    <div class="af2_slider_start">
        <h3 id="af2_slider_start_value" class="af2_slider_start_value"></h3>
    </div>
    <div class="af2_slider_flex_wrapper">
        <div class="af2_slide_no_image">
            <div class="af2_slider">
                <div class="af2_slide_dot"></div>
            </div>
            <div class="af2_slider_values">
                <div class="af2_slider_min">
                    <h4 id="af2_slider_value_min" class="af2_slider_value_min"></h4>
                </div>
                <div class="af2_slider_max">
                    <h4 id="af2_slider_value_max" class="af2_slider_value_max"></h4>
                </div>
            </div>
        </div>
        <div id="af2_slider_image" class="af2_slider_image"></div>
    </div>
    <div id="af2_slider_alternate_input" class="af2_slider_alternate_input">
        <div id="af2_slider_alternate_label" class="af2_slider_alternate_label"></div>
        <div class="af2_input"></div>
    </div>
</div>