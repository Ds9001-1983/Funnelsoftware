<div id="af2_dropdown_wrapper" class="af2_dropdown_wrapper">
    <div id="af2_dropdown" class="af2_dropdown">
        <div id="af2_dropdown_element_container" class="af2_dropdown_element_container">
            
            <div id="af2_dropdown_wrapper_add" class="af2_dropdown_wrapper_add af2_btn af2_btn_primary">
                <i class="fas fa-plus"></i>
                <?=__('Add Element', 'af2_multilanguage')?>
            </div>
        </div>
    </div>
</div>

<div id="af2_delete_answer_modal" class="af2_modal"
    data-class="af2_delete_answer_modal"
    data-target="af2_delete_answer_modal"
    data-sizeclass="moderate_size"
    data-bottombar="true"
    data-confirmationid="af2_confirm_deletion"
    data-heading="<?=__('Confirm deletion?', 'af2_multilanguage')?>"
    data-close="<?=__('Cancel', 'af2_multilanguage')?>">

  <!-- Modal content -->
  <div class="af2_modal_content">
        <p><?=__( 'This answer may be linked in an active form. Please confirm that you want to delete this answer. We recommend you to check the connections in your forms.', 'af2_multilanguage')?></p>
    </div>

    <div class="af2_modal_bottombar">
        <div id="af2_confirm_deletion" class="af2_btn af2_btn_secondary_outline"><?=__('Delete', 'af2_multilanguage')?></div>
    </div>
</div>
