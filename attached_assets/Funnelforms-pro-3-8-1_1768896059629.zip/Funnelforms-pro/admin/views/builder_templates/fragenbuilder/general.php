<div class="af2_question_type_wrapper_general">
    <div class="af2_question_type_wrapper_general_content">
        <h3 id="af2_question_type_heading" class="af2_builder_editable_object" data-editcontentid="heading"></h3>
        <h5 id="af2_question_type_description" class="af2_builder_editable_object" data-editcontentid="description"></h5>
    </div>

    <div class="af2_question_type_wrapper_custom_content">

    </div>
</div>

<?php include AF2_ICON_PICKER_MODAL_PATH ?>