<div id="af2_file_upload" class="af2_builder_editable_object af2_file_upload" data-editcontentid="file_upload">
    <div class="af2_file_upload_inner">
        <i class="fa fa-cloud-upload-alt"></i>
        <div id="af2_file_upload_description" class="af2_file_upload_description"></div>
    </div>
</div>