<div id="af2_answers_container" class="af2_answers_container af2_array_dropzone_before af2_array_draggable_restrict">
    <div id="af2_answer_wrapper_add">
        <i class="fas fa-plus"></i>
    </div>
</div>
