<div id="af2_adress_feld_inp" class="af2_builder_editable_object af2_adress_mapp_wrapper" data-editcontentid="map" style="display: flex;">
    <div id="af2_address_start_location" class="af2_hide"></div>
    <div id="af2_address_zoom" class="af2_hide"></div>
    <div id="af2_combined_adress" class="af2_hide"></div>
    <div class="af2_adress_map_input_wrapper standard">
        <div class="af2_adress_map_input_wrapper_fields">
            <div class="af2_adress_input_wrap size8">
                <p class="af2_address_input_label"><?= __('Street', 'af2_multilanguage') ?></p>
                <div class="af2_address_input_input"></div>
            </div>
            <div class="af2_adress_input_wrap size2">
                <p class="af2_address_input_label"><?= __('No.', 'af2_multilanguage') ?></p>
                <div class="af2_address_input_input"></div>
            </div>
        </div>
        <div class="af2_adress_map_input_wrapper_fields">
            <div class="af2_adress_input_wrap size4">
                <p class="af2_address_input_label"><?= __('Postcode', 'af2_multilanguage') ?></p>
                <div class="af2_address_input_input"></div>
            </div>
            <div class="af2_adress_input_wrap size6">
                <p class="af2_address_input_label"><?= __('City', 'af2_multilanguage') ?></p>
                <div class="af2_address_input_input"></div>
            </div>
        </div>
        <div id="af2_adress_map_input_country_wrap" class="af2_adress_map_input_wrapper_fields">
            <div class="af2_adress_input_wrap size10">
                <p class="af2_address_input_label"><?= __('Country', 'af2_multilanguage') ?></p>
                <div class="af2_address_input_input"></div>
            </div>
        </div>
    </div>
    <div class="af2_adress_map_input_wrapper combined">
        <div class="af2_adress_map_input_wrapper_fields">
            <div class="af2_adress_input_wrap" style="width: 100%">
                <p class="af2_address_input_label"><?= __('Address', 'af2_multilanguage') ?></p>
                <div class="af2_address_input_input"></div>
            </div>
        </div>
    </div>
    <div id="af2_backend_map" class="af2_hide" style="min-width: 400px;min-height:400px;"></div>
</div>