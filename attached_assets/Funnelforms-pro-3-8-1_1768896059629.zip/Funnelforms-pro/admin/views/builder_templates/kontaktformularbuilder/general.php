<div class="af2_contact_form_wrapper_general">
    <div class="af2_contact_form_wrapper_general_content">
        <h3 id="af2_contact_form_heading" class="af2_builder_editable_object" data-editcontentid="heading"></h3>
        <h5 id="af2_contact_form_description" class="af2_builder_editable_object" data-editcontentid="description"></h5>
    </div>

    <div class="af2_contact_form_wrapper_custom_content">
        <div id="af2_questions_container" class="af2_questions_container af2_array_dropzone_before af2_array_draggable_restrict af2_add_array_draggable_restrict">
            
        </div>
    </div>

    <div class="contact_form_send_button_wrapper af2_builder_editable_object mt30" data-editcontentid="send_button">
        <div class="af2_btn af2_btn_primary">
            <i class="fa fa-paper-plane"></i><span id="af2_contact_form_send_button"></span>
        </div>
    </div>
</div>


<?php include AF2_ICON_PICKER_MODAL_PATH ?>