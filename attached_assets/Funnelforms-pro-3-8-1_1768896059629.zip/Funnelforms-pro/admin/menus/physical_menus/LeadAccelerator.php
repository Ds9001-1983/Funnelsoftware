<?php

require_once AF2_MENU_PARENTS_CLASS;
class Af2LeadAccelerator extends Af2MenuCustom {

    public $healthchecks = [];

    protected function get_heading() { return 'Lead Accelerator'; }
    protected function get_menu_custom_template() { return AF2_CUSTOM_MENU_LEADACCELERATOR; }

    protected function load_resources() {
        wp_enqueue_style('af2_leadaccelerator_style');

        parent::load_resources();
    }
}
