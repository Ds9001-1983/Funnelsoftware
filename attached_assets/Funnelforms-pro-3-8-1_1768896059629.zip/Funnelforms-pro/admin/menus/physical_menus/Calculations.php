<?php

require_once AF2_MENU_PARENTS_CLASS;
class Af2Calculations extends Af2MenuTable {

    public $pagination = false;

    protected function get_heading() { return 'Calculations'; }
    protected function get_menu_action_button_add_post_() { return array('page' => CALCULATIONS_SLUG, 'post_type' => CALCULATION_POST_TYPE, 'builder' => CALCULATIONBUILDER_SLUG); }
    protected function get_menu_functions_search_() { return 'Name'; }
    protected function get_menu_action_button_copy_posts_() { return true; }
    protected function get_menu_action_button_delete_posts_() { return true; }
    protected function get_post_type_constant() { return CALCULATION_POST_TYPE; }
    protected function get_table_builder_load_array_() { return array( 'page' => CALCULATIONBUILDER_SLUG, 'id_label' => 'ID'); }
    protected function get_table_columns() {
        return array(
            array( 'lable' => 'ID', 'translate' => false, 'highlight' => true,                  'width' => '110px', 'flex' => '',  'max-width' => '', 'min-width' => '', 'button' => false, 'uid' => true, 'url' => true),
            array( 'lable' => 'Name', 'translate' => true, 'highlight' => false,                'width' => '',      'flex' => '1', 'max-width' => '', 'min-width' => '', 'button' => false, 'uid' => false, 'url' => true),
            array( 'lable' => 'Author', 'translate' => false, 'highlight' => false,      'width' => '',      'flex' => '0.5',  'min-width' => '', 'max-width'=> '', 'button' => false, 'uid' => false),
        );
    }

    protected function edit_posts_for_table($posts) {
        $new_posts = array();

        require_once AF2_MISC_FUNCTIONS_PATH;

        foreach($posts as $post) {

            $post_content = af2_get_post_content($post);
            $new_post = array();
            $new_post['ID'] = get_post_field('ID', $post );
            $new_post['Name'] = $post_content['title'];
            $new_post['Author'] = get_the_author_meta( 'display_name', get_post_field('post_author', $post ) );

            array_push($new_posts, $new_post);
        }

        return $new_posts;
    }
}
