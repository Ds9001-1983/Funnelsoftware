<?php

require_once AF2_MENU_PARENTS_CLASS;

class Af2Calculationbuilder extends Af2MenuBuilder {

    protected function get_builder_heading() { return array('label' => 'Calculation editor', 'icon' => 'fas fa-edit'); }
    protected function get_builder_template() { return AF2_CALCULATION_TYPE_GENERAL; }
    protected function get_close_editor_url() { return admin_url('/admin.php?page='.CALCULATIONS_SLUG ); }
    protected function get_menu_builder_control_buttons_() { return array(array('id' => 'af2_create_new_calculation', 'icon' => 'fas fa-plus', 'label' => 'New calculation')); }
    protected function get_builder_script() { return 'af2_calculationbuilder'; }
    protected function get_builder_style() { return 'af2_calculationbuilder_style'; }
    protected function get_builder_script_object_name() { return 'af2_calculationbuilder_object';  }
    protected function get_builder_script_localize_array() { 
        $locale = get_locale();

        return array(
            'name' => "Calculation",
            'create_new_calculation_url' => admin_url('/admin.php?page='.CALCULATIONS_SLUG.'&action=af2CreatePost&custom_post_type='.CALCULATION_POST_TYPE.'&redirect_slug='.CALCULATIONBUILDER_SLUG.'&time='.time()),
        );
    }
    protected function load_resources() {
        wp_enqueue_script('af2_calculations');

        wp_localize_script( 'af2_menu_components', 'af2_menu_components_object', array(
            'ajax_url' => admin_url( 'admin-ajax.php'),
            'dark_mode' => get_option('af2_dark_mode'),
        ));

        parent::load_resources();
    }
    protected function get_builder_sidebar_edit_() { return array('label' => 'Settings'); }
    protected function get_builder_sidebar_edit_elements_() {
        require_once AF2_MENU_CALCULATIONBUILDER_ELEMENTS_PATH;
        return get_calculationbuilder_elements();
    }
    protected function get_af2_builder_custom_contents_() {

        $posts = $this->Admin->af2_get_posts(FRAGE_POST_TYPE);
        $form_id = isset($_GET['form_id']) ? $_GET['form_id'] : 'all';

        $questionIds = [];
        $response = [];

        if($form_id !== 'all') {
            $the_form = af2_get_post_content($form_id);
            $the_form = json_decode(json_encode($the_form));
            foreach($the_form->all_entries as $entry) {
                $id = $entry->elementid;
                $post = get_post($id);
                if($post->post_type == 'af2_frage') {
                    $questionIds[] = $id;
                }
            }
        } else {
            $questionIds = $posts;
        }

        foreach($questionIds as $questionId) {
            $post_content = af2_get_post_content($questionId);
            $qid = $questionId;
            if(!is_int($questionId)) {
                $qid = $questionId->ID;
            }
            if($post_content['typ'] == 'af2_select') {
                $response[$qid] = $post_content;
            }
            else if($post_content['typ'] == 'af2_textfeld') {
                if($post_content['text_only_numbers']) {
                    $response[$qid] = $post_content;
                }
            }
            else if($post_content['typ'] == 'af2_dropdown') {
                $response[$qid] = $post_content;
            }
            else if($post_content['typ'] == 'af2_slider') {
                $response[$qid] = $post_content;
            }
        }

        return array(
            'questions' => $response,
        );
    }
    public static function save_function($content) {
        $own_content = $content;
        $echo_content = array();

        if(!isset($own_content['title']) || trim($own_content['title']) == '') {
            array_push($echo_content, array('label' => __('No title specified!', 'af2_multilanguage'), 'type' => 'af2_error', 'error_object' => '#af2_calculation_type_heading'));
        }

        if(!isset($own_content['formula_decimal_count']) || !is_numeric($own_content['formula_decimal_count']) || intval($own_content['formula_decimal_count']) < 0 || intval($own_content['formula_decimal_count']) > 10) {
            array_push($echo_content, array('label' => __('Invalid decimal count! Please enter a number between 0 and 10.', 'af2_multilanguage'), 'type' => 'af2_error'));
        }

        $own_content['error'] = false;

        foreach( $echo_content as $content ) {
            if($content['type'] == 'af2_error') {
                $own_content['error'] = true;
                break;
            }
        }

        array_push($echo_content, array('label' => __('Saved successfully!', 'af2_multilanguage'), 'type' => 'af2_success'));

        echo json_encode($echo_content);
        return $own_content;
    }
    protected function get_menu_functions_select_() {

        $posts = $this->Admin->af2_get_posts(FORMULAR_POST_TYPE);

        $all_forms = array();

        require_once AF2_MISC_FUNCTIONS_PATH;
        foreach($posts as $post) {
            $id = get_post_field( 'ID', $post );

            $post_content = af2_get_post_content($post);

            // remove warnigns
            $title = isset($post_content['name']) && !empty($post_content['name']) ? $post_content['name'] : __('Form title', 'af2_multilanguage');

            array_push($all_forms, array('value' => $id, 'label' => $title));
        }

        return array(
            'title' => __('Select form:', 'af2_multilanguage'),
            'id' => 'form_id_chooser',
            'getattribute' => 'form_id',
            'link' => admin_url('/admin.php?page='.CALCULATIONBUILDER_SLUG),
            'selected' => isset($_GET['form_id']) ? $_GET['form_id'] : 'all',
            'all_label' => __('All forms', 'af2_multilanguage'),
            'options' => $all_forms,
        );
    }
}
