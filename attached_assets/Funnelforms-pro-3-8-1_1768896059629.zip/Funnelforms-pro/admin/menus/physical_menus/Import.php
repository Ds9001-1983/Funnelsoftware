<?php

require_once AF2_MENU_PARENTS_CLASS;
class Af2ImportExport extends Af2MenuCustom {

    protected function get_heading() { return 'Import & Export'; }
    protected function get_menu_custom_template() { return AF2_CUSTOM_MENU_IMPORT_EXPORT; }
    
    protected function load_resources() {
        wp_enqueue_style('af2_import_export_style');
        wp_localize_script( 'af2_import_export', 'af2_import_object', array(
            'strings' => array(
                'success' => __('Imported successfully', 'af2_multilanguage'),
                'import' => __('Import', 'af2_multilanguage'),
                'wait' => __('Please wait', 'af2_multilanguage'),
            ),
        ));
        wp_enqueue_script('af2_import_export');

        parent::load_resources();
    }

}