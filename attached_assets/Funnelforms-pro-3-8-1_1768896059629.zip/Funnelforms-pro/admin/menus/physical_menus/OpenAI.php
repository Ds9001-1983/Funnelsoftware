<?php

require_once AF2_MENU_PARENTS_CLASS;

class Af2OpenAI extends Af2MenuCustom {

    protected function get_heading() { return 'Funnelforms AI'; }
    protected function get_menu_custom_template() { return AF2_CUSTOM_MENU_OPENAI; }

    protected function get_af2_custom_contents_() { 
        $this->load_resources();
        return '';
    }

    protected function load_resources() {
        $this->initialize_ai_form();
        parent::load_resources();
    }

    protected function initialize_ai_form() {
        $form_id = get_option('af2_openai_form_id');

        $locale = get_locale();
        $language_form = AI_EN_FORM;
        if($locale == 'de_DE') {
            $language_form = AI_DE_FORM;
        }

        if($form_id == '' || get_post_field( 'post_type', $form_id ) != AI_FORMULAR_POST_TYPE || get_option('af2_openai_form_language') != $locale) {
            update_option('af2_openai_form_language', $locale);
            $this->import_form($language_form);
        }
    }

    protected function import_form($language_form) {
        require_once $language_form;

        $toImport = unserialize(urldecode($af2_ai_form));
        if (is_array($toImport) && !empty($toImport)) {
            $import_data_ids = array();
            $import_data_form_ids = array();

            foreach ($toImport as $data) {
                $post_type = AI_FRAGE_POST_TYPE;
                $data->post_content = unserialize(urldecode($data->post_content));
                if($data->post_type == FRAGE_POST_TYPE) {
                    $i = 0;
                    if(isset($data->post_content['answers'])) {
                        foreach($data->post_content['answers'] as $answer) {
                            if(af2_str_contains($answer['img'], 'http')) {
                                if(af2_str_contains($answer['img'], 'Single' )) $data->post_content['answers'][$i]['img'] = plugins_url('/res/images/openai/single.png', AF2_PLUGIN);
                                else if(af2_str_contains($answer['img'], 'Multi' )) $data->post_content['answers'][$i]['img'] = plugins_url('/res/images/openai/multi.png', AF2_PLUGIN);
                                else if(af2_str_contains($answer['img'], 'Text' )) $data->post_content['answers'][$i]['img'] = plugins_url('/res/images/openai/text.png', AF2_PLUGIN);
                                else if(af2_str_contains($answer['img'], 'Date' )) $data->post_content['answers'][$i]['img'] = plugins_url('/res/images/openai/date.png', AF2_PLUGIN);
                                else if(af2_str_contains($answer['img'], 'Slider' )) $data->post_content['answers'][$i]['img'] = plugins_url('/res/images/openai/slider.png', AF2_PLUGIN);
                                else if(af2_str_contains($answer['img'], 'File-Upload' )) $data->post_content['answers'][$i]['img'] = plugins_url('/res/images/openai/upload.png', AF2_PLUGIN);
                                else if(af2_str_contains($answer['img'], 'Dropdown' )) $data->post_content['answers'][$i]['img'] = plugins_url('/res/images/openai/dropdown.png', AF2_PLUGIN);
                                else if(af2_str_contains($answer['img'], 'Address' )) $data->post_content['answers'][$i]['img'] = plugins_url('/res/images/openai/address.png', AF2_PLUGIN);
                            }
                            $i++;
                        }
                    }
                    $post_type = AI_FRAGE_POST_TYPE;
                }
                else if($data->post_type == KONTAKTFORMULAR_POST_TYPE) {
                    $post_type = AI_KONTAKTFORMULAR_POST_TYPE;
                }
                else if($data->post_type == FORMULAR_POST_TYPE) {
                    $post_type = AI_FORMULAR_POST_TYPE;
                }

                $data->post_content = urlencode(serialize($data->post_content));
                $id = wp_insert_post( array('post_content' => $data->post_content, 'post_status' => 'privat', 'post_type' => $post_type) );

                array_push($import_data_ids, array('old' => $data->id, 'new' => $id));
                if($data->post_type == FORMULAR_POST_TYPE) array_push($import_data_form_ids, $id);
            }
            foreach($import_data_form_ids as $form) {
                $form_content = unserialize(urldecode(get_post_field( 'post_content', $form )));

                if(isset($form_content['all_entries']) && !empty($form_content['all_entries']) && sizeof($form_content['all_entries']) > 1) {
                    for ($i=0; $i < sizeof($form_content['all_entries']); $i++) { 
                        $entry = $form_content['all_entries'][$i];
                        $import_data_id_array = array_filter($import_data_ids, function($var) use ($entry) { return $var['old'] == $entry['elementid']; });
                        if(sizeof($import_data_id_array) < 1) continue;

                        $import_data_id = array_shift($import_data_id_array);

                        $form_content['all_entries'][$i]['elementid'] = $import_data_id['new'];
                    }
                }

                if(isset($form_content['sections']) && !empty($form_content['sections'])) {
                    for ($i=0; $i < sizeof($form_content['sections']); $i++) { 
                        if(isset($form_content['sections'][$i]['contents']) && !empty($form_content['sections'][$i]['contents'])) {
                            for ($j=0; $j < sizeof($form_content['sections'][$i]['contents']); $j++) { 
                                $entry = $form_content['sections'][$i]['contents'][$j];
                                $import_data_id_array = array_filter($import_data_ids, function($var) use ($entry) { return $var['old'] == $entry['data']; });
                                if(sizeof($import_data_id_array) < 1) continue;

                                $import_data_id = array_shift($import_data_id_array);

                                $form_content['sections'][$i]['contents'][$j]['data'] = $import_data_id['new'];
                            }
                        }
                    }
                }

                wp_update_post( array('ID' => $form,'post_content' => urlencode(serialize($form_content)) ) );
                update_option('af2_openai_form_id', $form);
            }
        }
    }
}
class OpenAIView {

    private $frontend_id = 0;
    private $current_locale = null;

    /**
     * FrontendView constructor
     */
    public function __construct() {
        $this->current_locale = get_user_locale() ;
    }

    function af2_generate_frontend($atts) {
        $atts = shortcode_atts( array(
            'id' => 0,
        ), $atts, 'funnelforms' );
        return $this->_af2_generate_frontend($atts);
    }

    /**
     * The function to generate the base construct of the frontend
     *
     * @param $atts
     * @return string
     */
    function _af2_generate_frontend($atts) {


        require_once AF2_RESOURCE_HANDLER_PATH;
        $dataid = $atts['id'];                                                            // The Dataid of the Formular
        $base_post = get_post($dataid);                                                   // The post of it out of DB
        require_once AF2_MISC_FUNCTIONS_PATH;
        $base_json = af2_get_post_content($base_post);             

        $base_json = json_decode(json_encode($base_json));


        global $wp_locale_switcher;
        if(isset($base_json->fe_locale) && $base_json->fe_locale !== "default") {
            $wp_locale_switcher->switch_to_locale( $base_json->fe_locale );
        }
        else if(strpos(get_locale(), 'de_') !== false) {
            $wp_locale_switcher->switch_to_locale( 'de_DE' );
        }

        af2_load_ai_resources();


        wp_localize_script('af2_frontend_ai', 'af2_frontend_ajax', // Localizing the Script to use ajax loading
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('af2_FE_nonce'),
                'strings' => array(
                    'antworten_tag' => __('[ANSWERS]', 'af2_multilanguage'),
                    'error_01' => __('ERROR - [01] Ajax error (caching error, please contact support)!', 'af2_multilanguage'),
                    'fehler_admin' => __('An error has occurred! If you are an administrator of this website, you can find more information here:', 'af2_multilanguage'),
                    'fehler_find' => __('An error has occurred! Please check your questions, contact forms and forms for completeness!', 'af2_multilanguage'),
                    'help' => __('Get help', 'af2_multilanguage'),
                    'help_url' => __('https://help.funnelforms.io/das-formular-wird-auf-der-website-nicht-angezeigt/', 'af2_multilanguage'),
                    'erroroccured' => __('An error has occurred!', 'af2_multilanguage'),
                    'sms' => __('SMS verification', 'af2_multilanguage'),
                    'sms_sent' => __('A verification code was sent via SMS to the following number:', 'af2_multilanguage'),
                    'sms_change' => __('Change number', 'af2_multilanguage'),
                    'sms_repeat' => __('Send again', 'af2_multilanguage'),
                    'sms_verify' => __('Verify', 'af2_multilanguage'),
                    'country_search_placeholder' => __('Search for country or dial code', 'af2_multilanguage'),
                    'dot' => __(',', 'af2_multilanguage'),
                    'form_sent' => __('FORM SENT', 'af2_multilanguage'),
                    'street' => __('Street', 'af2_multilanguage'),
                    'no' => __('No.', 'af2_multilanguage'),
                    'postcode' => __('Postcode', 'af2_multilanguage'),
                    'city' => __('City', 'af2_multilanguage'),
                    'resend' => __('Send again', 'af2_multilanguage'),
                    'choosedur' => __('Select duration of appointment', 'af2_multilanguage'),
                    'choosedurdot' => __('Select duration of appointment:', 'af2_multilanguage'),
                    'choosetime' => __('Select time of appointment', 'af2_multilanguage'),
                    'choosetimedot' => __('Select time of appointment:', 'af2_multilanguage'),
                    'noappointments' => __('No appointments available on this day!', 'af2_multilanguage'),
                    'mr' => __('Mr.', 'af2_multilanguage'),
                    'mrs' => __('Mrs.', 'af2_multilanguage'),
                    'diverse' => __('Diverse', 'af2_multilanguage'),
                    'company' => __('Company', 'af2_multilanguage'),
                )
            )
        );

        wp_enqueue_script('af2_jQuery_ui');
        wp_enqueue_script('af2_frontend_ai');
        wp_enqueue_script('af2_select');
        wp_enqueue_style('af2_select_style');
        wp_enqueue_style('af2_fa_style');
        wp_enqueue_style('af2_frontend_style_usual');

        
        $content = '';                         // Content to draw

        //$loading_path = plugins_url(AF2_LOADING_GIF, AF2_PLUGIN);


        /** Check if license is active * */
        if (get_option('af2_license_stat') === 'Die Domain ist aktiviert!') {
            /** Fetching Data from the given "Formular" * */

            if ($base_json != null) {
                if(isset($base_json->error) && $base_json->error) return __('Your form has an error', 'af2_multilanguage');
                $size = sizeof($base_json->sections);                  // The maximum amount of steps

                $fe_title = isset($base_json->styling->fe_title) ? $base_json->styling->fe_title : '';                 // Frontent-Title of Formular
                
                $loader_color = !empty($base_json->styling->form_loader_color)?$base_json->styling->form_loader_color:'rgba(0, 0, 0, 1)';
                
                $back_btn_style_class = '';
                $forward_btn_style_class = '';
                
                $rtl_layout = false;
                if(isset($base_json->rtl_layout) && $base_json->rtl_layout != '') {
                    $rtl_layout = $base_json->rtl_layout;
                }
                

                if(!$rtl_layout)
                {
                    if(!empty($base_json->styling->global_prev_text)){
                        $back_btn_text = $base_json->styling->global_prev_text;
                        $back_btn_style_class = 'special';
                    }else if(isset($base_json->showFontAwesome) && $base_json->showFontAwesome){
                        $back_btn_text = '<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="long-arrow-alt-left" class="svg-inline--fa fa-long-arrow-alt-left fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M134.059 296H436c6.627 0 12-5.373 12-12v-56c0-6.627-5.373-12-12-12H134.059v-46.059c0-21.382-25.851-32.09-40.971-16.971L7.029 239.029c-9.373 9.373-9.373 24.569 0 33.941l86.059 86.059c15.119 15.119 40.971 4.411 40.971-16.971V296z"></path></svg>';
                        //$back_btn_text = '<i class="fas fa-long-arrow-alt-left fa-lg"></i>';
                    }else{
                        $back_btn_text = '<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="long-arrow-alt-left" class="svg-inline--fa fa-long-arrow-alt-left fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M134.059 296H436c6.627 0 12-5.373 12-12v-56c0-6.627-5.373-12-12-12H134.059v-46.059c0-21.382-25.851-32.09-40.971-16.971L7.029 239.029c-9.373 9.373-9.373 24.569 0 33.941l86.059 86.059c15.119 15.119 40.971 4.411 40.971-16.971V296z"></path></svg>';
                    }
                    
                    if(!empty($base_json->styling->global_next_text)){
                        $forward_btn_text = $base_json->styling->global_next_text;
                        $forward_btn_style_class = 'special';
                    }else if(isset($base_json->showFontAwesome) && $base_json->showFontAwesome){
                        $forward_btn_text = '<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="long-arrow-alt-right" class="svg-inline--fa fa-long-arrow-alt-right fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M313.941 216H12c-6.627 0-12 5.373-12 12v56c0 6.627 5.373 12 12 12h301.941v46.059c0 21.382 25.851 32.09 40.971 16.971l86.059-86.059c9.373-9.373 9.373-24.569 0-33.941l-86.059-86.059c-15.119-15.119-40.971-4.411-40.971 16.971V216z"></path></svg>';
                    }else{
                        $forward_btn_text = '<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="long-arrow-alt-right" class="svg-inline--fa fa-long-arrow-alt-right fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M313.941 216H12c-6.627 0-12 5.373-12 12v56c0 6.627 5.373 12 12 12h301.941v46.059c0 21.382 25.851 32.09 40.971 16.971l86.059-86.059c9.373-9.373 9.373-24.569 0-33.941l-86.059-86.059c-15.119-15.119-40.971-4.411-40.971 16.971V216z"></path></svg>';
                    }
                }
                else {
                    if(!empty($base_json->styling->global_prev_text)){
                        $back_btn_text = $base_json->styling->global_prev_text;
                        $back_btn_style_class = 'special';
                    }else if(isset($base_json->showFontAwesome) && $base_json->showFontAwesome){
                        $back_btn_text = '<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="long-arrow-alt-right" class="svg-inline--fa fa-long-arrow-alt-right fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M313.941 216H12c-6.627 0-12 5.373-12 12v56c0 6.627 5.373 12 12 12h301.941v46.059c0 21.382 25.851 32.09 40.971 16.971l86.059-86.059c9.373-9.373 9.373-24.569 0-33.941l-86.059-86.059c-15.119-15.119-40.971-4.411-40.971 16.971V216z"></path></svg>';
                        //$back_btn_text = '<i class="fas fa-long-arrow-alt-left fa-lg"></i>';
                    }else{
                        $back_btn_text = '<<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="long-arrow-alt-right" class="svg-inline--fa fa-long-arrow-alt-right fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M313.941 216H12c-6.627 0-12 5.373-12 12v56c0 6.627 5.373 12 12 12h301.941v46.059c0 21.382 25.851 32.09 40.971 16.971l86.059-86.059c9.373-9.373 9.373-24.569 0-33.941l-86.059-86.059c-15.119-15.119-40.971-4.411-40.971 16.971V216z"></path></svg>';
                    }
                    
                    if(!empty($base_json->styling->global_next_text)){
                        $forward_btn_text = $base_json->styling->global_next_text;
                        $forward_btn_style_class = 'special';
                    }else if(isset($base_json->showFontAwesome) && $base_json->showFontAwesome){
                        $forward_btn_text = '<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="long-arrow-alt-left" class="svg-inline--fa fa-long-arrow-alt-left fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M134.059 296H436c6.627 0 12-5.373 12-12v-56c0-6.627-5.373-12-12-12H134.059v-46.059c0-21.382-25.851-32.09-40.971-16.971L7.029 239.029c-9.373 9.373-9.373 24.569 0 33.941l86.059 86.059c15.119 15.119 40.971 4.411 40.971-16.971V296z"></path></svg>';
                    }else{
                        $forward_btn_text = '<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="long-arrow-alt-left" class="svg-inline--fa fa-long-arrow-alt-left fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M134.059 296H436c6.627 0 12-5.373 12-12v-56c0-6.627-5.373-12-12-12H134.059v-46.059c0-21.382-25.851-32.09-40.971-16.971L7.029 239.029c-9.373 9.373-9.373 24.569 0 33.941l86.059 86.059c15.119 15.119 40.971 4.411 40.971-16.971V296z"></path></svg>';
                    }
                }
                
                
                /** Getting the Preload-Part * */
                /*
                 * INCOMING -> Build migration!
                 *
                 */
                $preload = 2;

                $errormail = false;
                $aScrollToAnchor = true;
                $aShowSuccessScreen = true;

                /*if(!isset($base_json->send_error_mail) || $base_json->send_error_mail !== false) {
                    $errormail = true;
                }*/
                if(isset($base_json->activateScrollToAnchor) && ($base_json->activateScrollToAnchor === 'false' || $base_json->activateScrollToAnchor === false)) {
                    $aScrollToAnchor = false;
                }
                if(isset($base_json->showSuccessScreen) && ($base_json->showSuccessScreen === 'false' || $base_json->showSuccessScreen === false)) {
                    $aShowSuccessScreen = false;
                }

                /**$loading_delay = 0;
                if($base_json->loadingDelay != null && $base_json->loadingDelay != "") {
                    $loading_delay = $base_json->loadingDelay;
                }

                $popcssclass = "";
                if($base_json->popcssclass != null && $base_json->popcssclass != "") {
                    $popcssclass = $base_json->popcssclass;
                }**/

                // TODO

                if($popup_by_click || $popup_by_delay) {
                    $content .= '<div style="display: none;">';
                    $content .= '<div class="af2_popup_background" id="afpbg_'.$this->frontend_id.'">';
                    $content .= '<div class="af2_popup_wrapper">';
                    $content .= '<div class="af2_close_popup" data-num="'.$this->frontend_id.'"></div>';
                }

                $success_text = __('Thank you! The form was sent successfully!', 'af2_multilanguage');
                if(isset($base_json->success_text) && $base_json->success_text != '') {
                    $success_text = $base_json->success_text;
                }

                $success_image = plugins_url("../res/images/success_standard", __FILE__);
                if(isset($base_json->success_image) && $base_json->success_image != '') {
                    $success_image = $base_json->success_image;
                }

                
                /** Building Content **/
                $content .= '<div id="af2_form_' . $this->frontend_id . '" class="af2_form_wrapper af2_form-type-'.$type.'"
								data-preload="' . $preload . '" data-rtl="'. $rtl_layout .'" data-size="' . $size . '" data-num="' . $this->frontend_id . '"
                                data-did="' . $dataid . '" data-errormail="' . $errormail . '" data-activatescrolltoanchor="' . $aScrollToAnchor . '" data-showsuccessscreen="'.$aShowSuccessScreen.'"
                                data-popup_by_delay="'.$popup_by_delay.'" data-popup_delay="'.$popup_delay.'" data-popup_by_click="'.$popup_by_click.'"
                                data-popup_click_class="'.$popup_click_class.'">';
                
                if(isset($base_json->showLoading) && $base_json->showLoading === true) {
                $content .= '<div class="af2_loading_overlay">
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="margin:auto;background:transparent;display:block;" width="200px" height="200px" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid">
 <g transform="translate(50 50)">  <g transform="translate(-19 -19) scale(0.6)"> <g transform="rotate(22.5612)">
<animateTransform attributeName="transform" type="rotate" values="0;45" keyTimes="0;1" dur="0.2s" begin="0s" repeatCount="indefinite"></animateTransform><path style="fill:'.$loader_color.'" d="M31.359972760794346 21.46047782418268 L38.431040572659825 28.531545636048154 L28.531545636048154 38.431040572659825 L21.46047782418268 31.359972760794346 A38 38 0 0 1 7.0000000000000036 37.3496987939662 L7.0000000000000036 37.3496987939662 L7.000000000000004 47.3496987939662 L-6.999999999999999 47.3496987939662 L-7 37.3496987939662 A38 38 0 0 1 -21.46047782418268 31.35997276079435 L-21.46047782418268 31.35997276079435 L-28.531545636048154 38.431040572659825 L-38.43104057265982 28.531545636048158 L-31.359972760794346 21.460477824182682 A38 38 0 0 1 -37.3496987939662 7.000000000000007 L-37.3496987939662 7.000000000000007 L-47.3496987939662 7.000000000000008 L-47.3496987939662 -6.9999999999999964 L-37.3496987939662 -6.999999999999997 A38 38 0 0 1 -31.35997276079435 -21.460477824182675 L-31.35997276079435 -21.460477824182675 L-38.431040572659825 -28.531545636048147 L-28.53154563604818 -38.4310405726598 L-21.4604778241827 -31.35997276079433 A38 38 0 0 1 -6.999999999999992 -37.3496987939662 L-6.999999999999992 -37.3496987939662 L-6.999999999999994 -47.3496987939662 L6.999999999999977 -47.3496987939662 L6.999999999999979 -37.3496987939662 A38 38 0 0 1 21.460477824182686 -31.359972760794342 L21.460477824182686 -31.359972760794342 L28.531545636048158 -38.43104057265982 L38.4310405726598 -28.53154563604818 L31.35997276079433 -21.4604778241827 A38 38 0 0 1 37.3496987939662 -6.999999999999995 L37.3496987939662 -6.999999999999995 L47.3496987939662 -6.999999999999997 L47.349698793966205 6.999999999999973 L37.349698793966205 6.999999999999976 A38 38 0 0 1 31.359972760794346 21.460477824182686 M0 -23A23 23 0 1 0 0 23 A23 23 0 1 0 0 -23" fill="#070707"></path></g></g> <g transform="translate(19 19) scale(0.6)"> <g transform="rotate(44.9388)">
<animateTransform attributeName="transform" type="rotate" values="45;0" keyTimes="0;1" dur="0.2s" begin="-0.1s" repeatCount="indefinite"></animateTransform><path style="fill:'.$loader_color.'" d="M-31.35997276079435 -21.460477824182675 L-38.431040572659825 -28.531545636048147 L-28.53154563604818 -38.4310405726598 L-21.4604778241827 -31.35997276079433 A38 38 0 0 1 -6.999999999999992 -37.3496987939662 L-6.999999999999992 -37.3496987939662 L-6.999999999999994 -47.3496987939662 L6.999999999999977 -47.3496987939662 L6.999999999999979 -37.3496987939662 A38 38 0 0 1 21.460477824182686 -31.359972760794342 L21.460477824182686 -31.359972760794342 L28.531545636048158 -38.43104057265982 L38.4310405726598 -28.53154563604818 L31.35997276079433 -21.4604778241827 A38 38 0 0 1 37.3496987939662 -6.999999999999995 L37.3496987939662 -6.999999999999995 L47.3496987939662 -6.999999999999997 L47.349698793966205 6.999999999999973 L37.349698793966205 6.999999999999976 A38 38 0 0 1 31.359972760794346 21.460477824182686 L31.359972760794346 21.460477824182686 L38.431040572659825 28.531545636048158 L28.53154563604818 38.4310405726598 L21.460477824182703 31.35997276079433 A38 38 0 0 1 6.9999999999999964 37.3496987939662 L6.9999999999999964 37.3496987939662 L6.999999999999995 47.3496987939662 L-7.000000000000009 47.3496987939662 L-7.000000000000007 37.3496987939662 A38 38 0 0 1 -21.46047782418263 31.359972760794385 L-21.46047782418263 31.359972760794385 L-28.531545636048097 38.43104057265987 L-38.431040572659796 28.531545636048186 L-31.35997276079433 21.460477824182703 A38 38 0 0 1 -37.34969879396619 7.000000000000032 L-37.34969879396619 7.000000000000032 L-47.34969879396619 7.0000000000000355 L-47.3496987939662 -7.000000000000002 L-37.3496987939662 -7.000000000000005 A38 38 0 0 1 -31.359972760794346 -21.46047782418268 M0 -23A23 23 0 1 0 0 23 A23 23 0 1 0 0 -23" fill="#000000"></path></g></g></g>
</svg>
                        </div>';
                        
                    $content .= '<div class="af2_form" style="display: none;">';
                }
                else {
                    $content .= '<div class="af2_form" style="display: block;">';
                }

                $content .= '<div class="af2_success_message_screen af2_openai_success desktop" style="display: none;">';
                    $content .= '<div class="af2_success_image">';
                    $content .= '<img src="'.plugins_url('/res/images/openai/openai_success.png', AF2_PLUGIN).'" />';
                    $content .= '</div>';
                    $content .= '<div class="af2_success_text">';
                    $content .=  $success_text;
                    $content .= '</div>';
                $content .= '</div>';
                $content .= '<div class="af2_success_message_screen af2_openai_error desktop" style="display: none;">';
                    $content .= '<div class="af2_success_image">';
                    $content .= '<img src="'.plugins_url('/res/images/openai/openai_error.png', AF2_PLUGIN).'" />';
                    $content .= '</div>';
                    $content .= '<div class="af2_success_text">';
                    $content .= __('The form could not be created due to an error. Please try again with different details.', 'af2_multilanguage');
                    $content .= '</div>';
                $content .= '</div>';
                
                $content .= '<div class="af2_form_heading_wrapper">';
                $content .= '<div class="af2_form_heading desktop">' . $fe_title . '</div>';
                $content .= '<div class="af2_form_heading af2_mobile">' . $fe_title . '</div>';
                $content .= '</div>';
                $content .= '<div class="af2_form_carousel">';
                $content .= '</div>';

                if(isset($base_json->hide_progress_bar) && $base_json->hide_progress_bar === true) {
                    $content .= '<div class="af2_form_bottombar hide_progress_bar">';
                } else {
                    $content .= '<div class="af2_form_bottombar">';
                }

                $content .= '<button class="af2_form_back_button af2_form_button af2_disabled af2_mobile '.$back_btn_style_class.'">'.$back_btn_text.'</button>';
                $content .= '<button class="af2_form_back_button af2_form_button af2_disabled desktop '.$back_btn_style_class.'">'.$back_btn_text.'</button>';
                $content .= '<div class="af2_form_progress_bar"><div class="af2_form_progress"></div></div>';
                $content .= '<button class="af2_form_foward_button af2_form_button af2_disabled af2_mobile '.$forward_btn_style_class.'">'.$forward_btn_text.'</button>';
                $content .= '<button class="af2_form_foward_button af2_form_button af2_disabled desktop '.$forward_btn_style_class.'">'.$forward_btn_text.'</button>';
                $content .= '</div>';
                $content .= '</div>';
                
            
                $content .= '</div>';

                if($popup_by_click || $popup_by_delay) {
                    $content .= '</div>';
                    $content .= '</div>';
                    $content .= '</div>';
                }
            }
        } // ENDIF /** Check if license is active **/

        /** RETURNING * */
        $this->frontend_id++;

        $wp_locale_switcher->switch_to_locale( $this->current_locale );

        return $content;
    }

    /**
     * Getting all data for the frontend to work with
     */
    function af2_get_data() {
        if (!( check_ajax_referer('af2_FE_nonce', '_ajax_nonce', false) )) {
            echo __('ERROR - [01] Ajax error (caching error, please contact support)!', 'af2_multilanguage');
            die();
        }

        /** Check that all attributes are sent * */
        if (!isset($_GET['ids'])) {
            echo 'ERRORX';
            die();
        }

        /** Get all attributes * */
        $dataids = $_GET['ids'];                      // The Array of Dataids

        /** Checking for bad input and fetching posts * */
        $base_posts = array();                       // The post of it out of DB
        $x = 0;                           // Loop
        foreach ($dataids as $dataid) {

            $base_posts[$x] = $this->af2_check_params_for_getting_content($dataid);

            /** Checking that no Errors are given * */
            if ($base_posts[$x] === 'ERROR') {
                echo __('ERROR - [02] Please contact support!', 'af2_multilanguage');
                die();
            }

            $x++;
        }

        /** Fetching content out of Database * */
        $base_jsons = array();                       // The json-Objects of it
        $post_types = array();                       // The Types of the post
        $x = 0;                           // Loop
        require_once AF2_MISC_FUNCTIONS_PATH;
        foreach ($base_posts as $base_post) {
            $base_jsons[$x] = af2_get_post_content($base_post);


            $base_jsons[$x] = json_decode(json_encode($base_jsons[$x]));

            /** Checking that no Error is given * */
            $check = $this->af2_check_for_errors($base_jsons[$x]);
            if ($check === 'ERROR') {
                echo __('ERROR - [03] There is an error in a form element!', 'af2_multilanguage');
                die();
            }

            $post_types[$x] = get_post_field('post_type', $base_post);

            $x++;
        }

        /** Cleaning the jsons for the frontend * */
        $new_jsons = json_decode('{}');                    // The clean Jsons
        $x = 0;                           // Loop
        foreach ($post_types as $post_type) {
            $data = strval($dataids[$x]);                   // Actual called Dataid
            switch ($post_type) {
                case 'af2_ai_frage': {
                        $new_jsons->$data = $this->af2_clean_frage_json($base_jsons[$x]);
                        break;
                    }
                case 'af2_ai_kontf': {
                        $new_jsons->$data = $this->af2_clean_kontaktformular_json($base_jsons[$x]);
                        break;
                    }
                case 'af2_ai_formular': {
                        $new_jsons->$data = $this->af2_clean_formular_json($base_jsons[$x]);
                        break;
                    }
            }

            $x++;
        }

        $jsons = json_encode($new_jsons, JSON_UNESCAPED_UNICODE);              // Json to return

        echo $jsons;
        wp_die();
    }

    /**
     * Making the json usable for the frontend
     *
     * @param $base_json
     * @return string
     */
    function af2_clean_frage_json($base_json) {
        $new_json = json_decode('{}');

        /** Processing... * */
        $new_json->frontend_name = $base_json->name;
        $new_json->frontend_description = $base_json->description == null ? '' : $base_json->description;
        $new_json->typ = $base_json->typ;
        $new_json->type_specifics = $this->af2_process_type_specifics($base_json);
        $new_json->af2_type = 'frage';
        $new_json->tracking = $base_json->tracking_code;

        return $new_json;
    }

    /**
     * Making the json usable for the frontend
     *
     * @param $base_json
     * @return string
     */
    function af2_clean_kontaktformular_json($base_json) {
        $new_json = json_decode('{}');

        /** Processing... * */
        $new_json->frontend_name = $base_json->cftitle;
        $new_json->frontend_description = $base_json->description == null ? '' : $base_json->description;
        $new_json->questions = $base_json->questions;
        $new_json->sendButtonLabel = $base_json->send_button;
        $new_json->af2_type = 'kontaktformular';
        $new_json->show_bottombar = $base_json->show_bottombar;
        $new_json->tracking_code = $base_json->tracking_code;

        return $new_json;
    }

    /**
     * Making the json usable for the frontend
     *
     * @param $base_json
     * @return string
     */
    function af2_clean_formular_json($base_json) {
        $new_json = json_decode('{}');

        /** Processing... * */
        $new_json->sections = $this->af2_process_connections($base_json->sections);/** TODO ERRORS * */
        $new_json->styling = $this->af2_process_styling($base_json->styling);/** TODO ERRORS * */
        $new_json->af2_type = 'formular';

        return $new_json;
    }

    /*
     * INCOMING -> DELEDEABLE Part of the Method, WHEN ITS DONE IN BACKEND PERFECTLY
     */

    /**
     * Building the dataids of following into the connections
     *
     * @param $base_array
     * @return mixed
     */
    function af2_process_connections($base_array) {
        $new_json = json_decode('{}');
        $new_json->sections = $base_array;                    // Puffer

        /** Iterating all Sections * */
        for ($x = sizeof($new_json->sections) - 1; $x >= 0; $x--) {
            $section = $new_json->sections[$x];                  // ForEach object

            /** Iterating all Contents * */
            for ($y = sizeof($section->contents) - 1; $y >= 0; $y--) {
                $content = $section->contents[$y];                 // ForEach object

                /** Check if content should be deleted because its an interface * */
                if ($this->af2_check_data_type($content->data) === 'interface') {
                    /** SAFE THE OTHER ONES * */
                    /** Iterating all Contents * */
                    for ($z = sizeof($section->contents) - 1; $z >= 0; $z--) {
                        if ($z > $y) {
                            if ($this->af2_check_data_type($base_array[$x]->contents[$z]) === 'redirect') {
                                foreach ($base_array[$x]->contents[$z]->incoming_connections as $inc) {
                                    $from_section = $inc->from_section;
                                    $from_content = $inc->from_content;

                                    $a = 0;
                                    foreach ($base_array[$from_section]->contents[$from_content]->connections as $con) {
                                        if ($con->to_section == $x && $con->to_content == $z) {
                                            $new_json->sections[$from_section]->contents[$from_content]->connections[$a]->to_content = $base_array[$from_section]->contents[$from_content]->connections[$a]->to_content - 1;
                                        }
                                        $a++;
                                    }
                                }
                            }
                        }
                    }

                    array_splice($new_json->sections[$x]->contents, $y, 1);
                    continue;
                }

                /** Iterating all Connections * */
                if(isset($content->connections)) {
                    for ($z = sizeof($content->connections) - 1; $z >= 0; $z--) {
                        $connection = $content->connections[$z];               // ForEach object

                        $to_section = $connection->to_section;                // The Section to go on
                        $to_content = $connection->to_content;                // The Content to go on
                        $base_section = $base_array[$to_section];
                        $contents = null;
                        $to_dataid = null;
                        if(isset($base_section->contents[$to_content])) {
                            $contents = $base_section->contents[$to_content];
                            $to_dataid = $contents->data;        // The Dataid to go on
                        }

                        /** Check that dataid is an interface * */
                        if ($this->af2_check_data_type($to_dataid) === 'undefined') {
                            array_splice($new_json->sections[$x]->contents[$y]->connections, $z, 1);
                        } else {
                            /** Correcting everything into numbers! * */
                            /*
                            * INCOMING -> DELETEABE, when its perfectly done in the backend!
                            */
                            $new_json->sections[$x]->contents[$y]->connections[$z]->from = intval($connection->from);
                            $new_json->sections[$x]->contents[$y]->connections[$z]->to_section = intval($connection->to_section);
                            $new_json->sections[$x]->contents[$y]->connections[$z]->to_content = intval($connection->to_content);

                            /** Adding the Dataid into the connections * */
                            $new_json->sections[$x]->contents[$y]->connections[$z]->to_dataid = $to_dataid;
                        }
                    } // ENDLOOP /** Iterating all Connections **/
                }
                /** Iterating all incoming connections * */
                if(isset($content->incoming_connections)) {
                    for ($z = sizeof($content->incoming_connections) - 1; $z >= 0; $z--) {
                        $incoming_connection = $content->incoming_connections[$z];          // ForEach object
                        /** Correcting everything into numbers! * */
                        /*
                        * INCOMING -> DELETEABE, when its perfectly done in the backend!
                        */
                        $new_json->sections[$x]->contents[$y]->incoming_connections[$z]->from_section = intval($incoming_connection->from_section);
                        $new_json->sections[$x]->contents[$y]->incoming_connections[$z]->from_content = intval($incoming_connection->from_content);
                    } // ENDLOOP /** Iterating all Connections **/
                }
            } // ENDLOOP /** Iterating all Contents **/
        } // ENDLOOP /** Iterating all Sections **/

        return $new_json->sections;
    }

    /**
     * Process the specifics for every type
     *
     * @param $base_json
     * @return string
     */
    function af2_process_type_specifics($base_json) {
        require_once AF2_MISC_FUNCTIONS_PATH;
        $new_json = json_decode('{}');

        $type = $base_json->typ;                      // Typ of the actual Frage

        switch ($type) {
            case 'af2_select': {
                    $new_json->answers = $this->af2_process_answers($base_json->answers);
                    $new_json->desktop_layout = $base_json->desktop_layout;
                    $new_json->mobile_layout = $base_json->mobile_layout;
                    $new_json->hide_icons = $base_json->hide_icons;
                    break;
                }
            case 'af2_multiselect': {
                    $new_json->answers = $this->af2_process_answers($base_json->answers);
                    $new_json->condition = $base_json->condition;
                    $new_json->desktop_layout = $base_json->desktop_layout;
                    $new_json->mobile_layout = $base_json->mobile_layout;
                    $new_json->hide_icons = $base_json->hide_icons;
                    break;
                }
            case 'af2_textfeld': {
                    $new_json->placeholder = $base_json->textfeld;
                    $new_json->mandatory = $base_json->textfield_mandatory;
                    if($base_json->min_length != null) $new_json->min_length = $base_json->min_length;
                    if($base_json->max_length != null) $new_json->max_length = $base_json->max_length;

                    if($base_json->text_only_text != null) $new_json->text_only_text = $base_json->text_only_text;
                    if($base_json->text_only_numbers != null) $new_json->text_only_numbers = $base_json->text_only_numbers;
                    if($base_json->text_birthday != null) $new_json->text_birthday = $base_json->text_birthday;
                    if($base_json->text_only_numbers != null) $new_json->text_only_numbers = $base_json->text_only_numbers;
                    //if($base_json->text_plz != null) $new_json->text_plz = $base_json->text_plz;
                    break;
                }
            case 'af2_textbereich': {
                    $new_json->placeholder = $base_json->textarea;
                    $new_json->mandatory = $base_json->textarea_mandatory;
                    
                    if($base_json->min_length != null) $new_json->min_length = $base_json->min_length;
                    if($base_json->max_length != null) $new_json->max_length = $base_json->max_length;

                    if($base_json->text_only_text != null) $new_json->text_only_text = $base_json->text_only_text;
                    if($base_json->text_only_numbers != null) $new_json->text_only_numbers = $base_json->text_only_numbers;
                    if($base_json->text_birthday != null) $new_json->text_birthday = $base_json->text_birthday;
                    //if($base_json->text_plz != null) $new_json->text_plz = $base_json->text_plz;

                    break;
                }
            case 'af2_datum': {
                $new_json->placeholder = $base_json->datum;
                $new_json->format = $base_json->datum_format;
                $new_json->datemandatory = $base_json->datemandatory;
                break;
            }
            case 'af2_slider': {
                $new_json->min = $base_json->min;
                $new_json->max = $base_json->max;
                $new_json->step = $base_json->step;
                $new_json->label = $base_json->label;
                $new_json->start = $base_json->start;
                $new_json->thousand = $base_json->thousand;
                $new_json->labelBefore = $base_json->lab;
                $new_json->manual = $base_json->manual;
                $new_json->text_manual = $base_json->text_manual;
                $image = isset($base_json->slider_image) ? $base_json->slider_image : null;
                $new_json->icon = null;
                $new_json->image = null;
                if($image == null) break;
                
                if(af2_str_contains($image, 'https:')) $new_json->image = $image;
                else $new_json->icon = $image;
                break;
            }
            case 'af2_content': {
                $new_json->content = $base_json->content_area;
                $new_json->content_button = $base_json->content_button;
                $new_json->content_button_text = $base_json->content_button_text;
                $new_json->content_wait_time = $base_json->content_wait;
                break;
            }
            case 'af2_dateiupload': {
                $new_json->description = $base_json->fileupload_desc;
                $new_json->mandatory = $base_json->fileupload_mandatory;
                $new_json->max_size = $base_json->fileupload_max_size;
                $new_json->max_count = $base_json->fileupload_max_count;
                $new_json->restricted_types = $base_json->restrictedFiles == null ? array() : $base_json->restrictedFiles;
                break;
            }
            case 'af2_dropdown': {
                $new_json->dropdown_options = $base_json->dropdown_options;
                break;
            }
            case 'af2_adressfeld': {
                $new_json->zoomlevel = $base_json->zoomlevel;
                $new_json->center = $base_json->startposition->loc;
                $new_json->mapmandatory = $base_json->mapmandatory;
            }
            case 'af2_terminbuchung': {
                $termineventid = $base_json->terminbuchungsid;
                $terminevent = get_post($termineventid);
                if(isset($terminevent) && $terminevent != null) {

                    require_once AF2_MISC_FUNCTIONS_PATH;
                    $structure_base_json = af2_get_post_content($terminevent);                         
                    $jsonm = json_decode(json_encode($structure_base_json));
                    
                    $new_json->termineventcontent = $jsonm;
                    $new_json->termineventcontent->cronofy_token_data = null;
                } else {
                    $new_json->termineventcontent = null;
                }
            }
        }

        return $new_json;
    }

    /**
     * Processing the answers, that all types in there are corredt
     *
     * @param $answers
     * @return array
     */
    function af2_process_answers($answers) {
        $new_array = array();

        foreach ($answers as $answer) {
            $new_answer = json_decode('{}');                   // The new answer object
            $new_answer->text = $answer->text;                   // Text of the answer
            $new_answer->icon = $answer->img;                   // Actual Icon
            $new_answer->icon_type = '';                    // Type of the icon
            if (strpos($new_answer->icon, 'http') !== false) {
                $new_answer->icon_type = 'url';
            } else {
                $new_answer->icon_type = 'font-awesome';
            }

            array_push($new_array, $new_answer);
        }

        return $new_array;
    }

    /*
     * INCOMING -> DELEt´TEABLE METHOD, WHEN ITS DONE IN BACKEND PERFECTLY
     */

    /**
     * Building the right styling for the frontend to use
     *
     * @param $base_json
     * @return string
     */
    function af2_process_styling($base_json) {
        $new_json = json_decode('{}');

        /** Get all stylings * */
    
        /** COLORS * */
        $form_heading_color = json_decode('{"attribute": "color","value":"' . $base_json->form_heading_color . '"}');
        
        $form_question_heading_color = json_decode('{"attribute": "color","value":"' . $base_json->form_question_heading_color . '"}');
        
        $form_question_description_color = json_decode('{"attribute": "color","value":"' . $base_json->form_question_description_color . '"}');
        
        $form_answer_card_text_color = json_decode('{"attribute": "color","value":"' . $base_json->form_answer_card_text_color . '"}');
        
        $form_answer_card_icon_color = json_decode('{"attribute": "color","value":"' . $base_json->form_answer_card_icon_color . '"}');
        
        $form_background_color = json_decode('{"attribute": "background-color","value":"' . $base_json->form_background_color . '"}');
        $form_font = json_decode('{"attribute": "font-family","value":"' . $base_json->global_font . '"}');
        $form_fontfc = json_decode('{"attribute": "font-family","value":"' . $base_json->global_font . '", "special_class":"form_font"}');
        
        $form_answer_card_background_color = json_decode('{"attribute": "background-color","value":"' . $base_json->form_answer_card_background_color . '"}');
        
        $form_button_background_color = json_decode('{"attribute": "background-color","value":"' . $base_json->form_button_background_color . '"}');
        
        $form_button_disabled_background_color = json_decode('{"attribute":"background-color","value": "' . $base_json->form_button_disabled_background_color . '","special_class": "af2_disabled"}');
        
        $form_button_label_text_desktop = json_decode('{"attribute":"font-size","value": "' . $base_json->form_button_label_size_desktop . 'px","special_class": "desktop"}');
     
        $form_button_label_text_mobile = json_decode('{"attribute":"font-size","value": "' . $base_json->form_button_label_size_mobile . 'px","special_class": "af2_mobile"}');
    
        $answer_card_box_shadow_value = isset($base_json->form_box_shadow_color_answer_card) ? $base_json->form_box_shadow_color_answer_card : 'rgba(225,225,225,1)';
        $form_box_shadow_color_answer_card = json_decode('{"attribute": "box-shadow","value":" 5px 5px 15px 0 ' . $answer_card_box_shadow_value . '"}');

        $answer_card_box_shadow_value_unfocus = isset($base_json->form_box_shadow_color_unfocus) ? $base_json->form_box_shadow_color_unfocus : 'rgba(225,225,225,1)';
        
        $form_box_shadow_color_unfocus = json_decode('{"attribute": "box-shadow","value":" 0px 0px 10px 0 ' . $answer_card_box_shadow_value_unfocus . '"}');
        $form_box_shadow_color = json_decode('{"attribute": "box-shadow","value":" 0px 0px 10px 0 ' . $base_json->form_box_shadow_color . '", "special_state": "focus"}');
        $form_box_shadow_colorfc = json_decode('{"attribute": "box-shadow","value":" 0px 0px 10px 0 ' . $base_json->form_box_shadow_color . '", "special_state": "focus", "special_class":"form_class"}');
        
        $form_progress_bar_color = json_decode('{"attribute": "background-color","value":"' . $base_json->form_progress_bar_color . '"}');
        
        $form_progress_bar_unfilled_background_color = json_decode('{"attribute": "background-color","value":"' . $base_json->form_progress_bar_unfilled_background_color . '"}');
        
        $form_border_color = json_decode('{"attribute": "border","value":"1px solid ' . $base_json->form_border_color . '","special_state":"focus"}');
        $form_border_colorfc = json_decode('{"attribute": "border","value":"1px solid ' . $base_json->form_border_color . '","special_state":"focus", "special_class":"form_class"}');
        
        $form_slider_frage_bullet_color = json_decode('{"attribute": "color","value":"' . $base_json->form_slider_frage_bullet_color . '"}');
        
        $form_slider_frage_thumb_background_color = json_decode('{"attribute": "background-color","value":"' . $base_json->form_slider_frage_thumb_background_color . ' !important","special_extra":"-moz-range-thumb"}');
        
        $form_slider_frage_thumb_background_color2 = json_decode('{"attribute": "background-color","value":"' . $base_json->form_slider_frage_thumb_background_color . ' !important","special_extra":"-webkit-slider-thumb"}');
        $form_slider_frage_background_color = json_decode('{"attribute": "background-color","value":"' . $base_json->form_slider_frage_background_color . '"}');
        
        $form_input_background_color = json_decode('{"attribute": "background-color","value":"' . $base_json->form_input_background_color . '"}');
        
         $form_loader_color = json_decode('{"attribute": "color","value":"' . $base_json->form_loader_color . '"}');

        /** TEXT THINGS * */
        //form heading
        $form_heading_size_desktop = json_decode('{"attribute": "font-size",
								 						 	"value":"' . $base_json->form_heading_size_desktop . 'px",
								 						 	"special_class":"desktop"}');
        $form_heading_size_mobile = json_decode('{"attribute": "font-size",
								 						 	"value":"' . $base_json->form_heading_size_mobile . 'px",
								 						 	"special_class":"af2_mobile"}');
        $form_heading_weight = json_decode('{"attribute": "font-weight",
								 						 	"value":"' . $base_json->form_heading_weight . '"}');
        $form_heading_line_height_desktop = json_decode('{"attribute": "line-height",
								 						 	"value":"' . $base_json->form_heading_line_height_desktop . 'px",
								 						 	"special_class":"desktop"}');
        $form_heading_line_height_mobile = json_decode('{"attribute": "line-height",
								 						 	"value":"' . $base_json->form_heading_line_height_mobile . 'px",
								 						 	"special_class":"af2_mobile"}');

        //question heading
        $form_question_heading_size_desktop = json_decode('{"attribute": "font-size",
								 						 	"value":"' . $base_json->form_question_heading_size_desktop . 'px",
								 						 	"special_class":"desktop"}');
        $form_question_heading_size_mobile = json_decode('{"attribute": "font-size",
								 						 	"value":"' . $base_json->form_question_heading_size_mobile . 'px",
								 						 	"special_class":"af2_mobile"}');
        $form_question_heading_weight = json_decode('{"attribute": "font-weight",
								 						 	"value":"' . $base_json->form_question_heading_weight . '"}');
        $form_question_heading_line_height_desktop = json_decode('{"attribute": "line-height",
								 						 	"value":"' . $base_json->form_question_heading_line_height_desktop . 'px",
								 						 	"special_class":"desktop"}');
        $form_question_heading_line_height_mobile = json_decode('{"attribute": "line-height",
								 						 	"value":"' . $base_json->form_question_heading_line_height_mobile . 'px",
															  "special_class":"af2_mobile"}');

        //question description
        $form_question_description_size_desktop = json_decode('{"attribute": "font-size",
															"value":"' . $base_json->form_question_description_size_desktop . 'px",
															"special_class":"desktop"}');
        $form_question_description_size_mobile = json_decode('{"attribute": "font-size",
															"value":"' . $base_json->form_question_description_size_mobile . 'px",
															"special_class":"af2_mobile"}');
        $form_question_description_weight = json_decode('{"attribute": "font-weight",
															"value":"' . $base_json->form_question_description_weight . '"}');
        $form_question_description_line_height_desktop = json_decode('{"attribute": "line-height",
															"value":"' . $base_json->form_question_description_line_height_desktop . 'px",
															"special_class":"desktop"}');
        $form_question_description_line_height_mobile = json_decode('{"attribute": "line-height",
															"value":"' . $base_json->form_question_description_line_height_mobile . 'px",
															"special_class":"af2_mobile"}');

        //answers
        $form_answer_card_text_size_desktop = json_decode('{"attribute": "font-size",
								 						 	"value":"' . $base_json->form_answer_card_text_size_desktop . 'px",
								 						 	"special_class":"desktop"}');
        $form_answer_card_text_size_desktop_ = json_decode('{"attribute": "font-size",
								 						 	"value":"' . $base_json->form_answer_card_text_size_desktop . 'px"}');
        $form_answer_card_text_size_desktop_fc = json_decode('{"attribute": "font-size",
								 						 	"value":"' . $base_json->form_answer_card_text_size_desktop . 'px", "special_class":"form_class"}');
        $form_answer_card_text_size_mobile = json_decode('{"attribute": "font-size",
								 						 	"value":"' . $base_json->form_answer_card_text_size_mobile . 'px",
								 						 	"special_class":"af2_mobile"}');
        $form_answer_card_text_size_mobile_ = json_decode('{"attribute": "font-size",
								 						 	"value":"' . $base_json->form_answer_card_text_size_mobile . 'px"}');
        $form_answer_card_text_size_mobile_fc = json_decode('{"attribute": "font-size",
								 						 	"value":"' . $base_json->form_answer_card_text_size_mobile . 'px", "special_class":"form_class"}');
        $form_answer_card_text_weight = json_decode('{"attribute": "font-weight",
								 						 	"value":"' . $base_json->form_answer_card_text_weight . '"}');
        $form_answer_card_text_weightfc = json_decode('{"attribute": "font-weight",
								 						 	"value":"' . $base_json->form_answer_card_text_weight . '", "special_class":"form_class"}');
        $form_answer_card_text_line_height_desktop = json_decode('{"attribute": "line-height",
								 						 	"value":"' . $base_json->form_answer_card_text_line_height_desktop . 'px",
								 						 	"special_class":"desktop"}');
        $form_answer_card_text_line_height_mobile = json_decode('{"attribute": "line-height",
								 						 	"value":"' . $base_json->form_answer_card_text_line_height_mobile . 'px",
								 						 	"special_class":"af2_mobile"}');

        //input text sizes
        $form_text_input_size_desktop = json_decode('{"attribute": "font-size",
								 						 	"value":"' . $base_json->form_text_input_size_desktop . 'px",
								 						 	"special_class":"desktop"}');
        $form_text_input_size_mobile = json_decode('{"attribute": "font-size",
								 						 	"value":"' . $base_json->form_text_input_size_mobile . 'px",
								 						 	"special_class":"af2_mobile"}');
        $form_text_input_weight = json_decode('{"attribute": "font-weight",
								 						 	"value":"' . $base_json->form_text_input_text_weight . '"}');
        $form_text_input_line_height_desktop = json_decode('{"attribute": "line-height",
								 						 	"value":"' . $base_json->form_text_input_line_height_desktop . 'px",
								 						 	"special_class":"desktop"}');
        $form_text_input_line_height_mobile = json_decode('{"attribute": "line-height",
								 						 	"value":"' . $base_json->form_text_input_line_height_mobile . 'px",
								 						 	"special_class":"af2_mobile"}');

        /** BORDER RADIUS * */
        $form_answer_card_border_radius = json_decode('{"attribute": "border-radius",
								 						 	"value":"' . $base_json->form_answer_card_border_radius . 'px"}');
        $form_text_input_border_radius = json_decode('{"attribute": "border-radius",
								 						 	"value":"' . $base_json->form_text_input_border_radius . 'px"}');
        $form_text_input_border_radiusfc = json_decode('{"attribute": "border-radius",
								 						 	"value":"' . $base_json->form_text_input_border_radius . 'px", "special_class":"form_class"}');
        $form_text_input_border_radius_ = json_decode('{"attribute": "border-radius",
								 						 	"value":"' . $base_json->form_text_input_border_radius . 'px 0 0 ' . $base_json->form_text_input_border_radius . 'px"}');
        $form_text_input_border_radiuslr = json_decode('{"attribute": "border-radius",
                                                        "value":"0 ' . $base_json->form_text_input_border_radius . 'px ' . $base_json->form_text_input_border_radius . 'px 0"}');

        /** CONTACT FORM * */
        $form_contact_form_label_size = json_decode('{"attribute": "font-size",
															"value":"' . $base_json->form_contact_form_label_size . 'px"}');
        $form_contact_form_label_size_ = json_decode('{"attribute": "font-size",
															"value":"' . $base_json->form_contact_form_label_size . 'px", "special_class": "desktop"}');
        $form_contact_form_label_weight = json_decode('{"attribute": "font-weight",
															"value":"' . $base_json->form_contact_form_label_weight . '"}');
        $form_contact_form_input_size = json_decode('{"attribute": "font-size",
																	"value":"' . $base_json->form_contact_form_input_size . 'px"}');
        $form_contact_form_input_weight = json_decode('{"attribute": "font-weight",
																	"value":"' . $base_json->form_contact_form_input_weight . '"}');
        $form_contact_form_button_size = json_decode('{"attribute": "font-size",
																	"value":"' . $base_json->form_contact_form_button_size . 'px"}');
        $form_contact_form_button_weight = json_decode('{"attribute": "font-weight",
																	"value":"' . $base_json->form_contact_form_button_weight . '"}');
        $form_contact_form_button_padding_top_bottom = json_decode('{"attribute": "padding",
																	"value":"' . $base_json->form_contact_form_button_padding_top_bottom . 'px 0"}');
        
        $form_contact_form_button_padding_left = json_decode('{"attribute": "padding-left","value":"' . $base_json->form_contact_form_button_padding_left_right . 'px"}');
        $form_contact_form_button_padding_right = json_decode('{"attribute": "padding-right","value":"' . $base_json->form_contact_form_button_padding_left_right . 'px"}');
        
        $form_contact_form_cb_size = json_decode('{"attribute": "font-size",
																	"value":"' . $base_json->form_contact_form_cb_size . 'px"}');
        $form_contact_form_cb_weight = json_decode('{"attribute": "font-weight",
																	"value":"' . $base_json->form_contact_form_cb_weight . '"}');
        $form_contact_form_input_height = json_decode('{"attribute": "height",
																	"value":"' . $base_json->form_contact_form_input_height . 'px"}');
        $form_contact_form_input_border_radius = json_decode('{"attribute": "border-radius",
																	"value":"0 ' . $base_json->form_contact_form_input_border_radius . 'px '.$base_json->form_contact_form_input_border_radius.'px 0"}');
        $form_contact_form_input_border_radiuslr = json_decode('{"attribute": "border-radius",
																	"value":"' . $base_json->form_contact_form_input_border_radius . 'px 0 0 '.$base_json->form_contact_form_input_border_radius.'px"}');
        $form_contact_form_input_border_radius_ = json_decode('{"attribute": "border-radius",
																	"value":"' . $base_json->form_contact_form_input_border_radius . 'px"}');
        $form_contact_form_button_border_radius = json_decode('{"attribute": "border-radius",
																	"value":"' . $base_json->form_contact_form_button_border_radius . 'px"}');
        $form_contact_form_button_background_color = json_decode('{"attribute": "background-color",
																	"value":"' . $base_json->form_contact_form_button_background_color . '"}');
        $form_contact_form_button_background_color_ = json_decode('{"attribute": "color",
																	"value":"' . $base_json->form_contact_form_button_background_color . ' !important"}');
        $form_contact_form_button_background_color_fc = json_decode('{"attribute": "background-color",
																	"value":"' . $base_json->form_contact_form_button_background_color . ' !important", "special_class": "form_class"}');
        $form_contact_form_button_color = json_decode('{"attribute": "color",
																		"value":"' . $base_json->form_contact_form_button_color . '"}');
        
        $rgb = explode(',', explode('(', $base_json->form_contact_form_button_background_color)[1]);
        $form_contact_form_button_background_color_rgb = json_decode('{"attribute": "--rgb",
            "value":"' . $rgb[0].', '.$rgb[1].', '.$rgb[2] . '"}');

            $rgb = explode(',', explode('(', $base_json->form_contact_form_button_color)[1]);
            $form_contact_form_button_color_rgb = json_decode('{"attribute": "--rgbcol",
                "value":"' . $rgb[0].', '.$rgb[1].', '.$rgb[2] . '"}');




        $form_contact_form_input_padding_left_right = json_decode('{"attribute": "padding",
																		"value":"0 ' . $base_json->form_contact_form_input_padding_left_right . 'px"}');
        
        $form_contact_form_font_color = json_decode('{"attribute": "color","value":"' . $base_json->form_contact_form_font_color . '"}');

        /** Append them into the json * */
        $new_json->af2_answer_card = array($form_answer_card_icon_color, $form_answer_card_background_color,
            $form_answer_card_border_radius, $form_box_shadow_color_answer_card);
        $new_json->af2_slider_image_icon_wrapper = array($form_answer_card_icon_color);
        $new_json->af2_form_heading = array($form_heading_color,
            $form_heading_size_desktop, $form_heading_size_mobile, $form_heading_weight, $form_heading_line_height_desktop, $form_heading_line_height_mobile);
        $new_json->af2_question_heading = array($form_question_heading_color,
            $form_question_heading_size_desktop, $form_question_heading_size_mobile, $form_question_heading_weight, $form_question_heading_line_height_desktop, $form_question_heading_line_height_mobile);
        $new_json->af2_question_description = array($form_question_description_color,
            $form_question_description_size_desktop, $form_question_description_size_mobile, $form_question_description_weight, $form_question_description_line_height_desktop, $form_question_description_line_height_mobile);
        
        $new_json->af2_answer_text = array($form_answer_card_text_color,
            $form_answer_card_text_size_desktop, $form_answer_card_text_size_mobile, $form_answer_card_text_weight, $form_answer_card_text_line_height_desktop, $form_answer_card_text_line_height_mobile);
        $new_json->af2_form = array($form_answer_card_border_radius, $form_background_color,$form_font, $form_answer_card_border_radius);
        $new_json->af2_form_button = array($form_font, $form_answer_card_border_radius, $form_button_background_color, $form_button_disabled_background_color,$form_button_label_text_desktop,$form_button_label_text_mobile);
        $new_json->af2_form_progress = array($form_progress_bar_color);
        $new_json->af2_form_progress_bar = array($form_progress_bar_unfilled_background_color);
        $new_json->af2_textfeld_frage = array($form_box_shadow_color, $form_input_background_color,
            $form_text_input_size_desktop, $form_border_color, $form_text_input_size_mobile, $form_text_input_weight, $form_text_input_line_height_desktop, $form_text_input_line_height_mobile,
            $form_text_input_border_radius, $form_box_shadow_color_unfocus);
        $new_json->af2_textbereich_frage = array($form_box_shadow_color, $form_input_background_color,
            $form_text_input_size_desktop, $form_text_input_size_mobile, $form_text_input_weight, $form_text_input_line_height_desktop, $form_text_input_line_height_mobile,
            $form_text_input_border_radius, $form_border_color, $form_box_shadow_color_unfocus);
        
        $new_json->af2_datum_frage = array($form_box_shadow_color, $form_input_background_color,
            $form_text_input_size_desktop, $form_text_input_size_mobile, $form_text_input_weight, $form_text_input_line_height_desktop, $form_text_input_line_height_mobile,
            $form_text_input_border_radius, $form_border_color, $form_box_shadow_color_unfocus);
        
        // datepicker styling
        $datepicker_header_backgroud = json_decode('{"attribute": "background-color","value":"' . $base_json->form_datepicker_background_color . '", "special_class":"af2_datepicker","sub_class":"ui-datepicker-title"}');
        $datepicker_header_color = json_decode('{"attribute": "color","value":"' . $base_json->form_datepicker_color . '", "special_class":"af2_datepicker","sub_class":"ui-datepicker-title"}');
        $new_json->af2_datepicker_header = array($datepicker_header_backgroud,$datepicker_header_color);
        
        $new_json->{'ui-datepicker-title'} = array($form_font);
        $new_json->{'desktop .ui-datepicker-title'} = array($form_answer_card_text_size_desktop_);
        $new_json->{'af2_mobile .ui-datepicker-title'} = array($form_answer_card_text_size_mobile_);
        
        $datepicker_active_backgroud = json_decode('{"attribute": "background-color","value":"' . $base_json->form_datepicker_background_color . ' !important", "special_class":"af2_datepicker","sub_class":"ui-datepicker-current-day"}');
        $datepicker_active_color = json_decode('{"attribute": "color","value":"' . $base_json->form_datepicker_color . ' !important", "special_class":"af2_datepicker","sub_class":"ui-state-active"}');
        $new_json->af2_datepicker_active = array($datepicker_active_backgroud,$datepicker_active_color);
        
        $new_json->af2_question_wrapper = array($form_contact_form_font_color);
        $new_json->af2_text_type = array($form_contact_form_input_padding_left_right, $form_box_shadow_color, $form_border_color, $form_input_background_color, $form_contact_form_input_size, $form_contact_form_input_weight, $form_contact_form_input_height, $form_contact_form_input_border_radius,$form_contact_form_font_color, $form_box_shadow_color_unfocus);
        $new_json->{'af2_text_type.af2_rtl_layout'} = array($form_contact_form_input_border_radiuslr);
        $new_json->af2_text_type_ = array($form_contact_form_input_padding_left_right, $form_box_shadow_color, $form_border_color, $form_input_background_color, $form_contact_form_input_size, $form_contact_form_input_weight, $form_contact_form_input_height, $form_contact_form_input_border_radius_,$form_contact_form_font_color, $form_box_shadow_color_unfocus);
        $new_json->af2_slider_frage = array($form_box_shadow_color, $form_slider_frage_thumb_background_color, $form_slider_frage_thumb_background_color2,$form_slider_frage_background_color, $form_box_shadow_color_unfocus);
        $new_json->af2_slider_frage_bullet = array($form_question_heading_size_desktop, $form_question_heading_size_mobile, $form_question_heading_weight, $form_slider_frage_bullet_color);
        $new_json->af2_slider_frage_val = array($form_border_color, $form_box_shadow_color, $form_answer_card_text_size_desktop, $form_answer_card_text_size_mobile, $form_text_input_weight, $form_box_shadow_color_unfocus);
        $new_json->af2_slider_frage_val_after = array($form_text_input_border_radius_);
        $new_json->af2_slider_frage_val_before = array($form_text_input_border_radiuslr);
        $new_json->{'af2_slider_frage_val_after.af2_rtl_layout'} = array($form_text_input_border_radiuslr);
        $new_json->{'af2_slider_frage_val_before.af2_rtl_layout'} = array($form_text_input_border_radius_);

        //$new_json['select2-search__field'] = array($form_text_input_border_radius);
        
        // 2.0.9.2
        $new_json->af2_question_label = array($form_contact_form_label_size_, $form_text_input_size_mobile, $form_contact_form_label_weight);
        $new_json->af2_radio_label = array($form_contact_form_input_size, $form_contact_form_input_weight);
        $new_json->af2_submit_button = array($form_contact_form_button_background_color_rgb, $form_contact_form_button_color_rgb, $form_font,$form_contact_form_button_color, $form_contact_form_button_size, $form_contact_form_button_weight, $form_contact_form_button_padding_top_bottom,$form_contact_form_button_padding_left,$form_contact_form_button_padding_right, $form_contact_form_button_border_radius, $form_contact_form_button_background_color);
        $new_json->af2_question_cb_label = array($form_contact_form_cb_size, $form_contact_form_cb_weight);
        
        $new_json->af2_dateiupload_inner = array($form_answer_card_border_radius);
        
        
        $new_json->af2_form_html_content = array($form_contact_form_label_size, $form_contact_form_label_weight);
        
        // 2.1.2
        $new_json->af2_form_loader = array($form_loader_color);
        $new_json->af2_address_field_ = array($form_answer_card_border_radius);
        $new_json->af2_adress_map_input_wrapper = array($form_answer_card_border_radius);
        $new_json->af2_html_content_summary = array($form_answer_card_border_radius);

        $new_json->af2_ahref = array($form_contact_form_button_background_color_);

        //$new_json->af2_form_percentage 	= array( $buffer_main_background_color );
        /*         * }
          /** NEW VARIANT **
          else
          {
          //DO ANYTHING
          } */

          $new_json->af2_question_cf_text_type_icon = array($form_contact_form_button_background_color, $form_contact_form_input_height, $form_contact_form_input_border_radiuslr);
          $new_json->{'af2_question_cf_text_type_icon.af2_rtl_layout'} = array($form_contact_form_input_border_radius);
          $new_json->af2_ad_trans = array($form_font, $form_text_input_border_radius, $form_border_color, $form_box_shadow_color, $form_text_input_size_desktop, $form_text_input_size_mobile, $form_text_input_weight, $form_box_shadow_color_unfocus);
          $new_json->alternate_text_wrap_span = array($form_contact_form_button_background_color, $form_answer_card_text_size_desktop, $form_answer_card_text_size_mobile, $form_answer_card_text_weight);
          $new_json->alternate_text_wrap_span_before = array($form_text_input_border_radius_);
          $new_json->alternate_text_wrap_span_after = array($form_text_input_border_radiuslr);
          $new_json->{'alternate_text_wrap_span_before.af2_rtl_layout'} = array($form_text_input_border_radiuslr);
          $new_json->{'alternate_text_wrap_span_after.af2_rtl_layout'} = array($form_text_input_border_radius_);
          $new_json->af2_ad_trans_tabel = array($form_answer_card_text_weight, $form_answer_card_text_size_desktop, $form_answer_card_text_size_mobile);
          $new_json->af2_html_content_summary_object_title_ = array($form_answer_card_text_size_desktop, $form_answer_card_text_size_mobile);
          $new_json->af2_html_content_summary_object_answer_ = array($form_answer_card_text_weight, $form_answer_card_text_size_desktop, $form_answer_card_text_size_mobile);
          
          $new_json->range_text_box_label = array($form_answer_card_text_size_desktop, $form_answer_card_text_size_mobile, $form_answer_card_text_weight);
          
          $new_json->af2_response_error = array($form_contact_form_label_size, $form_contact_form_label_weight);

          $new_json->{'af2-select2-container input.select2-search__field'} = array($form_fontfc, $form_border_colorfc, $form_box_shadow_colorfc, $form_answer_card_text_weightfc, $form_text_input_border_radiusfc);
          $new_json->{'af2-select2-container.desktop input.select2-search__field'} = array($form_answer_card_text_size_desktop_fc);
          $new_json->{'af2-select2-container.af2_mobile input.select2-search__field'} = array($form_answer_card_text_size_mobile_fc);

          $new_json->{'af2-select2-container.select2-selection.select2-selection--single'} = array($form_fontfc, $form_border_colorfc, $form_box_shadow_colorfc, $form_answer_card_text_weightfc);
          $new_json->{'af2-select2-container.desktop.select2-selection.select2-selection--single'} = array($form_answer_card_text_size_desktop_fc);
          $new_json->{'af2-select2-container.af2_mobile.select2-selection.select2-selection--single'} = array($form_answer_card_text_size_mobile_fc);
          
          $new_json->{'select2-results__option.select2-results__option--selectable'} = array($form_fontfc, $form_answer_card_text_weightfc);
          $new_json->{'af2-select2-container.desktop .select2-results__option.select2-results__option--selectable'} = array($form_answer_card_text_size_desktop_fc);
          $new_json->{'af2-select2-container.af2_mobile .select2-results__option.select2-results__option--selectable'} = array($form_answer_card_text_size_mobile_fc);

          $new_json->{'af2-select2-container .select2-results__option.select2-results__option--selectable.select2-results__option--highlighted'} = array($form_contact_form_button_background_color_fc);
        
          $new_json->{'af2_terminbuchung_heading'} = array($form_font, $form_answer_card_text_size_desktop, $form_answer_card_text_size_mobile, $form_question_description_color);
          $new_json->{'af2_terminbuchung_time'} = array($form_contact_form_button_background_color_rgb);
          $new_json->{'af2_terminbuchung_duration'} = array($form_contact_form_button_background_color_rgb);
          $new_json->{'af2_notification'} = array($form_contact_form_button_color_rgb, $form_contact_form_button_background_color_rgb);

          $new_json->{'af2_terminbuchungs_wrap #select2-af2_zeitzone-container.select2-selection__rendered'} = array($form_contact_form_button_background_color_rgb);
          $new_json->{'af2_calender_wait--loading'} = array($form_contact_form_button_background_color_rgb);
          
          return $new_json;
    }

    /**
     * Returns the type of the Dataid
     *
     * -> element = Frage / Kontaktformular
     * -> redirect = redirect
     * -> interface = klicktipp / Deals and Projects / ...
     *
     * @param $dataid
     * @return string
     */
    private function af2_check_data_type($dataid) {
        return $dataid === null ? 'undefined' : ( is_numeric($dataid) ? 'element' :
                ( strpos($dataid, 'redirect') === false ? 'interface' : 'redirect' ) );
    }

    /**
     * Checking all input, that there is nothing bad in it
     * 	And returning the post, to reuse it.
     *
     * @param $dataid
     * @return string/post
     */
    private function af2_check_params_for_getting_content($dataid) {
        /** Validate the Content * */
        if (!is_numeric($dataid)) {
            return 'ERROR';
        }

        /** Getting the Post * */
        $base_post = get_post($dataid);

        /** Check that the post exists * */
        if ($base_post == null) {
            return 'ERROR';
        }

        /** Check that the post is really a Frage, a Kontaktformular, or a Formular * */
        $post_type = get_post_field('post_type', $base_post);             // Type of the Post

        if (( $post_type != 'af2_ai_frage' ) && ( $post_type != 'af2_ai_kontf' ) && ( $post_type != 'af2_ai_formular' )) {
            return 'ERROR';
        }

        return $base_post;
    }

    /**
     * Checking, if any error is given
     *
     * @param $json
     * @return string
     */
    private function af2_check_for_errors($json) {
        /*
         * INCOMING
         *
         * READING OUT OF DB
         */

        if (isset($json->error) && $json->error == true) {
            return 'ERROR';
        }
        return '';
    }

}

$openai_view = new OpenAIView();

add_shortcode('funnelforms_openai', array($openai_view, 'af2_generate_frontend'));

add_action('wp_ajax_af2_request_data_openai', array($openai_view, 'af2_get_data'));

function af2_create_openai_form() {
    if (!( check_ajax_referer('af2_FE_nonce', '_ajax_nonce') )) {
        die();
    }

    $answerObject = $_POST['answerObject'];

    $language = $answerObject[0]['answer'];
    $question_count = $answerObject[1]['answer'];
    $usage = $answerObject[2]['answer'];
    $question_types = $answerObject[3]['answer'];
    $form_mail = $answerObject[4]['answer'];

    $baseurl = 'https://prod.handlers.funnelforms.io/af2_openapi/prompt';
    $curlparams = '?language='.urlencode($language).'&questioncount='.urlencode($question_count).'&usage='.urlencode($usage).'&questiontypes='.urlencode($question_types);
    $curlurl = $baseurl.$curlparams;

    $ch = curl_init();
    $headers = array(
        'Accept: text/plain; charset=utf-8',
        'Content-Type: text/plain; charset=utf-8',
    );
    curl_setopt($ch, CURLOPT_URL, $curlurl);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_TIMEOUT, 600);

    $resp = curl_exec($ch);

    curl_close($ch);

    $openai_form_json = $resp;
    $openai_form_json = unicode_decode($openai_form_json);
    

    $openai_form_json = str_replace('\n', '', $openai_form_json);
    $openai_form_json = str_replace('\t', '', $openai_form_json);
    $openai_form_json = str_replace('\r', '', $openai_form_json);
    $openai_form_json = substr($openai_form_json, 1);
    $openai_form_json = substr($openai_form_json, 0, -1);
    $openai_form_json = stripslashes($openai_form_json);

    $json_start_position = strpos($openai_form_json, '{');
    if($json_start_position === false) {
        echo 'ERROR';
        die();
    }
    if($json_start_position !== 0) {
        $openai_form_json = substr($openai_form_json, $json_start_position);
    }

    $openai_form_json = json_decode($openai_form_json, true);

    if(!$openai_form_json || $openai_form_json == false) {
        echo 'ERROR';
        die();
    }

    $post_ids = array();
    foreach($openai_form_json['questions'] as $question) {
        switch($question['typ']) {
            case 'af2_select': {
                $question['desktop_layout'] = 'grid';
                $question['mobile_layout'] = 'list';
                $question['hide_icons'] = false;
                $question['tracking_code'] = '';
                break;
            }
            case 'af2_multiselect': {
                $question['desktop_layout'] = 'grid';
                $question['mobile_layout'] = 'list';
                $question['hide_icons'] = false;
                $question['tracking_code'] = '';
                $question['condition'] = null;
                break;
            }
            case 'af2_textfeld': {
                $question['min_length'] = null;
                $question['max_length'] = null;
                $question['text_birthday'] = false;
                $question['text_only_numbers'] = false;
                $question['text_only_text'] = false;
                $question['textfield_mandatory'] = true;
                $question['tracking_code'] = '';
                break;
            }
            case 'af2_datum': {
                $question['datemandatory'] = true;
                $question['datum_format'] = "dd.mm.yy";
                $question['tracking_code'] = '';
                break;
            }
            case 'af2_slider': {
                $question['min'] = strval($question['min']);
                $question['max'] = strval($question['max']);
                $question['step'] = strval($question['step']);
                $question['start'] = strval($question['start']);
                $question['text_manual'] = null;
                $question['slider_image'] = null;
                $question['thousand'] = true;
                $question['tracking_code'] = '';
                $question['lab'] = true;
                break;
            }
            case 'af2_dateiupload': {
                $question['fileupload_desc'] = __('Dateien hier ablegen', 'af2_multilanguage');
                $question['tracking_code'] = '';
                $question['fileupload_mandatory'] = true;
                $question['fileupload_public'] = false;
                $question['fileupload_max_size'] = "10";
                $question['fileupload_max_count'] = "10";
                break;
            }
            case 'af2_dropdown': {
                $question['tracking_code'] = '';
                break;
            }
            case 'af2_adressfeld': {
                $question['tracking_code'] = '';
                $question['mapmandatory'] = true;
                break;
            }
        }
        $question_insert_data = urlencode(serialize($question));
        $post_id = wp_insert_post(array('post_content' => $question_insert_data, 'post_type' => FRAGE_POST_TYPE, 'post_status' => 'privat', 'post_title' => ''));
        array_push($post_ids, $post_id);
    }

    $contact_form_insert_data = array();

    $contact_form_question_data = '[{"typ":"text_type_name","icon":"fas fa-user","label":"Ihr Name","placeholder":"","required":true,"id":"name"},{"typ":"text_type_mail","icon":"fas fa-envelope","label":"Ihre E-Mail Adresse","placeholder":"","required":true,"id":"mail"},{"typ":"text_type_phone","icon":"fas fa-phone","label":"Ihre Telefonnummer","required":true,"id":"telefon","placeholder":" "},{"typ":"checkbox_type","text":"Hiermit akzeptiere ich die Datenschutzbestimmungen","required":true,"id":"checkbox"}]';
    $contact_form_question_data = json_decode($contact_form_question_data, true);
    $contact_form_insert_data['questions'] = $contact_form_question_data;
    $contact_form_insert_data['cftitle'] = 'Kontaktdaten eingeben';
    $contact_form_insert_data['description'] = '';
    $contact_form_insert_data['name'] = __('Funnelforms AI Kontaktformular', 'af2_multilanguage');
    $contact_form_insert_data['send_button'] = 'Formular absenden';
    $contact_form_insert_data['mailfrom_name'] = get_option('blogname');
    $contact_form_insert_data['mailfrom'] = 'wordpress@'.parse_url(get_site_url(), PHP_URL_HOST);
    $contact_form_insert_data['mailto'] = $form_mail;
    $contact_form_insert_data['mailcc'] = '';
    $contact_form_insert_data['mailbcc'] = '';
    $contact_form_insert_data['mail_replyto'] = '';
    $contact_form_insert_data['mailsubject'] = __('Neuer Lead', 'af2_multilanguage');
    $contact_form_insert_data['mailtext'] = "[name]\n\n[mail]\n\n[telefon]\n\n[checkbox]\n\n[ANTWORTEN]\n\n";
    $contact_form_insert_data['show_bottombar'] = true;
    $contact_form_insert_data['use_autorespond'] = false;
    $contact_form_insert_data['use_smtp'] = false;
    $contact_form_insert_data['use_wp_mail'] = false;
    $contact_form_insert_data['tracking_code'] = '';
    $contact_form_insert_data['tracking_code_after'] = '';
    $contact_form_insert_data['autoresponder_field'] = '';
    $contact_form_insert_data['autoresponder_subject'] = '';
    $contact_form_insert_data['autoresponder_nachricht'] = '';
    $contact_form_insert_data['smtp_host'] = '';
    $contact_form_insert_data['smtp_username'] = '';
    $contact_form_insert_data['smtp_password'] = '';
    $contact_form_insert_data['smtp_port'] = '';
    $contact_form_insert_data['smtp_type'] = 'ssl';
    $contact_form_insert_data['attachment_url'] = null;
    $contact_form_insert_data['redirect_params'] = array();

    $contact_form_insert_data = urlencode(serialize($contact_form_insert_data));
    $contact_form_post_id = wp_insert_post(array('post_content' => $contact_form_insert_data, 'post_type' => KONTAKTFORMULAR_POST_TYPE, 'post_status' => 'privat', 'post_title' => ''));
    array_push($post_ids, $contact_form_post_id);

    $form_insert_data = array('error' => true);
    $form_insert_data['name'] = __('Funnelforms AI Formular', 'af2_multilanguage');
    $form_insert_data['migration'] = true;

    $form_insert_data['sections'] = array();

    $i = 0;
    foreach($post_ids as $post_id) {
        if($i <= 0) {
            array_push($form_insert_data['sections'], array('contents' => array( array( 'data' => $post_id, 'connections' => array( array( 'to_section' => $i+1, 'to_content' => 0, 'from' => -1 ) ), 'incoming_connections' => array() ) )));
        }
        else if($i >= count($post_ids)-1) {
            array_push($form_insert_data['sections'], array('contents' => array( array( 'data' => $post_id, 'connections' => array(), 'incoming_connections' => array( array( 'from_section' => $i-1, 'from_content' => 0, 'from' => -1 ) ) ) )));
        }
        else {
            array_push($form_insert_data['sections'], array('contents' => array( array( 'data' => $post_id, 'connections' => array( array( 'to_section' => $i+1, 'to_content' => 0, 'from' => -1 ) ), 'incoming_connections' => array( array( 'from_section' => $i-1, 'from_content' => 0, 'from' => -1 ) ) ) )));
        }
        

       
        $i++;
    }

    $form_insert_data = urlencode(serialize($form_insert_data));
    wp_insert_post(array('post_content' => $form_insert_data, 'post_type' => FORMULAR_POST_TYPE, 'post_status' => 'privat', 'post_title' => ''));

    wp_die();
}
function replace_unicode_escape_sequence($match) {
    return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');
}

function unicode_decode($str) {
    return preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $str);
}

add_action('wp_ajax_af2_create_openai_form', 'af2_create_openai_form');