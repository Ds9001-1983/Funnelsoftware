<?php

require_once AF2_MENU_PARENTS_CLASS;
class Af2Lizenzen extends Af2MenuCustom {

    protected function get_heading() { return 'License & App'; }
    protected function get_menu_custom_template() { return AF2_CUSTOM_MENU_LIZENZ; }
    

    protected function load_resources() {
        wp_enqueue_style('af2_lizenz_style');
        wp_enqueue_script('af2_lizenz');
        wp_localize_script( 'af2_lizenz', 'af2_lizenz_object', array(
            'strings' => array(
                'domain_activated' => __('The domain is activated!', 'af2_multilanguage')
            ),
        ));
        parent::load_resources();
    }

}