<?php

//FOR DEBUGGIN PURPOSE
/*
add_action( 'wp_mail_failed', 'onMailError', 10, 1 );
    function onMailError( $wp_error ) {
        echo "<pre>";
        print_r($wp_error);
        echo "</pre>";
    }   
*/

class Af2AjaxTestmail {

    function __construct() {}

    public function af2_test_mail() {

        if ( !current_user_can( 'edit_others_posts' ) ) {
            die( 'Permission denied' );
        }

        if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'af2_FE_nonce' ) ) {
            die( 'Permission denied' );
        }

        $smtp = $_POST['use_smtp'];
        $wp_mail = $_POST['use_wp_mail'];
    
    
        if ($smtp === true || $smtp === 'true') {
            $cc = $_POST['cc'];
            $bcc = $_POST['bcc'];
            $cc_list = explode(',', $cc);
            $bcc_list = explode(',', $bcc);
    
            $resp = $this->af2_smtp_mail($_POST['host'], $_POST['username'], $_POST['password'], $_POST['port'], $_POST['type'], $_POST['to'], $_POST['from'], $_POST['from_name'], __('Testmail'), __('Dies ist eine Testmail vom Funnelforms Pro Plugin per SMTP'), $cc_list, $bcc_list,$_POST['reply_to']);
            $arr = [];
    
            if (!$resp)
                $arr = array('status' => 'Error', 'message' => __("Bitte konfiguriere deine SMTP Einstellungen", 'af2_multilanguage'), 'resp' => $resp);
    
            //$arr = array('status' => $resp->status, 'message' => ( $resp->status == 'Success' ? __('E-mail sent successfully!', 'af2_multilanguage') : __("E-Mail konnte nicht gesendet werden!", 'af2_multilanguage') ), 'resp' => $resp);
    
            //echo $arr['status'] . ' : ' . $arr['message'];
        }
        else {
            $headers = 'From: ' . $_POST['from_name'] . ' <' . $_POST['from'] . '>' . "\r\n";
            $headers .= 'CC: ' . $_POST['cc'] . "\r\n";
            $headers .= 'BCC: ' . $_POST['bcc'] . "\r\n";
    
            if ($wp_mail === true || $wp_mail === 'true') {
                wp_mail($_POST['to'], __('Testmail', 'af2_multilanguage'), __('This is a test mail from the Funnelforms Pro plugin', 'af2_multilanguage'), $headers);
    
                echo __('Testmail sent with WP Mail. Please check your mailbox!', 'af2_multilanguage');
            } else {
                mail($_POST['to'], __('Testmail', 'af2_multilanguage'), __('This is a test mail from the Funnelforms Pro plugin', 'af2_multilanguage'), $headers);
    
                echo __('Testmail sent without SMTP. Please check your mailbox!', 'af2_multilanguage');
            }
        }
    
    
        //echo $resp;
    
        wp_die();
    }
    
    private function af2_smtp_mail($host, $user, $password, $port, $type, $to, $from, $from_nam, $subject, $body, $cc, $bcc,$reply_to) {
        //$errors = '';
    
        //$swpsmtp_options = get_option('twm_smtp_options');
    
        require_once( ABSPATH . WPINC . '/class-smtp.php' );
        require_once( ABSPATH . WPINC . '/class-phpmailer.php' );
        
        $mail = new \PHPMailer();
    
        $charset = get_bloginfo('charset');
        $mail->CharSet = $charset;
        $mail->Timeout = 10;
    
        $from_name = $from_nam;
        $from_email = $from;
    
        $mail->IsSMTP();
    
        $mail->SMTPAuth = true;
        $mail->Username = $user;
        $mail->Password = $password;
    
        $mail->SMTPSecure = $type;
    
        /* PHPMailer 5.2.10 introduced this option. However, this might cause issues if the server is advertising TLS with an invalid certificate. */
        $mail->SMTPAutoTLS = false;
    
        /* Set the other options */
        $mail->Host = $host;
        $mail->Port = $port;
    
        $mail->SetFrom($from_email, $from_name);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->MsgHTML($body);
        $mail->AddAddress($to);
    
        foreach ($cc as $c) {
            $c = trim($c);
    
            $mail->addCC($c);
        }
    
        foreach ($bcc as $bc) {
            $bc = trim($bc);
    
            $mail->addBCC($bc);
        }
    
        if(!empty($reply_to)){
            $mail->addReplyTo($reply_to);
        }
        
        $mail->SMTPDebug = 4;
    
        /* Send mail and return result */
    
        $error = $mail->Send();
    
        $mail->ClearAddresses();
        $mail->ClearAllRecipients();
        $mail->clearCCs();
        $mail->clearBCCs();
    
        return $error;
    }
}
