<?php


class Af2AjaxLizenz {

    function __construct() {}

    public function af2_do_license_check() {
        $key = get_option('af2_license_key');

        $newKey = trim($_POST['key']);

        $licenseKeyRegex2 = '/^[0-9A-Z]{8}-[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{12}$/i';
   
        $urlparts = parse_url(home_url());
        $domain = $urlparts['host'];
        
        if($key != $newKey && preg_match($licenseKeyRegex2, $key) && preg_match($licenseKeyRegex2, $newKey)) {
            require_once AF2_MISC_FUNCTIONS_PATH;
            $resp = af2_unnizza($key, $domain);
        }

        update_option('af2_license_key', $newKey);
        
        $urlparts = parse_url(home_url());
        $domain = $urlparts['host'];
        $key = get_option('af2_license_key');


        require_once AF2_MISC_FUNCTIONS_PATH;
        $resp = af2_nizza($key, $domain);

        echo __($resp, 'af2_multilanguage');
        wp_die();
    }

    public function af2_delete_app() {
        update_option('af2_registered_app_code', '');
        update_option('af2_registered_app_device', '');
        update_option('af2_registered_app_fcm', '');

        if(get_option('af2_license_stat') == 'Die Domain ist aktiviert!') {
            $randomNum = substr(str_shuffle("012345678901234567890123456789012345678901234567890123456789abcdefghijklmnopqrstuvwxyzabcdefghijklmopqrstuvwxyzsdjafkleiwopvnjkdvncyfeiawojkldsmvcxy"), 0, 32);
            update_option('app_code', $randomNum);

            $valcode = get_option('app_code');
            $prefix = str_replace("wp-admin/", "", get_admin_url());
            $qrlink = $prefix.'wp-json/af2/app/v2/register_qr?val_code='.$valcode;

            update_option('app_qr_code', $qrlink);
        }
        else {
            update_option('app_code', '');
            update_option('app_qr_code', '');
        }
    }
}
