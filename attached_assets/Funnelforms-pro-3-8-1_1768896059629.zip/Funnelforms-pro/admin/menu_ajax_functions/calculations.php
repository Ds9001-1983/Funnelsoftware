<?php

class Af2AjaxCalculations {

    private $Admin = null;
    
    function __construct($Admin) {
        $this->Admin = $Admin;
    }

     // Functions

     function af2_calculate_formula_live() {

        $evaluator = new \Matex\Evaluator();
        $post   = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
        $error = false;

        // get answers
        $answers = $post['answers'];
        $answersSorted = [];
        foreach ($answers as $a) {
            if(array_key_exists($a['question'], $answersSorted)) {
                $answersSorted[$a['question']] = array($answersSorted[$a['question']]);
                $answersSorted[$a['question']][] = $a['index'];
            } else {
                $answersSorted[$a['question']] = $a['index'];
            }
            //$answersSorted[$a['question']] = $a['index'];
        }

        // get formula string
        $formulaId = $post['formulaId'];
        $formulaObj = get_post($formulaId);
        if(!$formulaObj) {
            echo json_encode(["success" => false, "message" => __("The Calculation ID is invalid!", 'af2_multilanguage')]);
            die();
        }
        $post_content = af2_get_post_content($formulaObj);
        $formulaString = $post_content['calculate_formula'];
        $decimals = $post_content['formula_decimal_count'] ?? 2;
        $decimals = intval($decimals);
        $decimal_separator = $post_content['formula_decimal_separator'] ?? ".";
        $thousands_separator = $post_content['formula_thousands_separator'] ?? ",";

        // extract question ids from formula string
        $pattern = '/\[(\d+)\]/';
        $matches = [];
        if(preg_match_all($pattern, $formulaString, $results)) {
            $matches = $results[1];
        }
        $questions = array_map('intval', $matches);

        // check question matches in formula string
        foreach($questions as $question) {

            if(array_key_exists($question, $answersSorted)) {
                // replace question placeholder with value of selected answer

                $indexForAnswer = $answersSorted[$question];
                if(is_array($answersSorted[$question])) {
                    //$errors .= __("Answer for question was found multiple times, so only the last one used:", 'af2_multilanguage')." ".$question." \n";
                    $indexForAnswer = end($answersSorted[$question]);
                } 
                
                $questionObj = get_post($question);
                $post_content = af2_get_post_content($questionObj);

                if($post_content['typ'] == 'af2_select') {
                    $answers = $post_content['answers'];
                    $answer = $answers[$indexForAnswer];
                    $calculationValue = $answer['calculation_value'];
                    $replace = "[".$question."]";
                    $formulaString = str_replace($replace, $calculationValue, $formulaString);
                }
                else if($post_content['typ'] == 'af2_textfeld') {
                    $replace = "[".$question."]";
                    $formulaString = str_replace($replace, $indexForAnswer, $formulaString);
                }
                else if($post_content['typ'] == 'af2_dropdown') {
                    $answers = $post_content['dropdown_options'];
                    $answer = $answers[$indexForAnswer];
                    $calculationValue = $answer['calculation_value'];
                    $replace = "[".$question."]";
                    $formulaString = str_replace($replace, $calculationValue, $formulaString);
                }
                else if($post_content['typ'] == 'af2_slider') {
                    $replace = "[".$question."]";
                    $formulaString = str_replace($replace, $indexForAnswer, $formulaString);
                }

            } else {
                // if a placeholder is missing we can't evaluate the formula
                //$errors .= __("Answer for question not found so it got replaced by the value 0:", 'af2_multilanguage')." ".$question." \n";
                $replace = "[".$question."]";
                $formulaString = str_replace($replace, 0, $formulaString);
            }
        }

        $value = "";

        try {
            $value = $evaluator->execute($formulaString);
        } catch (Exception $e) {
            $error = true;
        }

        if($error == true) {
            $value = __('An error occured in the calculation!', 'af2_multilanguage');
        }

        if($error) {
            echo json_encode(["success" => false, "message" => $value]);
        } else {
            $value = number_format($value, $decimals, $decimal_separator, $thousands_separator);
            echo json_encode(["success" => true, "message" => $value]);
        }

        die();
    }

    function af2_calculate_formula_check() {
        require_once AF2_ADMIN_HELPER_PATH;
        $formula = $_POST['formula'];

        $decimals = 2;
        $decimal_separator = ".";
        $thousands_separator = ",";

        $formulaObj = get_post($_POST['post_id']);
        if($formulaObj) {
            $post_content = af2_get_post_content($formulaObj);
            $decimals = $post_content['formula_decimal_count'] ?? 2;
            $decimals = intval($decimals);
            $decimal_separator = $post_content['formula_decimal_separator'] ?? ".";
            $thousands_separator = $post_content['formula_thousands_separator'] ?? ",";
        }

        $success = true;
        $message = "";

        // extract question ids from formula string
        $pattern = '/\[(\d+)\]/';
        $matches = [];
        if(preg_match_all($pattern, $_POST['formula'], $results)) {
            $matches = $results[1]; // Capturing group results
        }
        $questions = array_map('intval', $matches);

        // check question matches in formula string
        foreach($questions as $question) {
            $questionObj = get_post($question);
            $post_content = af2_get_post_content($questionObj);
            if(!$post_content) {
                $success = false;
                $message .= __("Question not found", 'af2_multilanguage').': '.$question;
                break;
            } else {
                $question_type = __(Af2AdminHelper::af2_convert_question_type($post_content['typ']), 'af2_multilanguage');
                $message .= __("Checking", 'af2_multilanguage')." ".$question." (".$question_type."): ";
                $error = false;

                if($post_content['typ'] == 'af2_select') {
                    foreach($post_content['answers'] as $answer) {
                        if(!isset($answer['calculation_value']) || !is_numeric($answer['calculation_value'])) {
                            $error = true;
                            break;
                        }
                    }
                    if($error) {
                        $message .= __("Calculation value missing", 'af2_multilanguage');
                    }
                }
                else if($post_content['typ'] == 'af2_dropdown') {
                    foreach($post_content['dropdown_options'] as $answer) {
                        if(!isset($answer['calculation_value']) || !is_numeric($answer['calculation_value'])) {
                            $error = true;
                            break;
                        }
                    }
                    if($error) {
                        $message .= __("Calculation value missing", 'af2_multilanguage');
                    }
                }
                else if($post_content['typ'] == 'af2_textfeld') {

                    $error = !$post_content['text_only_numbers'];

                    if($error) {
                        $message .= __("Not a numbers only field", 'af2_multilanguage');
                    }
                }

                if(!$error) {
                    $message .= __("OK", 'af2_multilanguage');
                }
                $message .= "<br>";
            }
        }

        // check formula
        $formula = preg_replace('/\[\d+\]/', '1', $_POST['formula']);


        try {
            $evaluator = new \Matex\Evaluator();
            $exampleValue = $evaluator->execute($formula);

            $exampleValue = number_format($exampleValue, $decimals, $decimal_separator, $thousands_separator);

            $message .= __("Calculating result (every question result = 1):", 'af2_multilanguage').' '.$exampleValue; // translations could be improved by using sprintf
        } catch(Exception $exception) {
            $success = false;
            $message .= __('Formula not valid', 'af2_multilanguage');
        }

        echo json_encode(['success'=>$success, 'message'=>$message]);
        die();
    }
}
