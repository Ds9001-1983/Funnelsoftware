<?php

class Af2AjaxIntegration {

    function __construct() {}

    public function af2_save_integration_credentials() {
        if(!isset($_POST['integrationid'])) wp_die();

        switch($_POST['integrationid']) {
            case 'dealsnprojects': {
                if(isset($_POST['af2_dnp_mail'])) update_option('af2_dnp_mail', $_POST['af2_dnp_mail']);
                if(isset($_POST['af2_dnp_api_key'])) update_option('af2_dnp_api_key', $_POST['af2_dnp_api_key']);
                break;
            }
            case 'activecampaign': {
                if(isset($_POST['af2_ac_url'])) update_option('af2_ac_url', $_POST['af2_ac_url']);
                if(isset($_POST['af2_ac_key'])) update_option('af2_ac_key', $_POST['af2_ac_key']);
                break;
            }
            case 'mailchimp': {
                if(isset($_POST['af2_mc_url'])) update_option('af2_mc_url', $_POST['af2_mc_url']);
                if(isset($_POST['af2_mc_key'])) update_option('af2_mc_key', $_POST['af2_mc_key']);
                break;
            }
            case 'pipedrive': {
                if(isset($_POST['af2_pipedrive_api_url'])) update_option('af2_pipedrive_api_url', $_POST['af2_pipedrive_api_url']);
                if(isset($_POST['af2_pipedrive_api_key'])) update_option('af2_pipedrive_api_key', $_POST['af2_pipedrive_api_key']);
                break;
            }
            case 'getresponse': {
                if(isset($_POST['af2_getresponse_api_key'])) update_option('af2_getresponse_api_key', $_POST['af2_getresponse_api_key']);
                break;
            }
            case 'hubspot': {
                if(isset($_POST['af2_hubspot_key'])) update_option('af2_hubspot_key', $_POST['af2_hubspot_key']);
                break;
            }
            case 'klicktipp': {
                if(isset($_POST['af2_klicktipp_user'])) update_option('af2_klicktipp_user', $_POST['af2_klicktipp_user']);
                if(isset($_POST['af2_klicktipp_pw'])) update_option('af2_klicktipp_pw', $_POST['af2_klicktipp_pw']);
                break;
            }
            case 'messagebird': {
                if(isset($_POST['af2_messagebird_key'])) update_option('af2_messagebird_key', $_POST['af2_messagebird_key']);
                break;
            }
            case 'fincrm': {
                if(isset($_POST['af2_fincrm_id'])) update_option('af2_fincrm_id', $_POST['af2_fincrm_id']);
                if(isset($_POST['af2_fincrm_token'])) update_option('af2_fincrm_token', $_POST['af2_fincrm_token']);
                break;
            }
            case 'hellohq': {
                if(isset($_POST['af2_hellohq_token'])) update_option('af2_hellohq_token', $_POST['af2_hellohq_token']);
                if(isset($_POST['af2_hellohq_refreshtoken'])) update_option('af2_hellohq_refreshtoken', $_POST['af2_hellohq_refreshtoken']);
                break;
            }
            case 'zapier': {
                if(isset($_POST['af2_zapier_pw'])) update_option('af2_zapier_pw', $_POST['af2_zapier_pw']);
                break;
            }
            case 'make': {
                if(isset($_POST['af2_make_pw'])) update_option('af2_make_pw', $_POST['af2_make_pw']);
                break;
            }
            default: {
                break;
            }
        }

        wp_die();
    }
}
