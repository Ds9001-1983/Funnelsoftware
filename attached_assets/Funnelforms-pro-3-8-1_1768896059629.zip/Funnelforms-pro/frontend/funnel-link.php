<?php

add_action('template_redirect', 'af2_funnel_link_interceptor');

function af2_funnel_link_interceptor() {
    if (preg_match('/^\/funnelforms\/([^\/]+)$/', $_SERVER['REQUEST_URI'], $matches)) {
        $slug = $matches[1];

        $slug = sanitize_text_field($slug);
        $post_id = af2_get_post_id_by_public_slug($slug);
        if(!is_null($post_id)) {
            add_filter('template_include', function() use ($post_id) {
                return af2_funnel_link_template($post_id);
            });
        }
    }
}

function af2_funnel_link_template($post_id) {
    set_query_var('af2_form_id', $post_id);
    return AF2_PLUGIN_DIR . '/res/frontend/templates/funnel-link.php';
}

function af2_register_form_public_slug_meta() {
    // is this the correct post type? or do we also need to consider other post types?
    register_post_meta(FORMULAR_POST_TYPE, '_public_slug', array(
        'show_in_rest' => true,
        'single' => true,
        'type' => 'string',
    ));
}
add_action('init', 'af2_register_form_public_slug_meta');

function af2_save_funnel_link_slug() {
    if (!isset($_POST['form_id']) || !isset($_POST['public_slug'])) {
        wp_send_json_error('Invalid data');
    }

    if ( ! isset( $_POST['_ajax_nonce'] ) || ! wp_verify_nonce( $_POST['_ajax_nonce'], 'af2_admin_form_nonce_' ) ) {
        wp_send_json_error('Invalid nonce');
    }

    $post_id = intval($_POST['form_id']);
    $public_slug = sanitize_title(sanitize_text_field($_POST['public_slug']));

    if (empty($public_slug)) {
        delete_post_meta($post_id, '_public_slug');
        wp_send_json_success(true);
    } else {
        update_post_meta($post_id, '_public_slug', $public_slug);
        wp_send_json_success($public_slug);
    }
}
add_action('wp_ajax_af2_save_funnel_link_slug', 'af2_save_funnel_link_slug');


function af2_get_post_id_by_public_slug($public_slug) {
    global $wpdb;

    // Sanitize the input
    $public_slug = sanitize_text_field($public_slug);

    // Validate the input
    if (empty($public_slug)) {
        return null;
    }

    // Prepare and execute the query
    $post_id = $wpdb->get_var($wpdb->prepare(
        "SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_public_slug' AND meta_value = %s",
        $public_slug
    ));

    return $post_id ? intval($post_id) : null;
}