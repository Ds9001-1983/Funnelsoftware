<?php

function create_timestamp() {
    $tz = 'Europe/Amsterdam';
    $timestamp = time();
    $dt = new DateTime("now", new DateTimeZone($tz));
    $dt->setTimestamp($timestamp);

    return $dt->format('YmdH');
}

function af2_create_lc_timestamp() {
    $tz = 'Europe/Amsterdam';
    $timestamp = time();
    $dt = new DateTime("now", new DateTimeZone($tz));
    $dt->setTimestamp($timestamp);

    return $dt->format('Ymd');
}

function af_base64UrlEncode($inputStr)
{
    return strtr(base64_encode($inputStr), '+/=', '-_,');
}


function af_base64UrlDecode($inputStr)
{
    return base64_decode(strtr($inputStr, '-_,', '+/='));
}

function af_get_months_array(){
    return array(
        1 => __('January', 'af2_multilanguage' ),
        2 => __('February', 'af2_multilanguage' ),
        3 => __('March', 'af2_multilanguage' ),
        4 => __('April', 'af2_multilanguage' ),
        5 => __('May', 'af2_multilanguage' ),
        6 => __('June', 'af2_multilanguage' ),
        7 => __('July', 'af2_multilanguage' ),
        8 => __('August', 'af2_multilanguage' ),
        9 => __('September', 'af2_multilanguage' ),
        10 => __('October', 'af2_multilanguage' ),
        11 => __('November', 'af2_multilanguage' ),
        12 => __('December', 'af2_multilanguage' )
    );
}

function af2_get_post_content( $post ) {
    require_once AF2_PLUGIN_DIR."/misc/array_serializer.php";
    if(empty($post) || $post == null) return null;
    $allowed_post_types = [
        FORMULAR_POST_TYPE,
        FRAGE_POST_TYPE,
        KONTAKTFORMULAR_POST_TYPE,
        CALCULATION_POST_TYPE,
        AI_FRAGE_POST_TYPE,
        AI_KONTAKTFORMULAR_POST_TYPE,
        AI_FORMULAR_POST_TYPE,
        TERMIN_POST_TYPE,
        TERMINEVENT_POST_TYPE,
        REQUEST_POST_TYPE,
        FRAGE_BACKUP_POST_TYPE,
        KONTAKTFORMULAR_BACKUP_POST_TYPE,
        FORMULAR_BACKUP_POST_TYPE,
        TERMIN_BACKUP_POST_TYPE,
        TERMINEVENT_BACKUP_POST_TYPE,
        REQUEST_BACKUP_POST_TYPE,
        'af2_categories',
        'af2_ver_codes',
    ];
    if(!in_array(get_post_type($post), $allowed_post_types)) { return null; }
    $post_content = get_post_field( 'post_content', $post );
    if(empty($post_content) || $post_content == null) return null;
    $post_content_array = urldecode($post_content);
    $post_content_array = Array_Serializer::secure_unserialize($post_content_array);
    
    if($post_content_array === false) {
        return null;
    }
    
    $post_content_array = stripslashes_deep($post_content_array);
    
    return $post_content_array;
}

function af2_str_contains( $haystack, $needle ) {
    if(function_exists('str_contains')) return str_contains($haystack, $needle);
    else return strpos($haystack, $needle) !== false;
}

function addToURL( $key, $value, $url) {
    $info = parse_url( $url );
    parse_str( $info['query'], $query );
    return $info['scheme'] . '://' . $info['host'] . $info['path'] . '?' . http_build_query( $query ? array_merge( $query, array($key => $value ) ) : array( $key => $value ) );
}

function af2GetLicenseTranslation($license_str) {
    $resp = $license_str;
    switch($license_str) {
        case 'Die Domain ist aktiviert!': {
            $resp = 'The domain is activated!';
            break;
        }
        case 'Diese Lizenz ist ausgelaufen.': {
            $resp = 'This license is expired.';
            break;
        }
        case 'Diese Domain ist nicht auf den Lizenzschlüssel registriert': {
            $resp = 'This domain is not registered for this license key';
            break;
        }
        case 'Ungültiger Lizenzschlüssel!': {
            $resp = 'Invalid license key!';
            break;
        }
    }

    return __($resp, 'af2_multilanguage');
}

function af2GetAnswersTranslations() {
    $supported_languages = array('de_AT', 'de_CH', 'de_DE', 'en_US', 'es_ES', 'fr_FR', 'it_IT', 'fr_FR');

    $translations = array();

    foreach ($supported_languages as $language) {
        switch_to_locale($language);

        $translated_text = __('[ANSWERS]', 'af2_multilanguage');

        array_push($translations, $translated_text);

        restore_previous_locale();
    }

    return $translations;
}

// ZUR RESPONSE INFO GEBEN DASS DER SUPPORT KONTAKTIERT WERDEN SOLL
// Umbau Lizenzsystem Step 2!
// Ebenfalls muss die Funktionalität sein, dass nur bei manueller überprüfung das passieren muss mit deaktivierung
function af2_nizza($license_key, $domain, $walkthrough = 0) {
    if (!get_option('af2_license_error_log')) {
        add_option('af2_license_error_log', '');
    }

     $licenseKeyRegex = '/^[0-9A-Z]{5}(-[0-9A-Z]{5}){7}$/i';
     $licenseKeyRegex2 = '/^[0-9A-Z]{8}-[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{12}$/i';

    if(preg_match($licenseKeyRegex, $license_key)) {
        $url = 'https://licenseserver-anfrageformular.com/key_validation/plugin_validation/plu_interface.php?passkey=1-dj!Activate281ThedaieksMenu192!E&event=checkthedomainevent&password=n&key=' . $license_key . '&domain=' . $domain;
        $args = array(
            'headers' => array(
                'Accept: text/plain',
                'Content-Type: text/plain'
            ),
            'timeout' => 30,
        );

        $response = wp_remote_get($url, $args);
        $resp = wp_remote_retrieve_body($response);

        if (strpos($resp, 'ADK2918dSS') !== false) {
            $resp = str_replace('ADK2918dSS', '', $resp);
        }

    }
    else if(preg_match($licenseKeyRegex2, $license_key)) {
        $url = 'https://prod.licenses.funnelforms.io/licences/activate?license_key='.$license_key.'&license_url=https://'.$domain;
            $args = array(
                'timeout' => 30,
            );
        
            $response = wp_remote_get($url, $args);
            $resp = wp_remote_retrieve_body($response);
            $respString = $resp;
        
            $resp = json_decode($resp);
        
            if($resp->success == true) {
                if($resp->license_status == 'valid') {
                    update_option('af2_license_stat', 'Die Domain ist aktiviert!');
                    update_option('af2_license_last_updated', af2_create_lc_timestamp());
                    return 'Die Domain ist aktiviert!';
                }
                else if($walkthrough < 1){
                    return af2_nizza($license_key, $domain, $walkthrough+1);
                }
            }

            if(isset($resp->errors->expired_license_key) && in_array('License key has been expired', $resp->errors->expired_license_key)) $resp = 'This license is expired.';
            else if(isset($resp->errors->can_not_add_new_domain) && in_array('Can not add a new domain.', $resp->errors->can_not_add_new_domain)) $resp = 'No new domain can be added!';
            else {
                /*$respStringLog = print_r($respString, true);
                $currentLog = get_option('af2_license_error_log');
                $timestamp = date('Y-m-d H:i:s');

                $currentLog .= "XX [$timestamp] Error: Error success is not true! Response: $respStringLog XX";
                update_option('af2_license_error_log', $currentLog);*/

                $resp = 'Invalid license key! If this error is not explainable, please contact support!';
            }
    }
    else {
        $resp = 'Invalid license key! If this error is not explainable, please contact support!';

        /*$currentLog = get_option('af2_license_error_log');
        $timestamp = date('Y-m-d H:i:s');

        $currentLog .= "XX [$timestamp] Error: Invalid Regex found XX";
        update_option('af2_license_error_log', $currentLog);*/
    }    

    
    update_option('af2_license_stat', $resp);
    update_option('af2_license_last_updated', af2_create_lc_timestamp());

    return $resp;
}

function af2_unnizza($license_key, $domain) {
    $url = 'https://prod.licenses.funnelforms.io/licences/deactivate?license_key='.$license_key.'&license_url=https://'.$domain;
        $args = array(
            'timeout' => 30,
        );
    
    $response = wp_remote_get($url, $args);
    $resp = wp_remote_retrieve_body($response);
}