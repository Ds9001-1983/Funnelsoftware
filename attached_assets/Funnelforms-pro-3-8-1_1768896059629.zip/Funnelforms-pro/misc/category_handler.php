<?php

function get_all_categories_vanilla() {
    require_once AF2_MISC_FUNCTIONS_PATH;

    $categories_id = intval(get_option('af2_categories'));
    $post = get_post($categories_id);
    
    return af2_get_post_content($post);
}

function get_all_categories() {
    $categories = get_all_categories_vanilla();

    $all_cats = array();
    if(!is_null($categories)) {
        foreach($categories as $category){
            array_push($all_cats, array('value'=>$category['id'], 'label'=>$category['label']));
        }
    }

    return $all_cats;
}

function get_category_id_of_element($elementid) {
    $categories = get_all_categories_vanilla();
    if(!is_null($categories)) {
        foreach($categories as $category) {
            if(in_array($elementid, $category['elements'])) return $category['id'];
        }
    }

    return 'empty';
}