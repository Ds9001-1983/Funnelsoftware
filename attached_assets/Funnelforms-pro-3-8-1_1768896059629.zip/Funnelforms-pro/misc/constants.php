<?php

// Paths
define( 'AF2_MULTILANGUAGE_HANDLER_PATH', AF2_PLUGIN_DIR.'/misc/multilanguage_handler.php' );

define( 'AF2_UPDATE', AF2_PLUGIN_DIR.'/plugin-update-checker/plugin-update-checker.php' );
define( 'AF2_WP_OPTIONS_PATH', AF2_PLUGIN_DIR.'/misc/options.php' );
define( 'AF2_VERSION_MIGRATION_PATH', AF2_PLUGIN_DIR.'/misc/version_migrations.php' );
define( 'AF2_MISC_FUNCTIONS_PATH', AF2_PLUGIN_DIR.'/misc/misc_functions.php' );
define( 'AF2_CATEGORY_HANDLER_PATH', AF2_PLUGIN_DIR.'/misc/category_handler.php' );
define( 'AF2_ADMIN_HANDLER_PATH', AF2_PLUGIN_DIR.'/admin/Admin.php' );
define( 'AF2_ADMIN_HELPER_PATH', AF2_PLUGIN_DIR.'/admin/AdminHelper.php' );
define( 'AF2_RESOURCE_HANDLER_PATH', AF2_PLUGIN_DIR.'/misc/resource_handler.php' );
define( 'AF2_MENU_AJAX_PATH', AF2_PLUGIN_DIR.'/admin/menu_ajax_functions/MenuAjax.php' );
define( 'AF2_HEALTHCHECK_PATH', AF2_PLUGIN_DIR.'/admin/Healthcheck.php' );

// Ajax
define( 'AF2_MENU_AJAX_TESTMAIL', AF2_PLUGIN_DIR.'/admin/menu_ajax_functions/testmail.php' );
define( 'AF2_MENU_AJAX_DASHBOARD', AF2_PLUGIN_DIR.'/admin/menu_ajax_functions/dashboard.php' );
define( 'AF2_MENU_AJAX_IMPORT', AF2_PLUGIN_DIR.'/admin/menu_ajax_functions/import.php' );
define( 'AF2_MENU_AJAX_DEMOIMPORT', AF2_PLUGIN_DIR.'/admin/menu_ajax_functions/demoimport.php' );
define( 'AF2_MENU_AJAX_LIZENZ', AF2_PLUGIN_DIR.'/admin/menu_ajax_functions/lizenz.php' );
define( 'AF2_MENU_AJAX_LEADS', AF2_PLUGIN_DIR.'/admin/menu_ajax_functions/leads.php' );
define( 'AF2_MENU_AJAX_INTEGRATION', AF2_PLUGIN_DIR.'/admin/menu_ajax_functions/integration.php' );
define( 'AF2_MENU_AJAX_EXTERNAL', AF2_PLUGIN_DIR.'/admin/menu_ajax_functions/external.php' );
define( 'AF2_MENU_AJAX_EXTERNAL_EMBED', AF2_PLUGIN_DIR.'/admin/menu_ajax_functions/external_embed.php' );
define( 'AF2_MENU_AJAX_CATEGORY', AF2_PLUGIN_DIR.'/admin/menu_ajax_functions/category.php' );
define( 'AF2_MENU_AJAX_CALCULATIONS', AF2_PLUGIN_DIR.'/admin/menu_ajax_functions/calculations.php' );
define( 'AF2_MENU_AJAX_FORMULARBUILDER_FONTS', AF2_PLUGIN_DIR.'/admin/menu_ajax_functions/formularbuilder_fonts.php' );

define( 'AF2_FRONTEND_PATH', AF2_PLUGIN_DIR.'/frontend/frontend.php' );
define( 'AF2_FRONTEND_FUNNEL_PATH', AF2_PLUGIN_DIR.'/frontend/funnel-link.php' );

define( 'AF2_ALL_ICONS_PATH', AF2_PLUGIN_DIR.'/res/all_icons.php' );

// Integrations
define( 'AF2_INTEGRATION_HANDLER_CLASS', AF2_PLUGIN_DIR.'/integrations/Integration_HandlerParent.php' );
define( 'AF2_INTEGRATION_HANDLER_ACTIVECAMPAIGN', AF2_PLUGIN_DIR.'/integrations/ActiveCampaign/ActiveCampaign_Integration_Handler.php' );
define( 'AF2_INTEGRATION_HANDLER_HUBSPOT', AF2_PLUGIN_DIR.'/integrations/HubSpot/HubSpot_Integration_Handler.php' );
define( 'AF2_INTEGRATION_HANDLER_DEALSNPROJECTS', AF2_PLUGIN_DIR.'/integrations/DealsNProjects/DealsNProjects_Integration_Handler.php' );
define( 'AF2_INTEGRATION_HANDLER_KLICKTIPP', AF2_PLUGIN_DIR.'/integrations/Klicktipp/Klicktipp_Integration_Handler.php' );
define( 'AF2_INTEGRATION_HANDLER_FINCRM', AF2_PLUGIN_DIR.'/integrations/FinCRM/FinCRM_Integration_Handler.php' );
define( 'AF2_INTEGRATION_HANDLER_HELLOHQ', AF2_PLUGIN_DIR.'/integrations/HelloHQ/HelloHQ_Integration_Handler.php' );
define( 'AF2_INTEGRATION_HANDLER_MESSAGEBIRD', AF2_PLUGIN_DIR.'/integrations/Messagebird/Messagebird_Integration_Handler.php' );
define( 'AF2_INTEGRATION_HANDLER_ZAPIER', AF2_PLUGIN_DIR.'/integrations/Zapier/Zapier_Integration_Handler.php' );
define( 'AF2_INTEGRATION_HANDLER_MAKE', AF2_PLUGIN_DIR.'/integrations/Make/Make_Integration_Handler.php' );
define( 'AF2_INTEGRATION_HANDLER_PIPEDRIVE', AF2_PLUGIN_DIR.'/integrations/PipeDrive/PipeDrive_Integration_Handler.php' );
define( 'AF2_INTEGRATION_HANDLER_GETRESPONSE', AF2_PLUGIN_DIR.'/integrations/GetResponse/GetResponse_Integration_Handler.php' );
define( 'AF2_INTEGRATION_HANDLER_MAILCHIMP', AF2_PLUGIN_DIR.'/integrations/MailChimp/MailChimp_Integration_Handler.php' );
define( 'AF2_INTEGRATION_REST_ZAPIER', AF2_PLUGIN_DIR.'/integrations/Zapier/Zapier_REST.php' );
define( 'AF2_INTEGRATION_REST_MAKE', AF2_PLUGIN_DIR.'/integrations/Make/Make_REST.php' );
define( 'AF2_INTEGRATION_DIR', AF2_PLUGIN_DIR.'/integrations' );

define( 'AF2_APP_REST', AF2_PLUGIN_DIR.'/app/app_REST.php' );

// Custom Templates
define( 'AF2_CUSTOM_TEMPLATE_FORMULARE', AF2_PLUGIN_DIR.'/admin/views/custom_templates/formulare.php' );
define( 'AF2_CUSTOM_TEMPLATE_CATEGORY', AF2_PLUGIN_DIR.'/admin/views/custom_templates/category.php' );

// Menu Paths
define( 'AF2_MENU_PARENTS_CLASS', AF2_PLUGIN_DIR.'/admin/menus/Af2MenuParents.php' );
define( 'AF2_MENU_DASHBOARD_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Dashboard.php' );
define( 'AF2_MENU_LEADS_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Leads.php' );
define( 'AF2_MENU_LEADS_DETAILS_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Leads_details.php' );
define( 'AF2_MENU_FRAGEN_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Fragen.php' );
define( 'AF2_MENU_FRAGENBUILDER_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Fragenbuilder.php' );
define( 'AF2_MENU_KONTAKTFORMULARE_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Kontaktformulare.php' );
define( 'AF2_MENU_KONTAKTFORMULARBUILDER_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Kontaktformularbuilder.php' );
define( 'AF2_MENU_KONTAKTFORMULARBUILDER_SETTINGS_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Kontaktformularbuilder_settings.php' );
define( 'AF2_MENU_FORMULARE_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Formulare.php' );
define( 'AF2_MENU_FORMULARBUILDER_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Formularbuilder.php' );
define( 'AF2_MENU_FORMULARBUILDER_SETTINGS_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Formularbuilder_settings.php' );
define( 'AF2_MENU_FORMULARBUILDER_PREVIEW_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Formularbuilder_preview.php' );
define( 'AF2_MENU_TERMINE_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Termine.php' );
define( 'AF2_MENU_TERMINEVENTS_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Terminevents.php' );
define( 'AF2_MENU_TERMINEVENT_BUILDER_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Termineventbuilder.php' );
define( 'AF2_MENU_IMPORT_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Import.php' );
define( 'AF2_MENU_DEMOIMPORT_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Demoimport.php' );
define( 'AF2_MENU_INTEGRATIONEN_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Integrationen.php' );
define( 'AF2_MENU_LIZENZ_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Lizenz.php' );
define( 'AF2_MENU_CHECKLIST_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Checklist.php' );
define( 'AF2_MENU_OPENAI_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/OpenAI.php' );
define( 'AF2_MENU_LEADACCELERATOR_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/LeadAccelerator.php' );
define( 'AF2_MENU_CALCULATIONS_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Calculations.php' );
define( 'AF2_MENU_CALCULATIONBUILDER_PATH', AF2_PLUGIN_DIR.'/admin/menus/physical_menus/Calculationbuilder.php' );


// Sidebar elements
define( 'AF2_MENU_FRAGENBUILDER_ELEMENTS_PATH', AF2_PLUGIN_DIR.'/admin/edit_sidebar_elements/Fragenbuilder_elements.php' );
define( 'AF2_MENU_KONTAKTFORMULARBUILDER_ELEMENTS_PATH', AF2_PLUGIN_DIR.'/admin/edit_sidebar_elements/Kontaktformularbuilder_elements.php' );
define( 'AF2_MENU_KONTAKTFORMULARBUILDER_SETTINGS_ELEMENTS_PATH', AF2_PLUGIN_DIR.'/admin/edit_sidebar_elements/Kontaktformularbuilder_settings_elements.php' );
define( 'AF2_MENU_FORMULARBUILDER_SETTINGS_ELEMENTS_PATH', AF2_PLUGIN_DIR.'/admin/edit_sidebar_elements/Formularbuilder_settings_elements.php' );
define( 'AF2_MENU_CALCULATIONBUILDER_ELEMENTS_PATH', AF2_PLUGIN_DIR.'/admin/edit_sidebar_elements/Calculationbuilder_elements.php' );


// Sources
define( 'AF2_BACKEND_STYLES_PATH', 'res/backend/styles' );
define( 'AF2_BACKEND_SCRIPTS_PATH', 'res/backend/scripts' );
define( 'AF2_FRONTEND_STYLES_PATH', 'res/frontend/styles' );
define( 'AF2_FRONTEND_SCRIPTS_PATH', 'res/frontend/scripts' );

// Views
define( 'AF2_MENU_WRAPPER_VIEW', AF2_PLUGIN_DIR.'/admin/views/menu/menu_wrapper.php' );
define( 'AF2_MENU_TYPE_CUSTOM_VIEW', AF2_PLUGIN_DIR.'/admin/views/menu/menu_types/custom.php' );
define( 'AF2_MENU_TYPE_TABLE_VIEW', AF2_PLUGIN_DIR.'/admin/views/menu/menu_types/table.php' );
define( 'AF2_MENU_TYPE_BUILDER_VIEW', AF2_PLUGIN_DIR.'/admin/views/menu/menu_types/builder.php' );
define( 'AF2_MENU_SIDEBAR', AF2_PLUGIN_DIR.'/admin/views/menu/snippets/sidebar.php' );
define( 'AF2_MENU_HEROIC_BUTTON', AF2_PLUGIN_DIR.'/admin/views/menu/snippets/heroic_button.php' );
define( 'AF2_MENU_HEADLINE_SNIPPET', AF2_PLUGIN_DIR.'/admin/views/menu/snippets/headline.php' );
define( 'AF2_MENU_ACTION_BUTTONS_SNIPPET', AF2_PLUGIN_DIR.'/admin/views/menu/snippets/action_buttons.php' );
define( 'AF2_MENU_HOOKS_SNIPPET', AF2_PLUGIN_DIR.'/admin/views/menu/snippets/hooks.php' );
define( 'AF2_CUSTOM_MENU_DASHBOARD', AF2_PLUGIN_DIR.'/admin/views/menu/custom_menus/dashboard.php' );
define( 'AF2_CUSTOM_MENU_INTEGRATIONEN', AF2_PLUGIN_DIR.'/admin/views/menu/custom_menus/integrationen.php' );
define( 'AF2_CUSTOM_MENU_IMPORT_EXPORT', AF2_PLUGIN_DIR.'/admin/views/menu/custom_menus/import_export.php' );
define( 'AF2_CUSTOM_MENU_DEMO_IMPORT', AF2_PLUGIN_DIR.'/admin/views/menu/custom_menus/demoimport.php' );
define( 'AF2_CUSTOM_MENU_OPENAI', AF2_PLUGIN_DIR.'/admin/views/menu/custom_menus/openai.php' );
define( 'AF2_CUSTOM_MENU_LIZENZ', AF2_PLUGIN_DIR.'/admin/views/menu/custom_menus/lizenz.php' );
define( 'AF2_CUSTOM_MENU_CHECKLIST', AF2_PLUGIN_DIR.'/admin/views/menu/custom_menus/checklist.php' );
define( 'AF2_CUSTOM_MENU_LEADACCELERATOR', AF2_PLUGIN_DIR.'/admin/views/menu/custom_menus/leadaccelerator.php' );
define( 'AF2_CUSTOM_MENU_LEADDETAILS', AF2_PLUGIN_DIR.'/admin/views/menu/custom_menus/leaddetails.php' );

define( 'AF2_ICON_PICKER_MODAL_PATH', AF2_PLUGIN_DIR.'/admin/views/modals/icon_picker.php' );

// Builder Templates
define( 'AF2_BUILDER_TEMPLATE_KONTAKTFORMULAR', AF2_PLUGIN_DIR.'/admin/views/builder_templates/kontaktformularbuilder/general.php' );
define( 'AF2_BUILDER_TEMPLATE_KONTAKTFORMULAR_SETTINGS', AF2_PLUGIN_DIR.'/admin/views/builder_templates/kontaktformularbuilder/settings.php' );

define( 'AF2_BUILDER_TEMPLATE_FORMULAR', AF2_PLUGIN_DIR.'/admin/views/builder_templates/formularbuilder/general.php' );
define( 'AF2_BUILDER_TEMPLATE_FORMULAR_SETTINGS', AF2_PLUGIN_DIR.'/admin/views/builder_templates/formularbuilder/settings.php' );
define( 'AF2_BUILDER_TEMPLATE_FORMULAR_PREVIEW', AF2_PLUGIN_DIR.'/admin/views/builder_templates/formularbuilder/preview.php' );

define( 'AF2_BUILDER_TEMPLATE_TERMINEVENT', AF2_PLUGIN_DIR.'/admin/views/builder_templates/termineventbuilder/general.php' );

// Calculations
define( 'AF2_CALCULATION_TYPE_GENERAL', AF2_PLUGIN_DIR.'/admin/views/builder_templates/calculatebuilder/general.php' );
define( 'AF2_MENU_TERMINEVENTBUILDER_ELEMENTS_PATH', AF2_PLUGIN_DIR.'/admin/edit_sidebar_elements/Termineventbuilder_elements.php' );

// Question Types
define( 'AF2_QUESTION_TYPE_GENERAL', AF2_PLUGIN_DIR.'/admin/views/builder_templates/fragenbuilder/general.php' );
define( 'AF2_QUESTION_TYPE_SELECT', AF2_PLUGIN_DIR.'/admin/views/builder_templates/fragenbuilder/select.php' );
define( 'AF2_QUESTION_TYPE_MULTISELECT', AF2_PLUGIN_DIR.'/admin/views/builder_templates/fragenbuilder/multiselect.php' );
define( 'AF2_QUESTION_TYPE_SLIDER', AF2_PLUGIN_DIR.'/admin/views/builder_templates/fragenbuilder/slider.php' );
define( 'AF2_QUESTION_TYPE_TEXTAREA', AF2_PLUGIN_DIR.'/admin/views/builder_templates/fragenbuilder/textarea.php' );
define( 'AF2_QUESTION_TYPE_TEXTROW', AF2_PLUGIN_DIR.'/admin/views/builder_templates/fragenbuilder/textrow.php' );
define( 'AF2_QUESTION_TYPE_HTML', AF2_PLUGIN_DIR.'/admin/views/builder_templates/fragenbuilder/html.php' );
define( 'AF2_QUESTION_TYPE_FILEUPLOAD', AF2_PLUGIN_DIR.'/admin/views/builder_templates/fragenbuilder/fileupload.php' );
define( 'AF2_QUESTION_TYPE_DROPDOWN', AF2_PLUGIN_DIR.'/admin/views/builder_templates/fragenbuilder/dropdown.php' );
define( 'AF2_QUESTION_TYPE_DATE', AF2_PLUGIN_DIR.'/admin/views/builder_templates/fragenbuilder/date.php' );
define( 'AF2_QUESTION_TYPE_ADDRESS', AF2_PLUGIN_DIR.'/admin/views/builder_templates/fragenbuilder/address.php' );
define( 'AF2_QUESTION_TYPE_APPOINTMENT', AF2_PLUGIN_DIR.'/admin/views/builder_templates/fragenbuilder/appointment.php' );

// Menus and Slugs
define( 'MAIN_MENU_SLUG', 'af2_dashboard' );
define( 'LEADS_SLUG', 'af2_leads' );
define( 'LEADS_DETAILS_SLUG', 'af2_lead_details' );
define( 'FRAGE_SLUG', 'af2_fragen' );
define( 'CALCULATIONS_SLUG', 'af2_calculations' );
define( 'FRAGENBUILDER_SLUG', 'af2_fragenbuilder' );
define( 'CALCULATIONBUILDER_SLUG', 'af2_calculationbuilder' );
define( 'KONTAKTFORMULAR_SLUG', 'af2_kontaktformulare' );
define( 'KONTAKTFORMULARBUILDER_SLUG', 'af2_kontaktformularbuilder' );
define( 'KONTAKTFORMULARBUILDER_SETTINGS_SLUG', 'af2_kontaktformularbuilder_settings' );
define( 'FORMULAR_SLUG', 'af2_formulare' );
define( 'FORMULARBUILDER_SLUG', 'af2_formularbuilder' );
define( 'FORMULARBUILDER_SETTINGS_SLUG', 'af2_formularbuilder_settings' );
define( 'FORMULARBUILDER_PREVIEW_SLUG', 'af2_formularbuilder_preview' );
define( 'TERMIN_SLUG', 'af2_termine' );
define( 'TERMINEVENT_SLUG', 'af2_terminevent' );
define( 'TERMINEVENTBUILDER_SLUG', 'af2_termineventbuilder' );
define( 'IMPORT_SLUG', 'af2_import_export' );
define( 'DEMOIMPORT_SLUG', 'af2_demo_import' );
define( 'INTEGRATIONEN_SLUG', 'af2_integrationen' );
define( 'OPENAI_SLUG', 'af2_openai' );
define( 'LIZENZ_SLUG', 'af2_lizenzen' );
define( 'CHECKLIST_SLUG', 'af2_checklist' );
define( 'LEADACCELERATOR_SLUG', 'af2_leadaccelerator' );
define( 'PARTNERPROGRAMM_SLUG', 'af2_partnerprogramm');
define( 'HELPCENTER_SLUG', 'af2_helpcenter');
define( 'SUPPORT_SLUG', 'af2_support');

// Post Types
define( 'FRAGE_POST_TYPE', 'af2_frage' );
define( 'KONTAKTFORMULAR_POST_TYPE', 'af2_kontaktformular' );
define( 'FORMULAR_POST_TYPE', 'af2_formular' );

define( 'CALCULATION_POST_TYPE', 'af2_calculations' );

define( 'AI_FRAGE_POST_TYPE', 'af2_ai_frage' );
define( 'AI_KONTAKTFORMULAR_POST_TYPE', 'af2_ai_kontf' );
define( 'AI_FORMULAR_POST_TYPE', 'af2_ai_formular' );

define( 'TERMIN_POST_TYPE', 'af2_terminbuchung' );
define( 'TERMINEVENT_POST_TYPE', 'af2_terminevent' );
define( 'REQUEST_POST_TYPE', 'af2_request' );
define( 'REQUEST_POST_TYPE_', 'af2_request' );

define( 'FRAGE_BACKUP_POST_TYPE', 'af2_frage_backup' );
define( 'KONTAKTFORMULAR_BACKUP_POST_TYPE', 'af2_cf_backup' );
define( 'FORMULAR_BACKUP_POST_TYPE', 'af2_form_backup' );
define( 'TERMIN_BACKUP_POST_TYPE', 'af2_tb_backup' );
define( 'TERMINEVENT_BACKUP_POST_TYPE', 'af2_term_backup' );
define( 'REQUEST_BACKUP_POST_TYPE', 'af2_rq_backup' );

// Other constants
define( 'AF2_FINAL_VERSION', '3.8.1' );
define( 'AF2_MENU_ICON_URL', plugins_url("/res/images/menu_icon.png", AF2_PLUGIN) );
define( 'AF2_HEALTHCHECK_JSON', AF2_PLUGIN_DIR."/res/backend/healthcheck.json");

define( 'AI_DE_FORM', AF2_PLUGIN_DIR.'/res/openai/form_DE.php');
define( 'AI_EN_FORM', AF2_PLUGIN_DIR.'/res/openai/form_EN.php');
