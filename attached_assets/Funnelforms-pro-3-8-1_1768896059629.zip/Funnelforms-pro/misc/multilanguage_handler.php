<?php

function af2_plugin_init_language() {
    load_plugin_textdomain( 'af2_multilanguage', false, AF2_LANGUAGES_PATH );
}
add_action('init', 'af2_plugin_init_language'); 