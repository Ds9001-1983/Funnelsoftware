<?php

require_once AF2_INTEGRATION_HANDLER_CLASS;
class HelloHQ_Integration extends Af2Integration {

    public function get_credential_fields() {
        return array(
            array( 'key' => 'token', 'option_value' => 'af2_hellohq_token', 'icon' => 'fas fa-user-alt', 'label' => 'Token:', 'type' => 'text' ),
            array( 'key' => 'refreshtoken', 'option_value' => 'af2_hellohq_refreshtoken', 'icon' => 'fas fa-user-alt', 'label' => 'Refresh Token:', 'type' => 'text' ),
        );
    }

    public function is_active() {
        $credentials = $this->get_credentials();

        if(!isset($credentials) || empty($credentials)) return false;
        if(!isset($credentials['token']) || empty($credentials['token'])) return false;
        if(!isset($credentials['refreshtoken']) || empty($credentials['refreshtoken'])) return false;

        return true;
    }


    public function fetch_fields_from_api() {
        $options = $this->get_status_options();
        $customFields = $this->get_custom_fields();

        return array(
            'statuslist' => $options,
            'leaddescription' => $customFields,
        );
    }

    private function get_custom_fields()
    {
        $data = [];
        $response = $this->send_request('/v1/CustomFieldDefinitions', 'GET', $data);
        $responseData = $response["value"];
        $options = [];

        foreach($responseData as $data) {
            $obj = ["value" =>$data['Id'].",".$data['Name'], "label" => $data['Name']];
            $options[] = $obj;
        }

        return $options;
    }
    private function get_status_options()
    {
        $data = [];
        $response = $this->send_request('/v1/LeadStatuses', 'GET', $data);
        $responseData = $response["value"];
        $options = [];

        foreach($responseData as $data) {
            $obj = ["value" =>$data['Id'], "label" => $data['Name']];
            $options[] = $obj;
        }

        return $options;
    }

    public function get_api_values() {
        return array(
            array( 'label' => 'company', 'type' => 'contactform'),
            array( 'label' => 'firstname', 'type' => 'contactform'),
            array( 'label' => 'lastname', 'type' => 'contactform'),
            array( 'label' => 'phone', 'type' => 'contactform'),
            array( 'label' => 'mail', 'type' => 'contactform'),
            array( 'label' => 'statuslist', 'type' => 'field'),
            array( 'label' => 'leaddescription', 'type' => 'field'),
        );
    }

    public function get_api_draw_fields() {
        return array(
            array(
                'label' => __('Contact information:', 'af2_multilanguage'),
                'fields' => array(
                    array( 'label' => __('Company', 'af2_multilanguage'), 'required' => true, 'type' => 'select', 'value' => 'company' ),
                    array( 'label' => __('First name', 'af2_multilanguage'), 'required' => true, 'type' => 'select', 'value' => 'firstname' ),
                    array( 'label' => __('Last name', 'af2_multilanguage'), 'required' => true, 'type' => 'select', 'value' => 'lastname' ),
                    array( 'label' => __('Phone', 'af2_multilanguage'), 'required' => false, 'type' => 'select', 'value' => 'phone' ),
                    array( 'label' => __('E-mail', 'af2_multilanguage'), 'required' => true, 'type' => 'select', 'value' => 'mail' ),
                    array( 'label' => __('Status', 'af2_multilanguage'), 'required' => true, 'type' => 'select_', 'type_label' => 'statuslist', 'value' => 'statuslist' ),
                    array( 'label' => __('Lead description', 'af2_multilanguage'), 'required' => true, 'type' => 'select_', 'type_label' => 'leaddescription', 'value' => 'leaddescription' ),
                ),
            ),
        );
    }

    public function send_to_api() {

        // Create Company
        $data = [
            "Name" => $this->api_values['company'],
        ];
        $response = $this->send_request('/v1/Companies', 'POST', $data);
        $companyId = $response["Id"];

        // Create Contact Person
        $data = [
            "FirstName" => $this->api_values['firstname'],
            "LastName" => $this->api_values['lastname'],
            "PhoneLandline" => $this->api_values['phone'],
            "DefaultAddress" => [
                "Email" => $this->api_values['mail'],
                "Country" => 'DE'
            ],
            "CompanyId" => $companyId,
        ];
        $response = $this->send_request('/v1/ContactPersons', 'POST', $data);
        $customerId = $response["Id"];

        // Create Lead

        $data = [
            "Name" => "Lead: ".get_home_url(),
            "StatusId" => $this->api_values['statuslist'],
            "CompanyId" => $companyId,
            "ContactPersons" => [
                ["Id" => $customerId]
            ]
        ];

        $response = $this->send_request('/v1/Leads', 'POST', $data);
        var_dump($response);

        $customField = explode(",", $this->api_values['leaddescription']);
        $customFieldId = $customField[0];
        $customFieldName = $customField[1];

        $url = '/v1/Leads('.$response['Id'].')/CustomFields('.$customFieldId.')';

        $data = [
            "Name" => $customFieldName,
            "Value" => $this->api_values['answer_string']
        ];

        $response = $this->send_request($url, 'PUT', $data);
    }

    private function send_request($uri='/', $method = 'GET', $data = '')
    {
        $baseUri = 'https://api.hellohq.io';

        $credentials = $this->get_credentials();

        $method = strtoupper($method);
        $data = is_array($data) ? json_encode($data) : $data;

        $requestUri = '';

        if( $uri ) {
            $requestUri = $baseUri . $uri ;
        }
        else {
            throw new Exception('Not a valid request url');
        }

        if( empty($requestUri) ) {
            throw new Exception('Not a valid request url');
        }

        $headers = [
            'Accept: application/json',
            'Content-Type: application/json',
            'Authorization: Bearer ' . $credentials['token'],
        ];

        $curl = curl_init();

        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_URL, $requestUri);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, false); // optional
        curl_setopt($curl, CURLOPT_MAXREDIRS, 1);  // optional
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        if($method == 'POST'){
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        }
        else if ($method == 'PUT'){
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT');
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        }
        else if($method != 'GET'){
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        }
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); // optional if debug
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2); // optional if debug
        // curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($curl, CURLOPT_TIMEOUT, 30);
        $result = new StdClass();

        $result->response = curl_exec($curl);
        $result->code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $result->meta = curl_getinfo($curl);

        $curl_error = ($result->code > 0 ? null : curl_error($curl) . ' (' . curl_errno($curl) . ')');
        curl_close($curl);

        if ($curl_error) {
            throw new Exception('An error occurred while connecting to endpoint: ' . $curl_error);
        }
        return json_decode($result->response, true);
    }
}
