<?php

require_once AF2_INTEGRATION_HANDLER_CLASS;
class Zapier_Integration extends Af2Integration {

    public function get_credential_fields() {
        update_option('af2_zapier_url', home_url( '/wp-json/af2/v1', 'https' ));
        $urlparts = parse_url(home_url());
        $domain = $urlparts['host'];
        update_option('af2_domain', $domain);
        
        return array( 
            array( 'key' => 'license_key', 'option_value' => 'af2_license_key', 'icon' => 'fas fa-link', 'label' => 'License key:', 'type' => 'text', 'disabled' => true ),
            array( 'key' => 'domain', 'option_value' => 'af2_domain', 'icon' => 'fas fa-link', 'label' => 'Domain:', 'type' => 'text', 'disabled' => true ),
            array( 'key' => 'zapier_url', 'option_value' => 'af2_zapier_url', 'icon' => 'fas fa-link', 'label' => 'API URL:', 'type' => 'text', 'disabled' => true ),
            array( 'key' => 'zapier_pw', 'option_value' => 'af2_zapier_pw', 'icon' => 'fas fa-key', 'label' => 'API Password:', 'type' => 'password' ),
        );
    }
}
