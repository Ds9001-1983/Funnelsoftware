<?php

require_once AF2_INTEGRATION_HANDLER_CLASS;

class MailChimp_Integration extends Af2Integration {

    public function get_credential_fields() {
        return array(
            array( 'key' => 'api_url', 'option_value' => 'af2_mc_url', 'icon' => 'fas fa-link', 'label' => 'API URL:', 'type' => 'text' ),
            array( 'key' => 'api_key', 'option_value' => 'af2_mc_key', 'icon' => 'fas fa-key', 'label' => 'API Key:', 'type' => 'password' ),
        );
    }

    public function is_active() {
        $credentials = $this->get_credentials();

        if(!isset($credentials) || empty($credentials)) return false;
        if(!isset($credentials['api_url']) || empty($credentials['api_url'])) return false;
        if(!isset($credentials['api_key']) || empty($credentials['api_key'])) return false;

        return true;
    }

    public function get_api_values() {
        return array(
            array( 'label' => 'vorname', 'type' => 'contactform'),
            array( 'label' => 'name', 'type' => 'contactform'),
            array( 'label' => 'telefon', 'type' => 'contactform'),
            array( 'label' => 'mail', 'type' => 'contactform'),
            array( 'label' => 'liste', 'type' => 'field'),
        );
    }

    public function get_api_draw_fields() {
        return array(
            array(
                'label' => __('Contact information:', 'af2_multilanguage'),
                'fields' => array(
                    array( 'label' => __('First name', 'af2_multilanguage'), 'required' => false, 'type' => 'select', 'value' => 'vorname' ),
                    array( 'label' => __('Last name', 'af2_multilanguage'), 'required' => false, 'type' => 'select', 'value' => 'name' ),
                    array( 'label' => __('E-mail', 'af2_multilanguage'), 'required' => false, 'type' => 'select', 'value' => 'mail' ),
                ),
            ),
            array(
                'label' => __('List data:', 'af2_multilanguage'),
                'fields' => array(
                    array( 'label' => __('List', 'af2_multilanguage'), 'required' => true, 'type' => 'select_', 'type_label' => 'list', 'value' => 'liste' ),
                ),
            ),
        );
    }

    public function send_to_api() {
        $credentials = $this->get_credentials();

        $dat = array(
            'name' => $this->api_values['name'],
            'phone' => $this->api_values['telefon'],
            'email' => $this->api_values['mail'],
        );

        $resp = $this->add_contact($dat);
        $resp = json_decode($resp->response);
        $contact_id = $resp->data->id;
    }

    public function fetch_fields_from_api() {
        $list = $this->get_list_fields();

        return array(
            'list' => [['value'=>rand(), 'label'=>serialize($list)]],
        );
    }

    private function get_list_fields()
    {
        $requestUri = '/lists';
        try {
            $response = $this->send_request( $requestUri , 'get' );
            if( $response->code === 200 || $response->code === '200' )
            {
                return json_decode( $response->response, true )['lists'];
            }
            else
            {
                throw new Exception("Error getting list", 1);
            }
        } catch (\Throwable $th) {
            return $th;
        }
    }

    private function add_contact($contact, $list_id)
    {
        $email = is_array($contact) ? $contact['email_address'] : json_decode($contact,true)['email_address'];
        $email_hash = md5($email);
        $requestUri = '/lists/'.$list_id.'/members/'.$email_hash;
        try {
            $response = $this->send_request( $requestUri , 'put', $contact );
            if( $response->code === 200 || $response->code === '200' )
            {
                return 'added';
            }
            else
            {
                return json_decode( $response->response, true )['detail'];
            }
        } catch (\Throwable $th) {
            return $th;
        }
    }

    private function get_auth_header_string()
    {
        $credentials = $this->get_credentials();
        $credential_string = base64_encode( 'user:' . $credentials['api_key'] );
        return 'Authorization: '.$this->auth_type.' '. $credential_string;
    }

    private function send_request($uri='/', $method = 'GET', $data = '')
    {
        $header = array(
            'Content-Type: application/json',
            'Accept: application/json'
        );

        $credentials = $this->get_credentials();

        if(!empty($credentials)) array_push( $header, $this->get_auth_header_string());

        $method = strtoupper($method);
        $data = is_array($data) ? json_encode($data) : $data;

        $requestUri = '';
        if( $uri )
        {
            $baseUri = $credentials['api_url'];
            $requestUri = $baseUri . $uri;
        }
        else
        {
            throw new Exception('Not a valid request url');
        }

        if( empty($requestUri) ) throw new Exception('Not a valid request url');

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $requestUri);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, false);
        curl_setopt($curl, CURLOPT_MAXREDIRS, 1);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $header);

        if($method == 'POST'){
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        }
        else if ($method == 'PUT'){
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT');
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        }
        else if($method != 'GET'){
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        }
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
        // curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($curl, CURLOPT_TIMEOUT, 30);
        $result = new StdClass();

        $result->response = curl_exec($curl);
        $result->code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $result->meta = curl_getinfo($curl);

        $curl_error = ($result->code > 0 ? null : curl_error($curl) . ' (' . curl_errno($curl) . ')');
        curl_close($curl);

        if ($curl_error) {
            throw new Exception('An error occurred while connecting to endpoint: ' . $curl_error);
        }
        return $result;
    }
}
