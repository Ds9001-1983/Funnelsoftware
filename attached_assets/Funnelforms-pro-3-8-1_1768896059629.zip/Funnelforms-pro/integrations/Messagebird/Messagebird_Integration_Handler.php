<?php

require_once AF2_INTEGRATION_HANDLER_CLASS;
class Messagebird_Integration extends Af2Integration {

    public function get_credential_fields() {
        return array( 
            array( 'key' => 'api_key', 'option_value' => 'af2_messagebird_key', 'icon' => 'fas fa-key', 'label' => 'API Key:', 'type' => 'password' ),
        );
    }

    public function is_active() { 
        $credentials = $this->get_credentials();

        if(!isset($credentials) || empty($credentials)) return false;
        if(!isset($credentials['api_key']) || empty($credentials['api_key'])) return false;

        return true;
    }
}