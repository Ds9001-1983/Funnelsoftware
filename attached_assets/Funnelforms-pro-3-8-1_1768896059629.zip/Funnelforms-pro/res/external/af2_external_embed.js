let externalEmbedScript = document.querySelector('script[src*="/af2_external_embed.js"]');

if (externalEmbedScript && typeof externalEmbedScript !== 'undefined') {
    const dataUrl = externalEmbedScript.getAttribute('data-url') + 'wp-admin/admin-ajax.php';
    const jqueryNeeded = externalEmbedScript.getAttribute('data-jquery-needed') === 'false' ? 'false' : 'true';

    const requestBody = new URLSearchParams();
    requestBody.append('action', 'af2_load_external_embed');
    requestBody.append('jquery_needed', jqueryNeeded);

    fetch(dataUrl, {
        method: 'POST',
        headers: {},
        body: requestBody,
    })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            data.styles.forEach(style => {
                const link = document.createElement('link');
                link.rel = 'stylesheet';
                link.href = style;
                document.head.appendChild(link);
            });

            const jqueryScript = data.scripts.find(script => script.includes('jquery.js'));
            if (jqueryScript) {
                const jqueryElement = document.createElement('script');
                jqueryElement.src = jqueryScript;
                jqueryElement.onload = () => {
                    data.scripts.forEach(script => {
                        if (!script.includes('jquery.js')) {
                            const scriptElement = document.createElement('script');
                            scriptElement.src = script;
                            document.body.appendChild(scriptElement);
                        }
                    });
                };
                document.body.appendChild(jqueryElement);
            } else {
                data.scripts.forEach(script => {
                    const scriptElement = document.createElement('script');
                    scriptElement.src = script;
                    document.body.appendChild(scriptElement);
                });
            }

            document.body.appendChild(document.createElement('script')).text = `var af2_frontend_ajax = ${JSON.stringify(data.af2_frontend_ajax)};`;

            const external_forms = document.querySelectorAll('.af2_external_form');
            const formPromises = [];

            external_forms.forEach((form, index) => {
                if(!form.getAttribute('data-form-id')) {
                    console.error('Form ID is missing!');
                    return;
                }
                
                const formRequestBody = new URLSearchParams();
                formRequestBody.append('action', 'af2_external_load_form_shortcode');
                formRequestBody.append('form_id', form.getAttribute('data-form-id'));
                formRequestBody.append('index', index);

                const formRequest = fetch(dataUrl, {
                    method: 'POST',
                    headers: {},
                    body: formRequestBody,
                })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(`HTTP error for form ${index}! Status: ${response.status}`);
                        }
                        return response.json();
                    })
                    .then(formData => {
                        if(formData.content) form.innerHTML = formData.content;
                    })
                    .catch(error => {
                        console.error(`Error during form ${index} request:`, error);
                    });

                formPromises.push(formRequest);
            });

            Promise.all(formPromises).then(() => {
                const allFormsLoadedEvent = new CustomEvent('af2_all_forms_loaded');
                document.body.dispatchEvent(allFormsLoadedEvent);

                document.body.appendChild(document.createElement('div')).className = 'af2_all_forms_loaded';
                const allFormsLoadedElement = document.querySelector('.af2_all_forms_loaded');
                allFormsLoadedElement.style.display = 'none';
            });
        })
        .catch(error => {
            console.error('Error during POST request:', error);
        });
}

    