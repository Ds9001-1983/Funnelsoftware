let t = document.querySelector('script[src*="/af2_iframe_data_alternate.js"]');
if (t && 'undefined' !== typeof t) {
    const e = t.getAttribute("data-url") + "wp-admin/admin-ajax.php",
        n = t.getAttribute("data-content-id"),
        k = t.getAttribute("data-maps-key"),
        a = new FormData;
    a.append("externtest", window.location.hostname), a.append("contentID", n), a.append("action", "iframeContent"), fetch(e, {
        method: "POST",
        body: a
    }).then(t => t.json()).then(n => {
        let front_styles = front_scripts = '';
        $.each(n.style, function( i, src ) {
            front_styles +='<link rel="stylesheet" href="' + src + '" />'
        });
        $.each(n.script, function( i, src ) {
            front_scripts +='<script src="' + src + '"><\/script>'
        });
        let strings = '';
        strings += 'strings:{';

        strings += 'antworten_tag:"'+n.strings.antworten_tag+'"';
        strings += ',error_01:"'+n.strings.error_01+'"';
        strings += ',fehler_admin:"'+n.strings.fehler_admin+'"';
        strings += ',fehler_find:"'+n.strings.fehler_find+'"';
        strings += ',help:"'+n.strings.help+'"';
        strings += ',help_url:"'+n.strings.help_url+'"';
        strings += ',erroroccured:"'+n.strings.erroroccured+'"';
        strings += ',sms:"'+n.strings.sms+'"';
        strings += ',sms_sent:"'+n.strings.sms_sent+'"';
        strings += ',sms_change:"'+n.strings.sms_change+'"';
        strings += ',sms_repeat:"'+n.strings.sms_repeat+'"';
        strings += ',sms_verify:"'+n.strings.sms_verify+'"';
        strings += ',country_search_placeholder:"'+n.strings.country_search_placeholder+'"';
        strings += ',dot:"'+n.strings.dot+'"';
        strings += ',form_sent:"'+n.strings.form_sent+'"';
        strings += ',street:"'+n.strings.street+'"';
        strings += ',address:"'+n.strings.address+'"';
        strings += ',no:"'+n.strings.no+'"';
        strings += ',postcode:"'+n.strings.postcode+'"';
        strings += ',city:"'+n.strings.city+'"';
        strings += ',resend:"'+n.strings.resend+'"';
        strings += ',choosedur:"'+n.strings.choosedur+'"';
        strings += ',choosedurdot:"'+n.strings.choosedurdot+'"';
        strings += ',choosetime:"'+n.strings.choosetime+'"';
        strings += ',choosetimedot:"'+n.strings.choosetimedot+'"';
        strings += ',noappointments:"'+n.strings.noappointments+'"';
        strings += ',mr:"'+n.strings.mr+'"';
        strings += ',mrs:"'+n.strings.mrs+'"';
        strings += ',diverse:"'+n.strings.diverse+'"';
        strings += ',company:"'+n.strings.company+'"';


        strings += ',date:{';

        strings += 'sonntag:"'+n.strings.date.sonntag+'"';
        strings += ',montag:"'+n.strings.date.montag+'"';
        strings += ',dienstag:"'+n.strings.date.dienstag+'"';
        strings += ',mittwoch:"'+n.strings.date.mittwoch+'"';
        strings += ',donnerstag:"'+n.strings.date.donnerstag+'"';
        strings += ',freitag:"'+n.strings.date.freitag+'"';
        strings += ',samstag:"'+n.strings.date.samstag+'"';
        strings += ',so:"'+n.strings.date.so+'"';
        strings += ',mo:"'+n.strings.date.mo+'"';
        strings += ',di:"'+n.strings.date.di+'"';
        strings += ',mi:"'+n.strings.date.mi+'"';
        strings += ',do:"'+n.strings.date.do+'"';
        strings += ',fr:"'+n.strings.date.fr+'"';
        strings += ',sa:"'+n.strings.date.sa+'"';
        strings += ',januar:"'+n.strings.date.januar+'"';
        strings += ',februar:"'+n.strings.date.februar+'"';
        strings += ',marz:"'+n.strings.date.marz+'"';
        strings += ',april:"'+n.strings.date.april+'"';
        strings += ',mai:"'+n.strings.date.mai+'"';
        strings += ',juni:"'+n.strings.date.juni+'"';
        strings += ',juli:"'+n.strings.date.juli+'"';
        strings += ',august:"'+n.strings.date.august+'"';
        strings += ',september:"'+n.strings.date.september+'"';
        strings += ',oktober:"'+n.strings.date.oktober+'"';
        strings += ',november:"'+n.strings.date.november+'"';
        strings += ',dezember:"'+n.strings.date.dezember+'"';
        strings += ',jan:"'+n.strings.date.jan+'"';
        strings += ',feb:"'+n.strings.date.feb+'"';
        strings += ',mar:"'+n.strings.date.mar+'"';
        strings += ',apr:"'+n.strings.date.apr+'"';
        strings += ',mai:"'+n.strings.date.mai+'"';
        strings += ',jun:"'+n.strings.date.jun+'"';
        strings += ',jul:"'+n.strings.date.jul+'"';
        strings += ',aug:"'+n.strings.date.aug+'"';
        strings += ',sep:"'+n.strings.date.sep+'"';
        strings += ',okt:"'+n.strings.date.okt+'"';
        strings += ',nov:"'+n.strings.date.nov+'"';
        strings += ',dez:"'+n.strings.date.dez+'"';


        strings += '}';

        
        strings += ',dropzone:{';

        strings += 'remove:"'+n.strings.dropzone.remove+'"';
        strings += ',max_uploads:"'+n.strings.dropzone.max_uploads+'"';
        strings += ',max_uploads_size:"'+n.strings.dropzone.max_uploads_size+'"';
        strings += ',wrong_filetype:"'+n.strings.dropzone.wrong_filetype+'"';


        strings += '}';
        strings += '}';
        jQuery('<div id="af2_dynamic_content" style="width: 100%;"></div>').insertAfter(t), jQuery("#af2_dynamic_content").html('<div class="af2_frontend_ajax" data-url="'+e+'" data-k="'+n.nonce+'" data-supported="'+k+'"></div><script>var af2_frontend_ajax={ajax_url:"' + e + '",nonce:"' + n.nonce + '",supported_server_size:"' + k + '",supported_file_types:"'+n.supported_file_types+'",server_max_size:"'+n.server_max_size+'",'+strings+'}<\/script>'+front_styles + front_scripts + n.content);
    })
}
