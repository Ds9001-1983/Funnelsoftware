$( document ).ready(function($) {
    let activeIncompleteLeads = true;

    const changeActiveIncompleteLeads = () => {

            $('.af2_post_table_body .af2_post_table_row').each((i, el) => {
                let id = $(el).attr('id');
                if(id != undefined) {
                    let post_status = $('.af2_post_table_body .af2_post_table_row#' + id +' .af2_post_table_content[data-searchfilter="post_status"]').data('searchvalue');
                    if(post_status == 'draft') $('.af2_post_table_body .af2_post_table_row#' + id).addClass('af2_table_highlight');
                }
            });
        
    }

    function updateURLParameter(url, param, paramVal){
        var newAdditionalURL = "";
        var tempArray = url.split("?");
        var baseURL = tempArray[0];
        var additionalURL = tempArray[1];
        var temp = "";
        if (additionalURL) {
            tempArray = additionalURL.split("&");
            for (var i=0; i<tempArray.length; i++){
                if(tempArray[i].split('=')[0] != param){
                    newAdditionalURL += temp + tempArray[i];
                    temp = "&";
                }
            }
        }

        var rows_txt = temp + "" + param + "=" + paramVal;
        return baseURL + "?" + newAdditionalURL + rows_txt;
    }

    // $(document).on('click', '#af2_show_uncomplete', changeActiveIncompleteLeads );
    $(document).on('click', '#af2_show_uncomplete', function() {
        const currentUrl = window.location.href;
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const draft = urlParams.get('draft');

        if(draft == 'true') {
            let newUrl = updateURLParameter(currentUrl, 'draft', false);
            newUrl = updateURLParameter(newUrl, 'page_offset', 0);
            window.location.href = newUrl;
        } else {
            let newUrl = updateURLParameter(currentUrl, 'draft', true);
            newUrl = updateURLParameter(newUrl, 'page_offset', 0);
            window.location.href = newUrl;
        }
    } );

    $('.af2_choose_table_object').on('click', function() {
        let ids = [];
        $('.af2_choose_table_object:checked').each((i, el) => {
            ids.push($(el).attr('id'));
        });
        if(ids.length) {
            $('input[name=form_ids]').attr('value', ids.join(','));
        } else {
            $('input[name=form_ids]').attr('value', 'all');
        }
    });

    changeActiveIncompleteLeads();
});
