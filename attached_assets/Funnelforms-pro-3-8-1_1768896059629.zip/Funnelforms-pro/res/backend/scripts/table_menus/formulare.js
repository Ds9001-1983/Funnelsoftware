$( document ).ready(function($) {
    
    $(document).on('click', '.open_external_embed_code', function() {
        const objectid = $(this).attr('data-objectid');

        let string1 = '';
        string1 += "<script type='text/javascript' src='" + af2_formulare_object.strings.plugin_dir_url + "res/external/af2_external_embed.js'";
        string1 += " data-url='" + af2_formulare_object.strings.site_url + "'";
        string1 += " data-jquery-needed='true' defer>";
        string1 += "</script>";



        let string2 = '';
        string2 += "<div class='af2_external_form' data-form-id='"+objectid+"'></div>";

        $('#af2_external_modal .af2_modal_content #af2_external_script_1').html(string1);
        $('#af2_external_modal .af2_modal_content #af2_external_script_2').html(string2);

        af2_open_modal('#af2_external_modal');
    });

    $(document).on('click', '.open_popup_embed_code', function() {
        af2_open_modal('#af2_popup_modal');

        $('#af2_popup_modal_ .af2_modal_content #af2_popup_radio_chooser').attr('id', 'af2_popup_radio_chooser_');

        $('#af2_popup_modal_ .af2_modal_content #af2_popup_delay').attr('id', 'af2_popup_delay_');
        $('#af2_popup_modal_ .af2_modal_content label[for="af2_popup_delay"]').attr('for', 'af2_popup_delay_');
        $('#af2_popup_modal_ .af2_modal_content #af2_popup_click').attr('id', 'af2_popup_click_');
        $('#af2_popup_modal_ .af2_modal_content label[for="af2_popup_click"]').attr('for', 'af2_popup_click_');

        $('#af2_popup_modal_ .af2_modal_content #af2_popup_delay_').attr('value', 'af2_popup_choose_div_delay_');
        $('#af2_popup_modal_ .af2_modal_content #af2_popup_delay_').attr('data-hide', 'af2_popup_choose_div_click_');
        $('#af2_popup_modal_ .af2_modal_content #af2_popup_click_').attr('value', 'af2_popup_choose_div_click_');
        $('#af2_popup_modal_ .af2_modal_content #af2_popup_click_').attr('data-hide', 'af2_popup_choose_div_delay_');



        $('#af2_popup_modal_ .af2_popup_choose_div_delay').addClass('af2_popup_choose_div_delay_');
        $('#af2_popup_modal_ .af2_popup_choose_div_delay').removeClass('af2_popup_choose_div_delay');
        $('#af2_popup_modal_ .af2_popup_choose_div_click').addClass('af2_popup_choose_div_click_');
        $('#af2_popup_modal_ .af2_popup_choose_div_click').removeClass('af2_popup_choose_div_click');
        

        const objectid = $(this).attr('data-objectid');
        $('#af2_popup_modal_ #af2_popup_delay_value').attr('data-objectid', objectid);
        $('#af2_popup_modal_ #af2_popup_click_value').attr('data-objectid', objectid);

        $('#af2_popup_modal_ .af2_modal_content #af2_popup_script').html('');
    });
    
    $(document).on('click', '.open_funnel_link', function() {
        af2_open_modal('#af2_funnel_link_modal');
        const objectid = $(this).attr('data-objectid');
        const isPublic = $(this).attr('data-is-public');
        const publicSlug = $(this).attr('data-public-slug');
        const publishButton = $('#af2_funnel_link_modal_ #af2-save-public-slug');
        const makePrivateButton = $('#af2_funnel_link_modal_ #af2-remove-public-slug');
        
        $('#af2_funnel_link_modal_ #af2_public_slug').val(publicSlug);
        $('#af2_funnel_link_modal_ #af2-public-slug-full-url').val(`${af2_formulare_object.strings.site_url}funnelforms/${publicSlug}`);
        
        
        if(isPublic) {
            $('#af2_funnel_link_modal_ #af2_public_slug_message_public').show();
            $('#af2_funnel_link_modal_ #af2_public_slug_message_private').hide();
        } else {
            $('#af2_funnel_link_modal_ #af2_public_slug_message_private').show();
            $('#af2_funnel_link_modal_ #af2_public_slug_message_public').hide();
        }
        
        
        $('#af2_funnel_link_modal_ #af2-save-public-slug').on('click', function() {
            publishButton.addClass('af2_button--loading');
            $('#af2_funnel_link_modal_ #af2_public_slug_error').hide();
            let public_slug = $('#af2_funnel_link_modal_ #af2_public_slug').val();
            
            $.ajax({
                url: af2_formulare_object.ajax_url,
                type: 'POST',
                data: {
                    action: 'af2_save_funnel_link_slug',
                    form_id: objectid,
                    public_slug: public_slug,
                    _ajax_nonce: af2_formulare_object.nonce
                },
                success: function(response) {
                    if (response.success) {
                        $('#af2_funnel_link_modal_ #af2_public_slug').val(response.data);
                        $('#af2_funnel_link_modal_ #af2-public-slug-full-url').val(`${af2_formulare_object.strings.site_url}funnelforms/${response.data}`);
                        $('#af2_funnel_link_modal_ #af2_public_slug_message_public').show();
                        $('#af2_funnel_link_modal_ #af2_public_slug_message_private').hide();
                    } else {
                        $('#af2_funnel_link_modal_ #af2_public_slug_error').text(af2_formulare_object.strings.public_slug.could_not_save)
                        $('#af2_funnel_link_modal_ #af2_public_slug_error').show();
                    }
                    publishButton.removeClass('af2_button--loading');
                }
            });
        });

        $('#af2_funnel_link_modal_ #af2-remove-public-slug').on('click', function() {
            $('#af2_funnel_link_modal_ #af2_public_slug_error').hide();
            makePrivateButton.addClass('af2_button--loading');
            $.ajax({
                url: af2_formulare_object.ajax_url,
                type: 'POST',
                data: {
                    action: 'af2_save_funnel_link_slug',
                    form_id: objectid,
                    public_slug: "",
                    _ajax_nonce: af2_formulare_object.nonce
                },
                success: function(response) {
                    if (response.success) {
                        $('#af2_funnel_link_modal_ #af2_public_slug').val("");
                        $('#af2_funnel_link_modal_ #af2_public_slug_message_public').hide();
                        $('#af2_funnel_link_modal_ #af2_public_slug_message_private').show();
                    } else {
                        $('#af2_funnel_link_modal_ #af2_public_slug_error').text(af2_formulare_object.strings.public_slug.could_not_make_private);
                        $('#af2_funnel_link_modal_ #af2_public_slug_error').show();
                    }
                    makePrivateButton.removeClass('af2_button--loading');
                }
            });
        });
    });

    $(document).on('change', '#af2_popup_radio_chooser_ input:radio', function() {
        const val = $(this).val();
        const otherVal = $(this).attr('data-hide');

        $('.'+val).removeClass('af2_hide');
        $('.'+otherVal).addClass('af2_hide');

        $('#af2_popup_modal_ #af2_popup_delay_value').val('');
        $('#af2_popup_modal_ #af2_popup_click_value').val('');

        $('#af2_popup_modal_ .af2_modal_content #af2_popup_script').html('');
    });

    $(document).on('input', '#af2_popup_delay_value', function() {
        const val = $(this).val();
        const objectid = $(this).attr('data-objectid');
        let shortcode = '[funnelforms id="'+objectid+'" popup_by_delay="true" popup_delay="'+val+'"]';
        $('#af2_popup_modal_ .af2_modal_content #af2_popup_script').html(shortcode);
    });

    $(document).on('input', '#af2_popup_click_value', function() {
        const val = $(this).val();
        const objectid = $(this).attr('data-objectid');
        let shortcode = '[funnelforms id="'+objectid+'" popup_by_click="true" popup_click_class="'+val+'"]';
        $('#af2_popup_modal_ .af2_modal_content #af2_popup_script').html(shortcode);
    });

    $(document).on('af2_close_modal', 'body', function(e) {
        if(e.target.id == "af2_funnel_link_modal") {
            window.location.reload();
        }
    });
});