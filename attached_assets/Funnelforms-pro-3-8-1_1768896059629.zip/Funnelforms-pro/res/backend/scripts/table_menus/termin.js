$( document ).ready(function($) {
    let activePast = true;

    const changeActivePast = () => {
        if(activePast == true) {
            activePast = false;
            $('.af2_post_table_body .af2_post_table_row').each((i, el) => {
                let id = $(el).attr('id');
                if(id != undefined) {
                    let datum = $('.af2_post_table_body .af2_post_table_row#' + id +' .af2_post_table_content[data-searchfilter="Date"]').data('searchvalue');
                    let zeit = $('.af2_post_table_body .af2_post_table_row#' + id +' .af2_post_table_content[data-searchfilter="Time"]').data('searchvalue');
    
                    let datums = datum.split('.');
                    if(datums[0].length == 1) datums[0] = '0' + datums[0];
                    if(datums[1].length == 1) datums[1] = '0' + datums[1];
                    let zeits = zeit.split(':');
                    let final = datums[2] + '' + datums[1] + '' + datums[0] + '' + zeits[0] + '' + zeits[1];
    
                    let date = new Date()
    
                    let day = date.getDate();
                    let month = date.getMonth() + 1;
                    let year = date.getFullYear();
                    let hour = date.getHours();
                    let minute = date.getMinutes();
    
                    day = (day < 10 ? '0' : '') + day;
                    month = (month < 10 ? '0' : '') + month;
                    hour = (hour < 10 ? '0' : '') + hour;
                    minute = (minute < 10 ? '0' : '') + minute;
    
                    let final2 = year + '' + month + '' + day + '' + hour + '' + minute;
                    
                    if(final < final2) $('.af2_post_table_body .af2_post_table_row#' + id).addClass('af2_hide');
                    if(final < final2) $('.af2_post_table_body .af2_post_table_row#' + id).addClass('af2_table_highlight');

                    // console.log($('.af2_post_table_body .af2_post_table_content[data-searchfilter="Titel"]').data('searchvalue') + ' - ' + final + ' : ' + final2);
                }
            });
        }
        else {
            activePast = true;
            $('.af2_post_table_row.af2_hide').each((i, el) => {
                $('#'+$(el).attr('id')).removeClass('af2_hide');
            });
        } 
    }

    $(document).on('click', '#af2_show_outdated', changeActivePast );

    changeActivePast();
});
