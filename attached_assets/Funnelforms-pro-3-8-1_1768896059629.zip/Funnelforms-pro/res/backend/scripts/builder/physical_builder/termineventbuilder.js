$( document ).ready(function() {

    af2_builder_object.af2_save_object.title = af2_builder_object.af2_save_object.title != null ? af2_builder_object.af2_save_object.title : '';
    
    af2_builder_object.af2_save_object.typ = af2_builder_object.af2_save_object.typ != null ? af2_builder_object.af2_save_object.typ : 'meeting_personal';
    af2_builder_object.af2_save_object.invitation = af2_builder_object.af2_save_object.invitation != null ? af2_builder_object.af2_save_object.invitation : true;
    af2_builder_object.af2_save_object.puffer = af2_builder_object.af2_save_object.puffer != null ? af2_builder_object.af2_save_object.puffer : 'puffer_15';
    af2_builder_object.af2_save_object.calendar_typ = af2_builder_object.af2_save_object.calendar_typ != null ? af2_builder_object.af2_save_object.calendar_typ : null;
    af2_builder_object.af2_save_object.calendar_conflict = af2_builder_object.af2_save_object.calendar_conflict != null ? af2_builder_object.af2_save_object.calendar_conflict : [];
    af2_builder_object.af2_save_object.vorlaufzeit = af2_builder_object.af2_save_object.vorlaufzeit != null ? af2_builder_object.af2_save_object.vorlaufzeit : '60';
    af2_builder_object.af2_save_object.anfangszeit = af2_builder_object.af2_save_object.anfangszeit != null ? af2_builder_object.af2_save_object.anfangszeit : '30';
    af2_builder_object.af2_save_object.verfuegbarkeit = af2_builder_object.af2_save_object.verfuegbarkeit != null ? af2_builder_object.af2_save_object.verfuegbarkeit : [{days: 'workday', from: '09-00', to: '16-00'}];
    af2_builder_object.af2_save_object.dauer = af2_builder_object.af2_save_object.dauer != null ? af2_builder_object.af2_save_object.dauer : [{std: '0', min: '30'}];
    af2_builder_object.af2_save_object.reminder = af2_builder_object.af2_save_object.reminder != null ? af2_builder_object.af2_save_object.reminder : [];
    af2_builder_object.af2_save_object.datumsbereich = af2_builder_object.af2_save_object.datumsbereich != null ? af2_builder_object.af2_save_object.datumsbereich : 'daterange_future';
    af2_builder_object.af2_save_object.daterange_future_number = af2_builder_object.af2_save_object.daterange_future_number != null ? af2_builder_object.af2_save_object.daterange_future_number : '2';
    af2_builder_object.af2_save_object.daterange_future_unit = af2_builder_object.af2_save_object.daterange_future_unit != null ? af2_builder_object.af2_save_object.daterange_future_unit : 'week';
    af2_builder_object.af2_save_object.daterange_daterange_end = af2_builder_object.af2_save_object.daterange_daterange_end != null ? af2_builder_object.af2_save_object.daterange_daterange_end : ''; // next day
    af2_builder_object.af2_save_object.daterange_daterange_start = af2_builder_object.af2_save_object.daterange_daterange_start != null ? af2_builder_object.af2_save_object.daterange_daterange_start : ''; // next day


    // Create all selects
    // Verfügbare Zeiten
    const af2_create_verfuegbarkeit = () => {
        $('.af2_terminevent_time_select').html('');
        af2_builder_object.af2_save_object.verfuegbarkeit.forEach((el, i) => {
            let content = '';

            content += '<div class="af2_terminevent_array_wrapper">';
                            content += '<select id="select_tag" class="af2_edit_content_select" data-saveobjectid="verfuegbarkeit" data-saveobjectarrayid="'+i+'" data-saveobjectfieldid="days" value="">';
                                content += '<option value="daily">'+af2_termineventbuilder_object.strings.daily+'</option>';
                                content += '<option value="workday">'+af2_termineventbuilder_object.strings.mofr+'</option>';
                                content += '<option value="weekend">'+af2_termineventbuilder_object.strings.saso+'</option>';
                                content += '<option value="monday">'+af2_termineventbuilder_object.strings.monday+'</option>';
                                content += '<option value="tuseday">'+af2_termineventbuilder_object.strings.tuseday+'</option>';
                                content += '<option value="wednesday">'+af2_termineventbuilder_object.strings.wednesday+'</option>';
                                content += '<option value="thursday">'+af2_termineventbuilder_object.strings.thursday+'</option>';
                                content += '<option value="friday">'+af2_termineventbuilder_object.strings.friday+'</option>';
                                content += '<option value="saturday">'+af2_termineventbuilder_object.strings.saturday+'</option>';
                                content += '<option value="sunday">'+af2_termineventbuilder_object.strings.sunday+'</option>';
                            content += '</select>';
                            content += '<p class="af2_terminevent_margin_between">'+af2_termineventbuilder_object.strings.von+'</p>';
                            content += '<select id="select_von" class="af2_edit_content_select" data-saveobjectid="verfuegbarkeit" data-saveobjectarrayid="'+i+'" data-saveobjectfieldid="from">';
                                content += '<option value="00-00">00:00</option>';
                                content += '<option value="00-15">00:15</option>';
                                content += '<option value="00-30">00:30</option>';
                                content += '<option value="00-45">00:45</option>';
                                content += '<option value="01-00">01:00</option>';
                                content += '<option value="01-15">01:15</option>';
                                content += '<option value="01-30">01:30</option>';
                                content += '<option value="01-45">01:45</option>';
                                content += '<option value="02-00">02:00</option>';
                                content += '<option value="02-15">02:15</option>';
                                content += '<option value="02-30">02:30</option>';
                                content += '<option value="02-45">02:45</option>';
                                content += '<option value="03-00">03:00</option>';
                                content += '<option value="03-15">03:15</option>';
                                content += '<option value="03-30">03:30</option>';
                                content += '<option value="03-45">03:45</option>';
                                content += '<option value="04-00">04:00</option>';
                                content += '<option value="04-15">04:15</option>';
                                content += '<option value="04-30">04:30</option>';
                                content += '<option value="04-45">04:45</option>';
                                content += '<option value="05-00">05:00</option>';
                                content += '<option value="05-15">05:15</option>';
                                content += '<option value="05-30">05:30</option>';
                                content += '<option value="05-45">05:45</option>';
                                content += '<option value="06-00">06:00</option>';
                                content += '<option value="06-15">06:15</option>';
                                content += '<option value="06-30">06:30</option>';
                                content += '<option value="06-45">06:45</option>';
                                content += '<option value="07-00">07:00</option>';
                                content += '<option value="07-15">07:15</option>';
                                content += '<option value="07-30">07:30</option>';
                                content += '<option value="07-45">07:45</option>';
                                content += '<option value="08-00">08:00</option>';
                                content += '<option value="08-15">08:15</option>';
                                content += '<option value="08-30">08:30</option>';
                                content += '<option value="08-45">08:45</option>';
                                content += '<option value="09-00">09:00</option>';
                                content += '<option value="09-15">09:15</option>';
                                content += '<option value="09-30">09:30</option>';
                                content += '<option value="09-45">09:45</option>';
                                content += '<option value="10-00">10:00</option>';
                                content += '<option value="10-15">10:15</option>';
                                content += '<option value="10-30">10:30</option>';
                                content += '<option value="10-45">10:45</option>';
                                content += '<option value="11-00">11:00</option>';
                                content += '<option value="11-15">11:15</option>';
                                content += '<option value="11-30">11:30</option>';
                                content += '<option value="11-45">11:45</option>';
                                content += '<option value="12-00">12:00</option>';
                                content += '<option value="12-15">12:15</option>';
                                content += '<option value="12-30">12:30</option>';
                                content += '<option value="12-45">12:45</option>';
                                content += '<option value="13-00">13:00</option>';
                                content += '<option value="13-15">13:15</option>';
                                content += '<option value="13-30">13:30</option>';
                                content += '<option value="13-45">13:45</option>';
                                content += '<option value="14-00">14:00</option>';
                                content += '<option value="14-15">14:15</option>';
                                content += '<option value="14-30">14:30</option>';
                                content += '<option value="14-45">14:45</option>';
                                content += '<option value="15-00">15:00</option>';
                                content += '<option value="15-15">15:15</option>';
                                content += '<option value="15-30">15:30</option>';
                                content += '<option value="15-45">15:45</option>';
                                content += '<option value="16-00">16:00</option>';
                                content += '<option value="16-15">16:15</option>';
                                content += '<option value="16-30">16:30</option>';
                                content += '<option value="16-45">16:45</option>';
                                content += '<option value="17-00">17:00</option>';
                                content += '<option value="17-15">17:15</option>';
                                content += '<option value="17-30">17:30</option>';
                                content += '<option value="17-45">17:45</option>';
                                content += '<option value="18-00">18:00</option>';
                                content += '<option value="18-15">18:15</option>';
                                content += '<option value="18-30">18:30</option>';
                                content += '<option value="18-45">18:45</option>';
                                content += '<option value="19-00">19:00</option>';
                                content += '<option value="19-15">19:15</option>';
                                content += '<option value="19-30">19:30</option>';
                                content += '<option value="19-45">19:45</option>';
                                content += '<option value="20-00">20:00</option>';
                                content += '<option value="20-15">20:15</option>';
                                content += '<option value="20-30">20:30</option>';
                                content += '<option value="20-45">20:45</option>';
                                content += '<option value="21-00">21:00</option>';
                                content += '<option value="21-15">21:15</option>';
                                content += '<option value="21-30">21:30</option>';
                                content += '<option value="21-45">21:45</option>';
                                content += '<option value="22-00">22:00</option>';
                                content += '<option value="22-15">22:15</option>';
                                content += '<option value="22-30">22:30</option>';
                                content += '<option value="22-45">22:45</option>';
                                content += '<option value="23-00">23:00</option>';
                                content += '<option value="23-15">23:15</option>';
                                content += '<option value="23-30">23:30</option>';
                                content += '<option value="23-45">23:45</option>';
                            content += '</select>';
                            content += '<p class="af2_terminevent_margin_between">'+af2_termineventbuilder_object.strings.bis+'</p>';
                            content += '<select id="select_bis" class="af2_edit_content_select" data-saveobjectid="verfuegbarkeit" data-saveobjectarrayid="'+i+'" data-saveobjectfieldid="to">';
                            content += '<option value="00-00">00:00</option>';
                                content += '<option value="00-15">00:15</option>';
                                content += '<option value="00-30">00:30</option>';
                                content += '<option value="00-45">00:45</option>';
                                content += '<option value="01-00">01:00</option>';
                                content += '<option value="01-15">01:15</option>';
                                content += '<option value="01-30">01:30</option>';
                                content += '<option value="01-45">01:45</option>';
                                content += '<option value="02-00">02:00</option>';
                                content += '<option value="02-15">02:15</option>';
                                content += '<option value="02-30">02:30</option>';
                                content += '<option value="02-45">02:45</option>';
                                content += '<option value="03-00">03:00</option>';
                                content += '<option value="03-15">03:15</option>';
                                content += '<option value="03-30">03:30</option>';
                                content += '<option value="03-45">03:45</option>';
                                content += '<option value="04-00">04:00</option>';
                                content += '<option value="04-15">04:15</option>';
                                content += '<option value="04-30">04:30</option>';
                                content += '<option value="04-45">04:45</option>';
                                content += '<option value="05-00">05:00</option>';
                                content += '<option value="05-15">05:15</option>';
                                content += '<option value="05-30">05:30</option>';
                                content += '<option value="05-45">05:45</option>';
                                content += '<option value="06-00">06:00</option>';
                                content += '<option value="06-15">06:15</option>';
                                content += '<option value="06-30">06:30</option>';
                                content += '<option value="06-45">06:45</option>';
                                content += '<option value="07-00">07:00</option>';
                                content += '<option value="07-15">07:15</option>';
                                content += '<option value="07-30">07:30</option>';
                                content += '<option value="07-45">07:45</option>';
                                content += '<option value="08-00">08:00</option>';
                                content += '<option value="08-15">08:15</option>';
                                content += '<option value="08-30">08:30</option>';
                                content += '<option value="08-45">08:45</option>';
                                content += '<option value="09-00">09:00</option>';
                                content += '<option value="09-15">09:15</option>';
                                content += '<option value="09-30">09:30</option>';
                                content += '<option value="09-45">09:45</option>';
                                content += '<option value="10-00">10:00</option>';
                                content += '<option value="10-15">10:15</option>';
                                content += '<option value="10-30">10:30</option>';
                                content += '<option value="10-45">10:45</option>';
                                content += '<option value="11-00">11:00</option>';
                                content += '<option value="11-15">11:15</option>';
                                content += '<option value="11-30">11:30</option>';
                                content += '<option value="11-45">11:45</option>';
                                content += '<option value="12-00">12:00</option>';
                                content += '<option value="12-15">12:15</option>';
                                content += '<option value="12-30">12:30</option>';
                                content += '<option value="12-45">12:45</option>';
                                content += '<option value="13-00">13:00</option>';
                                content += '<option value="13-15">13:15</option>';
                                content += '<option value="13-30">13:30</option>';
                                content += '<option value="13-45">13:45</option>';
                                content += '<option value="14-00">14:00</option>';
                                content += '<option value="14-15">14:15</option>';
                                content += '<option value="14-30">14:30</option>';
                                content += '<option value="14-45">14:45</option>';
                                content += '<option value="15-00">15:00</option>';
                                content += '<option value="15-15">15:15</option>';
                                content += '<option value="15-30">15:30</option>';
                                content += '<option value="15-45">15:45</option>';
                                content += '<option value="16-00">16:00</option>';
                                content += '<option value="16-15">16:15</option>';
                                content += '<option value="16-30">16:30</option>';
                                content += '<option value="16-45">16:45</option>';
                                content += '<option value="17-00">17:00</option>';
                                content += '<option value="17-15">17:15</option>';
                                content += '<option value="17-30">17:30</option>';
                                content += '<option value="17-45">17:45</option>';
                                content += '<option value="18-00">18:00</option>';
                                content += '<option value="18-15">18:15</option>';
                                content += '<option value="18-30">18:30</option>';
                                content += '<option value="18-45">18:45</option>';
                                content += '<option value="19-00">19:00</option>';
                                content += '<option value="19-15">19:15</option>';
                                content += '<option value="19-30">19:30</option>';
                                content += '<option value="19-45">19:45</option>';
                                content += '<option value="20-00">20:00</option>';
                                content += '<option value="20-15">20:15</option>';
                                content += '<option value="20-30">20:30</option>';
                                content += '<option value="20-45">20:45</option>';
                                content += '<option value="21-00">21:00</option>';
                                content += '<option value="21-15">21:15</option>';
                                content += '<option value="21-30">21:30</option>';
                                content += '<option value="21-45">21:45</option>';
                                content += '<option value="22-00">22:00</option>';
                                content += '<option value="22-15">22:15</option>';
                                content += '<option value="22-30">22:30</option>';
                                content += '<option value="22-45">22:45</option>';
                                content += '<option value="23-00">23:00</option>';
                                content += '<option value="23-15">23:15</option>';
                                content += '<option value="23-30">23:30</option>';
                                content += '<option value="23-45">23:45</option>';
                            content += '</select>';
                            let hideClass = '';
                            if(i == 0) hideClass = 'af2_hide_';
                            content += '<div class="af2_edit_content_remove af2_edit_content_remove_verfuegbarkeit af2_btn af2_btn_primary '+hideClass+'" data-saveobjectid="verfuegbarkeit" data-saveobjectarrayid="'+i+'"><i class="fas fa-trash"></i></div>';
                        content += '</div>';

            $('.af2_terminevent_time_select').append(content);
        });
    }

    // Dauer
    const af2_create_dauer = () => {
        $('.af2_terminevent_duration_select').html('');
        af2_builder_object.af2_save_object.dauer.forEach((el, i) => {
            let content = '';
            content += '<div class="af2_terminevent_array_wrapper">';
                content += '<input type="number" class="af2_edit_content_input" data-saveobjectid="dauer" min="0" max="12" data-saveobjectarrayid="'+i+'" data-saveobjectfieldid="std">';
                content += '<p class="af2_terminevent_margin_after">'+af2_termineventbuilder_object.strings.hours+'</p>';
                content += '<input type="number" class="af2_edit_content_input" data-saveobjectid="dauer" min="0" max="59" data-saveobjectarrayid="'+i+'" data-saveobjectfieldid="min">';
                content += '<p class="af2_terminevent_margin_after">'+af2_termineventbuilder_object.strings.minutes+'</p>';
                let hideClass = '';
                if(i == 0) hideClass = 'af2_hide_';
                content += '<div class="af2_edit_content_remove af2_edit_content_remove_dauer af2_btn af2_btn_primary '+hideClass+'" data-saveobjectid="dauer" data-saveobjectarrayid="'+i+'"><i class="fas fa-trash"></i></div>';
            content += '</div>';

            $('.af2_terminevent_duration_select').append(content);
        });
            
        if(af2_builder_object.af2_save_object.dauer.length >= 3) $('.af2_edit_content_add_dauer').addClass('af2_hide_');
        else $('.af2_edit_content_add_dauer').removeClass('af2_hide_');
    }

    // Reminder
    const af2_create_erinnerungen = () => {
        $('.af2_terminevent_reminder_select').html('');
        af2_builder_object.af2_save_object.reminder.forEach((el, i) => {
            let content = '';
            content += '<div class="af2_terminevent_array_wrapper">';
                content += '<input type="number" class="af2_edit_content_input edit_content_terminevent_number" data-saveobjectid="reminder" min="0" max="59" data-saveobjectarrayid="'+i+'" data-saveobjectfieldid="number">';
                content += '<select id="select_tag" class="af2_edit_content_select" data-saveobjectid="reminder" data-saveobjectarrayid="'+i+'" data-saveobjectfieldid="unit" value="">';
                    content += '<option value="minutes">'+af2_termineventbuilder_object.strings.minutes+'</option>';
                    content += '<option value="hours">'+af2_termineventbuilder_object.strings.hours+'</option>';
                    content += '<option value="days">'+af2_termineventbuilder_object.strings.days+'</option>';
                content += '</select>';
                content += '<div class="af2_edit_content_remove af2_edit_content_remove_reminder af2_btn af2_btn_primary" data-saveobjectid="reminder" data-saveobjectarrayid="'+i+'"><i class="fas fa-trash"></i></div>';
            content += '</div>';

            $('.af2_terminevent_reminder_select').append(content);
        });

        if(af2_builder_object.af2_save_object.reminder.length >= 5) $('.af2_edit_content_add_reminder').addClass('af2_hide_');
        else $('.af2_edit_content_add_reminder').removeClass('af2_hide_');
    }

    $(document).on('click', '.af2_edit_content_remove_verfuegbarkeit', function() {
        if($(this).hasClass('af2_hide_')) return;
        const saveObjectId = $(this).data('saveobjectid');
        const saveObjectArrayId = $(this).data('saveobjectarrayid');

        af2_builder_object.af2_save_object[saveObjectId].splice(saveObjectArrayId, 1);

        af2_create_verfuegbarkeit();
        af2_load_input_html_data();
    });
    $(document).on('click', '.af2_edit_content_add_verfuegbarkeit', function() {
        if($(this).hasClass('af2_hide_')) return;
        af2_builder_object.af2_save_object['verfuegbarkeit'].push({days: 'workday', from: '09-00', to: '16-00'});

        af2_create_verfuegbarkeit();
        af2_load_input_html_data();
    });

    $(document).on('click', '.af2_edit_content_remove_dauer', function() {
        if($(this).hasClass('af2_hide_')) return;
        const saveObjectId = $(this).data('saveobjectid');
        const saveObjectArrayId = $(this).data('saveobjectarrayid');

        af2_builder_object.af2_save_object[saveObjectId].splice(saveObjectArrayId, 1);

        af2_create_dauer();
        af2_load_input_html_data();
    });
    $(document).on('click', '.af2_edit_content_add_dauer', function() {
        if($(this).hasClass('af2_hide_')) return;
        af2_builder_object.af2_save_object['dauer'].push({std: '0', min: '30'});

        af2_create_dauer();
        af2_load_input_html_data();
    });

    $(document).on('click', '.af2_edit_content_remove_reminder', function() {
        if($(this).hasClass('af2_hide_')) return;
        const saveObjectId = $(this).data('saveobjectid');
        const saveObjectArrayId = $(this).data('saveobjectarrayid');

        af2_builder_object.af2_save_object[saveObjectId].splice(saveObjectArrayId, 1);

        af2_create_erinnerungen();
        af2_load_input_html_data();
    });
    $(document).on('click', '.af2_edit_content_add_reminder', function() {
        if($(this).hasClass('af2_hide_')) return;
        af2_builder_object.af2_save_object['reminder'].push({number: '30', unit: 'minutes'});

        af2_create_erinnerungen();
        af2_load_input_html_data();
    });


    af2_create_verfuegbarkeit();
    af2_create_dauer();
    af2_create_erinnerungen();

    af2_load_input_html_data();
    af2_load_object_data();

    $('input[name="daterangepicker"]').daterangepicker();
});