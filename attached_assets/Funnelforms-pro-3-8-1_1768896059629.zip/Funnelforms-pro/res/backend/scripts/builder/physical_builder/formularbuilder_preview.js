$( document ).ready(function() {
    $('#af2_goto_formularbuilder_settings').on('click', _ => {
        window.location.href = af2_formularbuilder_preview_object.redirect_formularbuilder_settings_url;
    });

    $('#device_button_mobile').on('click', _ => {
        $('.af2_custom_builder_wrapper.af2_formularbuilder_preview').addClass('af2_preview_mobile_view');
        $('.af2_custom_builder_wrapper.af2_formularbuilder_preview').removeClass('af2_preview_ipad_view');
        $('.af2_custom_builder_wrapper.af2_formularbuilder_preview').removeClass('af2_preview_desktop_view');

        
        $('.af2_form_carousel').css('min-width', 'unset');
        $('.af2_form_carousel').css('max-width', 'unset');
        $('.af2_form_carousel').css('min-width',  $('.af2_form_carousel').width());
        $('.af2_form_carousel').css('max-width',  $('.af2_form_carousel').width());

        $('.af2-select2-container').removeClass('desktop').addClass('af2_mobile');

        const height = $('.af2_form_carousel .af2_carousel_content').last().height();
        $('.af2_form_carousel').css('height', height);
    });
    $('#device_button_ipad').on('click', _ => {
        $('.af2_custom_builder_wrapper.af2_formularbuilder_preview').removeClass('af2_preview_mobile_view');
        $('.af2_custom_builder_wrapper.af2_formularbuilder_preview').addClass('af2_preview_ipad_view');
        $('.af2_custom_builder_wrapper.af2_formularbuilder_preview').removeClass('af2_preview_desktop_view');

        
        $('.af2_form_carousel').css('min-width', 'unset');
        $('.af2_form_carousel').css('max-width', 'unset');
        $('.af2_form_carousel').css('min-width',  $('.af2_form_carousel').width());
        $('.af2_form_carousel').css('max-width',  $('.af2_form_carousel').width());

        $('.af2-select2-container').removeClass('af2_mobile').addClass('desktop');

        const height = $('.af2_form_carousel .af2_carousel_content').last().height();
        $('.af2_form_carousel').css('height', height);
    });
    $('#device_button_desktop').on('click', _ => {
        $('.af2_custom_builder_wrapper.af2_formularbuilder_preview').removeClass('af2_preview_mobile_view');
        $('.af2_custom_builder_wrapper.af2_formularbuilder_preview').removeClass('af2_preview_ipad_view');
        $('.af2_custom_builder_wrapper.af2_formularbuilder_preview').addClass('af2_preview_desktop_view');

        
        $('.af2_form_carousel').css('min-width', 'unset');
        $('.af2_form_carousel').css('max-width', 'unset');
        $('.af2_form_carousel').css('min-width',  $('.af2_form_carousel').width());
        $('.af2_form_carousel').css('max-width',  $('.af2_form_carousel').width());

        $('.af2-select2-container').removeClass('af2_mobile').addClass('desktop');

        const height = $('.af2_form_carousel .af2_carousel_content').last().height();
        $('.af2_form_carousel').css('height', height);
    });
});



/*
(function($, window, document) {

    var breakpoints = {
      "Mobile":  {"width": 360, "height": 768, "icon" : "phone_iphone"},
      "iPad":  {"width": 780, "height": 1024, "icon" : "tablet_mac"},
      "Desktop":    {"width": 100, "height": 700, "icon" : "desktop_windows"}
    }
    
    $(function() {
      var deviceCurrent;
      
      var $deviceChooser = $('.device-chooser'),
          $content = $('.preview_wrapper'),
          $iframe = $('iframe#af2_preview_window'),
          $deviceButtons = $('.device-chooser button');
  
  
      $deviceButtons.on('click', function(e){
          var key = this.dataset.device;
          $deviceChooser.find('li').removeClass('active');
          changeDevice(
            key, 
            breakpoints[key]["width"], 
            breakpoints[key]["height"]
          );
          $(this).parent('li').addClass('active');
      });
         
      function changeDevice(key, w, h) {
          var w = w.toString(); var h = h.toString();
          $iframe
            .css('width', w + (key != 'Desktop' ? 'px' : '%'))
            .css('height', h + (key != 'Desktop' ? 'px' : '%'));
          if(key == 'Desktop'){
            $content.addClass('content--maximized');
          }else{
            $content.removeClass('content--maximized');
          }
          deviceCurrent = key;
      }
  
      var initDeviceType = "Desktop"
      var initDevice = changeDevice(initDeviceType, breakpoints[initDeviceType]["width"], breakpoints[initDeviceType]["height"]);
    });
  
  }(window.jQuery, window, document));
  */
