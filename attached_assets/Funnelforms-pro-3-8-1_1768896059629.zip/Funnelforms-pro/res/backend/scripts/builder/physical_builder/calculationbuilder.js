$( document ).ready(function() {

    af2_builder_object.af2_save_object.title = af2_builder_object.af2_save_object.title != null ? af2_builder_object.af2_save_object.title : '';
    af2_builder_object.af2_save_object.formula_decimal_count = af2_builder_object.af2_save_object.formula_decimal_count != null ? af2_builder_object.af2_save_object.formula_decimal_count : 2;
    af2_builder_object.af2_save_object.formula_decimal_separator = af2_builder_object.af2_save_object.formula_decimal_separator != null ? af2_builder_object.af2_save_object.formula_decimal_separator : ".";
    af2_builder_object.af2_save_object.formula_thousands_separator = af2_builder_object.af2_save_object.formula_thousands_separator != null ? af2_builder_object.af2_save_object.formula_thousands_separator : ",";
    // Formula
    const af2_textarea_calculate_formula = () => {

        $('#af2_textarea_calculate_formula').html('');

    }

    $(document).on('click', '#af2_calculate_formula_calculate', function() {

        $.ajax({
            url: af2_builder_object.ajax_url,
            type: "POST",
            dataType: "json",
            data: {
                action : 'af2_calculate_formula_check',
                formula : $("#af2_textarea_calculate_formula textarea").val(),
                post_id: af2_builder_object.post_id,
            },
            success: (data) => {
                console.log(data);
                if(data.success) {
                    $('#af2_calculate_formula_calculate_result').html(data.message);
                } else {
                    $('#af2_calculate_formula_calculate_result').html("ERROR: " + data.message);
                }
            },
            error: (jqXHR, error, errorThrown) => {
            }
        });

    });

    $(document).on('click', '.af2_calculate_formula_question', function() {

        var copyText = "["+$(this).data("id")+"]";
        $( "#af2_textarea_calculate_formula_textarea" ).val($( "#af2_textarea_calculate_formula_textarea" ).val() + copyText + " ").trigger('input');

    });

    af2_load_input_html_data();
    af2_load_object_data();

    $('#af2_create_new_calculation').on('click', ev => {
        af2_save_builder( _ => {
            window.location.href = af2_calculationbuilder_object.create_new_calculation_url;
        });
    });
});
