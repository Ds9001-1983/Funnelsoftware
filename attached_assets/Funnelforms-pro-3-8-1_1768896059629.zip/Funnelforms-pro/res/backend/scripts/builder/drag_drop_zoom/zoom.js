
var zoom_level = parseInt($('.af2_zoom_container').data('zoomlevel'));

$(document).on('click', '#af2_zoom_out', _ => {
    zoom_level--;
    if(zoom_level < 1) zoom_level = 1;
    $('.af2_zoom_container').attr('data-zoomlevel', zoom_level);

    let event = jQuery.Event('af2_zoomed_out');
    $('.af2_zoom_container').trigger(event);
});


$(document).on('click', '#af2_zoom_in', _ => {
    zoom_level++;
    if(zoom_level > 5) zoom_level = 5;
    $('.af2_zoom_container').attr('data-zoomlevel', zoom_level);

    let event = jQuery.Event('af2_zoomed_in');
    $('.af2_zoom_container').trigger(event);
});