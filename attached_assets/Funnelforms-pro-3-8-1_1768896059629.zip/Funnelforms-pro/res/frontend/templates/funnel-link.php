<?php
$form_id = get_query_var('af2_form_id');
$form = af2_get_post_content($form_id);
$form_title = get_bloginfo( 'name' );
if($form['styling']['fe_title']) {
    $form_title = $form['styling']['fe_title'];
}
$form_lang_attribute = get_language_attributes();
if($form['fe_locale'] != "default") {
    $form_lang_attribute = 'lang="'.$form['fe_locale'].'"';
}

?>
<!DOCTYPE html>
<html <?php echo $form_lang_attribute; ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <title><?php echo $form_title; ?></title>
    <?php wp_head(); ?>
</head>
<body class="af2-standalone-form">
    <div class="af2-standalone-form-container">
    <?php
    echo do_shortcode('[funnelforms id="' . esc_attr($form_id) . '"]');
    ?>
    <?php wp_footer(); ?>
</body>
</html>