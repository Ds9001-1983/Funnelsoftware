<?php

function readMsgIdsFromPoFile($poFilePath) {
    $msgidList = [];

    $poFileContent = file_get_contents($poFilePath);

    $entries = preg_split('/\n\n/', $poFileContent);

    foreach ($entries as $entry) {
        preg_match('/msgid "(.*)"/', $entry, $matches);
        if (isset($matches[1])) {
            $msgidList[] = $matches[1];
        }
    }

    return $msgidList;
}


$filename = "./admin/translations.php";
$languages = "./languages/";
$keys = [];

if(file_exists($filename)) {
    file_put_contents($filename, "");
}


$path = "/path/to/files";

if ($dhandle = opendir($languages)) {
    while (false !== ($file = readdir($dhandle))) {
        if ('.' === $file) continue;
        if ('..' === $file) continue;

        $ext = pathinfo($file, PATHINFO_EXTENSION);

        if($ext == "po") {
            $array = readMsgIdsFromPoFile($languages.$file);
            $keys = array_unique(array_merge($keys, $array));
        }
    }
    closedir($dhandle);
}

$fhandle = fopen($filename, "w");
fwrite($fhandle, '<?php');
fwrite($fhandle, "\n\n");
foreach($keys as $key) {
    $string = '__("'.$key.'", "af2_multilanguage");';
    fwrite($fhandle, $string);
    fwrite($fhandle, "\n");
}
fclose($fhandle);
