<?php

/*
Plugin Name: Funnelforms Pro
Description: Create innovative forms and optimize your lead generation, recruiting, pricing calculation, appointment booking or product configuration! Get more ready-to-buy customers, acquire the right staff and digitize your business processes with intuitive and smart multi-step forms! Create high-quality forms with just a few clicks using drag & drop, without touching a line of code and lead your website visitors intuitively through a sales-boosting form funnel.
Author: Funnelforms
Author URI: https://funnelforms.io/
Author E-Mail: support@funnelforms.io
Text Domain: af2_multilanguage
Domain Path: /languages/
Version: 3.8.1
*/


/*
 * Developed By:
 * CodeRevolution - https://coderevolution.de/
*/


// Throw out if unallowed access

use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

defined('ABSPATH') or die('NO!');

register_activation_hook(__FILE__, 'ff_activation');
function ff_activation()
{
    deactivate_plugins('funnelforms-free/Funnelforms-free.php');
}

if (!get_option('af2_free_version')) {
    add_option('af2_free_version', '0');
}

// Check if free version is active
include_once ABSPATH . 'wp-admin/includes/plugin.php';
if (is_plugin_active('Anfrageformular/Anfrageformular.php')) {
    //die(__('You still have the free version of the Funnelforms plugin installed. Please deactivate the free version first before you activate the Funnelforms Pro version!', 'af2_multilanguage'));
}
if (!is_plugin_active('funnelforms-free/Funnelforms-free.php')) {
    update_option('af2_free_version', '0');
}
if (get_option('af2_free_version') == '1') {
} else {

    // Plugin DIR constants
    define('AF2_PLUGIN', __FILE__);

    define('AF2_PLUGIN_DIR', untrailingslashit(dirname(AF2_PLUGIN)));
    define('AF2_LANGUAGES_PATH', dirname(plugin_basename(AF2_PLUGIN)) . '/languages/');

    // Include Constants
    require_once AF2_PLUGIN_DIR . '/misc/constants.php';

    // Include ML
    require_once AF2_MULTILANGUAGE_HANDLER_PATH;

    // Include WP Options
    require_once AF2_WP_OPTIONS_PATH;

    // Include resource handler
    require_once AF2_RESOURCE_HANDLER_PATH;

    // Include Admin handler
    require_once AF2_ADMIN_HANDLER_PATH;

    // Include version migration
    require_once AF2_VERSION_MIGRATION_PATH;

    // Include healthchecks
    require_once AF2_HEALTHCHECK_PATH;


    // Frontend path
    require_once AF2_FRONTEND_PATH;
    require_once AF2_FRONTEND_FUNNEL_PATH;

    // Add Zapier API
    require_once AF2_INTEGRATION_REST_ZAPIER;
    // Add Zapier API
    require_once AF2_INTEGRATION_REST_MAKE;

    // Add App
    require_once AF2_APP_REST;

    // Math parser
    require_once  AF2_PLUGIN_DIR . '/vendor/matex/Evaluator.php';

    // QR Generator
    require_once  AF2_PLUGIN_DIR . '/vendor/php-qr-code-master/src/QRCode.php';

    // Plugin Update Checker
    require AF2_UPDATE;
    $MyUpdateChecker = PucFactory::buildUpdateChecker(
        'https://updateserver-anfrageformular.com/wp-update-server/?action=get_metadata&slug=Funnelforms-pro', //Metadata URL.
        __FILE__, //Full path to the main plugin file.
        'Funnelforms-pro' //Plugin slug. Usually it's the same as the name of the directory.
    );

    require_once  AF2_PLUGIN_DIR . '/vendor/persist-admin-notices-dismissal/persist-admin-notices-dismissal.php';

    add_action('admin_init', array('PAnD', 'init'));

    function ff_notice()
    {

        global $pagenow;
        $admin_pages = ['index.php', 'edit.php', 'plugins.php'];
        if (true || in_array($pagenow, $admin_pages)) {


            $url = "https://member.funnelforms.io/wp-json/af2/app/v2/dashboardnotes_pro";

            $ch2 = curl_init();
            curl_setopt($ch2, CURLOPT_URL, $url);
            curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
            $output =  curl_exec($ch2);
            curl_close($ch2);
            $json = json_decode($output);
            $locale = get_user_locale();
            $headlineProperty = 'headline';
            $textProperty = 'text';
            if (strpos($locale, "de_") === false) {
                $headlineProperty = 'headline_en';
                $textProperty = 'text_en';
            }

            foreach ($json as $notice) {
                if (! PAnD::is_admin_notice_active('disable-' . $notice->id . '-forever')) {
                    continue;
                }

?>
                <style>
                    .ff-notice {
                        background-color: #6A30F5;
                        color: #ffffff;
                        padding: 10px 20px;
                        margin-top: 20px;
                        border-radius: 5px;
                        border: 0;
                    }

                    .ff-notice h2,
                    .ff-notice p {
                        margin: 0;
                    }

                    .ff-notice * {
                        color: #ffffff;
                    }

                    .ff-notice-content {
                        padding: 0px 20px;
                    }

                    .ff-notice-cta {
                        background-color: #ffffff;
                        color: #6A30F5;
                        border-radius: 5px;
                        padding: 10px 20px;
                        text-align: center;
                        line-height: 100%;
                        font-weight: bold;
                    }

                    .ff-notice .notice-dismiss:before {
                        color: #ffffff;
                    }
                </style>
                <div data-dismissible="disable-<?= $notice->id ?>-forever" class="ff-notice notice is-dismissible">
                    <div style="width: 100%; height: 100%; display: flex; align-items: center">
                        <div>
                            <img src="https://member.funnelforms.io/wp-content/uploads/2022/10/cropped-Funnelforms-White-SMALL.png" alt="Funnelform Logo" />
                        </div>
                        <div class="ff-notice-content">
                            <h2>
                                <?= $notice->$headlineProperty ?>
                            </h2>
                            <div>
                                <?= $notice->$textProperty ?>
                            </div>
                        </div>
                        <?php if (!empty($notice->link)) { ?>
                            <a href="<?= $notice->link->url ?>" target="<?= $notice->link->target ?>">
                                <div class="ff-notice-cta">
                                    <?= $notice->link->title ?>
                                </div>
                            </a>
                        <?php } ?>
                    </div>
                </div>
<?php
            }
        }
    }
    add_action('admin_notices', 'ff_notice');

    function getCurrentUrlWp()
    {
        return home_url($_SERVER['REQUEST_URI']);
    }

    function addOrUpdateQueryParamWp($paramName, $paramValue, $url = null)
    {
        if ($url === null) {
            $url = getCurrentUrlWp();
        }

        // Use WordPress's add_query_arg function to add or update the parameter
        $newUrl = add_query_arg($paramName, $paramValue, $url);

        return $newUrl;
    }

    // HTACCESS

    function do_htaccess_cors()
    {
        $htaccess = ABSPATH . ".htaccess";
        $tit = "AF2 - Allow Font embed";
        $lin = array();
        array_push($lin, "<IfModule mod_headers.c>");
        array_push($lin, '<FilesMatch ".(eot|otf|ttf|woff|woff2)">');
        array_push($lin, 'Header always set Access-Control-Allow-Origin "*"');
        array_push($lin, '</FilesMatch>');
        array_push($lin, "</IfModule>");

        insert_with_markers($htaccess, $tit, $lin);
    }

    add_action('admin_init', 'do_htaccess_cors');

    function do_htaccess_upload_restrict()
    {
        $htaccess = ABSPATH . ".htaccess";
        $tit = "AF2 - Protect User Uploads";

        $lin = array();

        # Protect all files within the uploads folder
        array_push($lin, "<IfModule mod_rewrite.c>");
        array_push($lin, "RewriteEngine On");
        array_push($lin, "RewriteCond %{HTTP_COOKIE} !.*wordpress_logged_in.*$ [NC]");
        array_push($lin, "RewriteCond %{REQUEST_URI} ^(.*?/?)wp-content/uploads/af2/.* [NC]");
        array_push($lin, "RewriteRule . http://%{HTTP_HOST}%1/wp-login.php?redirect_to=%{REQUEST_URI} [L,QSA]");
        array_push($lin, "</IfModule>");

        insert_with_markers($htaccess, $tit, $lin);
    }

    if (get_option('af2_htaccess_rewrite') == 'true') {
        add_action('admin_init', 'do_htaccess_upload_restrict');
    } else {
    }

    function allow_iframe_styling_fetch_cors()
    {
        header('Access-Control-Allow-Origin: *');
    }

    add_action('init', 'allow_iframe_styling_fetch_cors');


    add_action('rest_api_init', function () {
        register_rest_route('af2/app/v2', '/upload/(?P<id>\d+)/', [
            'methods' => 'GET',
            'callback' => 'af2_form_upload',
            'permission_callback' => '__return_true'
        ]);
    });

    function af2_form_upload($data)
    {

        $fileparam = $data->get_param('file');
        $url = $fileparam;
        $formid = $data['id'];
        $post = get_post($formid);

        // check if it a request and nothing else, otherwise refuse
        if ($post->post_type !== REQUEST_POST_TYPE) {
            return;
        }

        // get post meta content
        $public_param = get_post_meta($formid, $url, true);
        $url = $public_param;

        // if it is not set, or private then refuse
        if (!isset($public_param) || !$public_param || $public_param == 'private') return;


        // generate filepath
        $path = getcwd();
        $urlparts = parse_url(home_url());
        $domain = $urlparts['host'];
        $filepath = str_replace($domain, $path, $url);
        $filepath = str_replace("https://", "", $filepath);
        $filepath = str_replace("http://", "", $filepath);

        // checked post type, checked that answer is real, checked that it's not private, so return file!
        if (file_exists($filepath)) {
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . basename($filepath) . '"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($filepath));
            readfile($filepath);
            exit;
        } else return 'error';
    }
}
